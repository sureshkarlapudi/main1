# Alberta pipeline repository
## Overview

- [How to integrate](#how-to-integrate)
- [Folder Composition](#folder-composition)
- [Stages backend pipeline](#stages-backend-pipeline)
- [Configuration server pipeline](#configuration-server-pipeline)

### Introduction

The Alberta team has created shared libraries and reference Jenkins files to be used by teams within their applications. These contain common utilities and functionalities.


The pipeline and utilities facilitates the deployment of application taking into consideration what they need to function properly when deployed. 

#### <a name="how-to-integrate"></a>How to integrate

The configuration for the file should be included in pipelineconfig.yml in the root of the application. The information contained in this file are the parameters that make the application unique, these will be based into the main pipeline and everything is done internally. The following is an example of the configuration file: 
```
-- -
# root element which will contain all the pipeline config
pipeline:
  pcf:
    stage:
      foundation: stl-stage
      org: Alberta
      space: berta
      credid: alberta-pcf-credentials
    pr:
      foundation: stl-stage
      org: Alberta
      space: pr-int
      credid: alberta-pcf-credentials
  credentialids:
    stash: alberta-stash-credentials
    artifactory: alberta-uploader
    sonar: sonar-publisher
  synapse:
    clientname: identity-services-client
  branch:
    integration: pipeline-parameterization-test
```

For higher environments configurations are provided by the job to the pipeline. 

_For this repo, please we are following forking workflow. To make any change with PR, first fork this repo in your personal space create a feature branch. After changes gets completed raised PR to develop branch. Develop branch than will be merged with master branch as and when it is required as shown below_


￼![Alt Image Text](pipeline_flow.png "Config server pipeline")

### <a name="folder-composition"></a>Folder Composition

#### Reference
* In this folder we can find reference Jenkins files for backend, frontend, mobile. These Jenkins files should function as a reference for any current and future project. The pipelines make use of shared libraries to demonstrate functionality and how it can be integrated. Documentation on the stages provided is also available within this document.  

__Note__: Currently these are work in progress and will change with time based on enhancements, functionality and usage. 


Mastercard shared libraries:

In this folder we can find different components that can be used by pipelines to increase their functionality. Currently there is two folders:
* __Alberta__: 
    * Contains collection of Alberta utility tasks for Jenkins dsl to perform pipeline related tasks : 
        * QA utility functions used to extend functionality of pipeline related to quality assurance 
        * PCF Utility functions used to extend functionality of pipeline related to PCF
        * Common Utility functions used to extend functionality of pipeline with common functions 
        * Email Utility functions that aid on customizing email messages for pipeline output
* __Pipeline__ 
    * __Deploy__  
        * Utility to interact with the PCF platform. Used to deploy artifacts and manage services.
    * __Utility__ - collection of utilities to perform common pipeline tasks
        * Autoscaling util, this utility reads a autoscale.yml file and scales the application accordingly to rules specified within it
        * CaaSUtil is an utility used to interact with the Cases service used to create certs and trust stores for the applications
        * MavenUtil is an utility that performs various maven taks as well such as build, interact with sonar, integration tests, git pull., etc. 
        * PCFUtil used to deploy artifacts and manage services 
        * SynapseUtil used to handle synapse related tasks 
	

* __Vars__: 
	* In this folder we can find the shared global environment variables used within the project, some examples include the url to access different pcf environments. 

### <a name="stages-backend-pipeline"></a>Stages backend pipeline

￼![Alt Image Text](pipeline.png "Pipeline Image")

This is the entire pipeline. This pipeline consists of stages including the blue green deployment, getting certificates for the synapse  and autoscaling our application.
This pipeline consist of the backend stages that need to be called.

__Checkout__:
* First stage called when deploying an application, this will checkout the code from the git repository and clone it in the Jenkins workspace, currently these files are stashed for later use in other stages. 

__Test and build__:
* __Build__: 
    * In this stage the application is build with flags -d for outputting debug information and executes the task test with the flag -x test
* __Unit Tests__:
    * In this stage three tasks are called from within the gradle file check, clean, and test outputting debugging 

__SonarQube Static Code Analysis__:
* In this stage we run sonarqube which will do a continuous inspection of code quality. It will automatically review with static analysis of code to detect bugs, security vulnerabilities.

__Publish to Artifactory__:
* At this stage we upload the successful build to artifactory. 

__Setup E2E Environment__:
* This stage makes use of qaUtil to prepare for end to end tests 

__Get Certs__:
* In this stage we obtain the necessary security certificate that the application can use for communication with APIs 

__Note__: Current example is setup to go with stage

__Deploy Green__:
* At this stage the artifact is downloaded environment variables are set for application in case it makes use of synapse. The next step it takes care of is deploying the newer green application. 

__Integration Tests__:
* Green application is tested by bringing individual modules are combined and tested as a group. 

__Note__: This will differ based on application 


__Flip Traffic__:
* If the green application has passed all tests and is ready to go live this stage is called. The stage will take the green route and change to blue route which is our live route. 

__Autoscale application__:
* In this stage the application takes in the autoscaling.yml properties and turns on autoscaling based on those configurations. 

__Execute E2E Tests__:
* In this stage based on E2E setup the E2E will be executed and the pipeline will end successfully if this stage passes. 

### <a name="configuration-server-pipeline"></a>Configuration server pipeline

￼![Alt Image Text](config_server.png "Config server pipeline")

__Stages__:
* __Checkout Git Server and Deploy__
    * At this stage the new configuration is pulled from bitbucket, a local version of gittea is created with the pulled changes from bitbucket. The gittea service is uploaded.
* __Health Check Git Server and Config Server__
    * At this stage the gittea service is up and running so its health is checked to make sure everything is running correctly.
* __Refresh Instances__
    * At this stage each instance of the application whose configurations changed must be refreshed with the new properties. This is done currently by calling the refresh endpoint. 
