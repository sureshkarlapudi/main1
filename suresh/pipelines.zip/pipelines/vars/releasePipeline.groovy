def call() {

    def gitUtil = new org.mastercard.alberta.GitUtil(this)
    def pcfUtil = new org.mastercard.pipeline.utility.PCFUtil(this)
    def albertaPCFUtil = new org.mastercard.alberta.AlbertaPCFUtil(this)
    def commonUtil = new org.mastercard.alberta.CommonUtil(this)
    def emailUtil = new org.mastercard.alberta.EmailUtil(this)
    def artifactoryUtil = new org.mastercard.alberta.ArtifactoryUtil(this)
    def qaUtil = new org.mastercard.alberta.QAUtil(this)
    def caasUtil = new org.mastercard.pipeline.utility.CaaSUtil(this)
    def autoscaleUtil = new org.mastercard.pipeline.utility.AutoscaleUtil(this)
    def fileUtil = new org.mastercard.pipeline.utility.FileUtil(this)
    def setEnvironmentVars = new org.mastercard.alberta.SetEnvironmentVarsUtil(this)
    def contractTestingUtil = new org.mastercard.alberta.ContractTestingUtil(this)
    def contractMap = [:]
    def keyMap = [:]
    def envVar = [:]
    def blueGreenDeployer
    def e2eTearDown = false
    def appRollBack = false
    def startStage = ""
    def endStage = ""
    def selectedEnvironment = params.Environment
  	def releasePipeline = true

    def PROD_ENVIRONMENT = "prod-release"
    def PRE_PROD_ENVIRONMENT = "pre-prod-release"
    def PERFORMANCE_ENVIRONMENT = "perf-release"
    def VALIDATION_JOB_TYPE = "validation"
    def MTF_ENVIRONMENT = "src-mtf-release"
    def SRCINT_ENVIRONMENT = "src-int-release"
    def SRCPRERELEASE_ENVIRONMENT = "src-prerelease-release"
    def SRC_PROD_ENVIRONMENT = "src-prod-release"

    // Setting up Dynamic Jenkins Agents
    def HIGHER_ENVIRONMENTS = [PRE_PROD_ENVIRONMENT, PROD_ENVIRONMENT, MTF_ENVIRONMENT, SRC_PROD_ENVIRONMENT]
    env.GRADLE_LABEL = HIGHER_ENVIRONMENTS.contains(selectedEnvironment) ? "GRADLE" : "DTL-GRADLE"
    env.CF_CLI_LABEL = HIGHER_ENVIRONMENTS.contains(selectedEnvironment) ? "CF-CLI" : "DTL-CF-CLI"
    env.CAAS_CLIENT_LABEL = HIGHER_ENVIRONMENTS.contains(selectedEnvironment) ? "CAAS_CLIENT" : "DTL-CAAS-CLIENT"

    pipeline {
        agent { label "${GRADLE_LABEL}" }
        options {
            buildDiscarder(logRotator(numToKeepStr: '5'))
            skipDefaultCheckout()
            timestamps()
            disableConcurrentBuilds()
            timeout(time: 2, unit: 'HOURS')
        }
        environment {
            BROWSERSTACK_KEY = credentials('BrowserStackKey')
            BROWSERSTACK_USER = credentials('BrowserStackUser')
            CF_DIAL_TIMEOUT = 15
        }
        parameters {
            /* Below environment variables need to be defined at Jenkins job configuration level accordingly, for Release Pipeline.
            *
            *      ChangeRequestID = "CHG12345"
            *      ArtifactName = "durable-data-service-1.0-20180511.224921-1.jar"
            *      Environment = "pre-prod-release" or "prod-release" or "perf-release"
            *      e2eReleaseTag = "release/alpha"
            */
            choice(choices: 'DISABLE\nENABLE', description: "Please select 'DISABLE' option to exclude E2E Stage", name: 'EXECUTE_E2E_STAGE')
        }
        stages {
             stage('Checkout') {
                steps {
                    script {
                        deleteDir()  
                        gitUtil.customCheckout( this, releasePipeline, selectedEnvironment, env.ChangeRequestID )
                        env.STAGE_STATUS = "SCM_CHECKOUT"
                    }
                }
            }
            stage('Initialize Environment') {
                steps {
                    script {
                         
                        commonUtil.echoSteps("Reading pipelinecofig.yml file")
                        def pipelineConfigData = fileUtil.readPipelineConfig()

                        commonUtil.echoSteps("Reading environmentconfig.yml")
                        def envConfiguration = fileUtil.readEnvironmentsConfig()

                        commonUtil.echoSteps("Inspecting the current configuration parameters...")
                        steps.sh 'pwd'
                        steps.sh 'ls -avlh'
                        commonUtil.echoSteps("Pipeline Config file: ${pipelineConfigData}")
                        commonUtil.echoSteps("Environment Config file: ${envConfiguration}")

                        commonUtil.echoSteps("Current git branch: - ${currentGitBranch}")

                        setEnvironmentVars.setDefaultVars()

                        if( selectedEnvironment == PRE_PROD_ENVIRONMENT ) {
                            setEnvironmentVars.setPreProdVars()
                        } else if( selectedEnvironment == PROD_ENVIRONMENT ) {
                            setEnvironmentVars.setProdVars()
                        } else if (selectedEnvironment == PERFORMANCE_ENVIRONMENT) {
                            setEnvironmentVars.setPerfVars()
                        }else if (selectedEnvironment == SRCINT_ENVIRONMENT) {
                            setEnvironmentVars.setSrcIntVars()
                        }else if (selectedEnvironment == SRCPRERELEASE_ENVIRONMENT) {
                            setEnvironmentVars.setSrcPreReleaseVars()
                        }else if (selectedEnvironment == MTF_ENVIRONMENT) {
                            setEnvironmentVars.setMtfVars()
                        }else if (selectedEnvironment == SRC_PROD_ENVIRONMENT) {
                            setEnvironmentVars.setSrcProdVars()
                        }

                        if(env.jobType == VALIDATION_JOB_TYPE){
                            setEnvironmentVars.setValidationJobVars(VALIDATION_JOB_TYPE)
                        }

                        APP_HOST_NAME = PCF_DEV_SPACE + '-' + pipelineConfigData.pipeline.hostname
                        env.SERVICE_TYPE = pipelineConfigData.pipeline.serviceType
                      	
                        commonUtil.echoSteps("\nGlobal Envionment Veriables: \n\nPCF Foundation: ${PCF_FOUNDATION} \nPCF ORG: ${PCF_ORG} \nPCF Dev space: ${PCF_DEV_SPACE} \nPCF Credential ID: ${PCF_CREDENTIALS} \nStash Credential ID: ${STASH_CREDENTIALS} \nArtifactory Credential ID: ${ARTIFACTORY_CREDENTIALS} \nSonar Credential ID: ${SONAR_CREDENTIALS} \nStage Branch Name: ${INTEGRATION_BRANCH} \nSynapse Client Name: ${SYNAPSE_CLIENT_NAME} \nEntry URL: ${ENTRY_URL} \nApp Host Name: ${APP_HOST_NAME} \nBuild and Test execution: ${BUILD_TEST_EXECUTION}\nSERVICE_TYPE: ${SERVICE_TYPE}\nGRADLE LABEL: ${GRADLE_LABEL}\nCAAS-CLIENT LABEL: ${CAAS_CLIENT_LABEL}\nCF-CLI LABEL: ${CF_CLI_LABEL}")

                        if(null == env.startStage){
                            commonUtil.echoSteps("WARNING: No environment start stage found. Replacing value with zero.")
                            env.startStage = 0
                        }

                        startStage = "${env.startStage}".toInteger()

                        if(null == env.endStage){
                            commonUtil.echoSteps("WARNING: No environment end stage found. Replacing value with zero.")
                            env.endStage = 0
                        }

                        endStage = "${env.endStage}".toInteger()
                        

                        env.STAGE_STATUS = "INITIALIZE_ENV"
                        steps.sh "printenv"
                       // contractMap = contractTestingUtil.backendCT(false ,STASH_CREDENTIALS , ORG_GRADLE_PROJECT_PACT_BROKER_URL,selectedEnvironment)

                        //doing for re-deployment on automatic build, currently only for stage
                        def versionDeployed = org.mastercard.pipeline.utility.AppInfoUtil.getBuildVersionOfRunningApp(this, APP_HOST_NAME, PCF_FOUNDATION, INFO_ENDPOINT)
                        def currentVersion = artifactoryUtil.getVersion()
                        if(!currentVersion.contains('SNAPSHOT') && !versionDeployed.contains('SNAPSHOT')) {
                            if (currentVersion == versionDeployed) {
                                //we will just start at getting certs
                                startStage = stages.getCertsForStage
                            }//else is a new deployment
                        }

                    }
                }
            }
            stage('Test') {
                steps {
                    script {
                        stageUnitTest(commonUtil)
                    }
                }
            }
            stage('Publish Pact') {
                when {
                    expression { SERVICE_TYPE == "consumer"  || SERVICE_TYPE == "consumer-provider"}
                }
                steps {
                    figlet "Pact Publish"
                    script{
                        try{
                            withCredentials([usernamePassword(credentialsId: 'pactbroker_credentials', passwordVariable: 'PB_PASSWORD', usernameVariable: 'PB_USERNAME')]) {
                                sh "$GRADLE4/bin/gradle pactPublish -Dusername=${PB_USERNAME} -Dpassword=${PB_PASSWORD}"
                            }
                            commonUtil.echoSteps("Publishing Pacts Completed Successfully")
                            env.STAGE_STATUS = "PUBLISH_PACT"
                        }
                        catch(e){throw e}
                    }
                }
            }
            stage('Retrieve Package from Artifactory') {  //TODO move this to checkout stage
                steps {
                    script {
                        
                        commonUtil.echoSteps("Retrieving Artifact from Artifactory")
                        //artifactoryUtil.artifactoryDownload(this, ARTIFACTORY_CREDENTIALS, selectedEnvironment)
                        artifactoryUtil.artifactoryDownloadFromURL(env.ARTIFACT_URL)
                        commonUtil.echoSteps("Artifact Package Successfully Retrieved from Artifactory")
                        
                        commonUtil.echoSteps("Renaming AppHostName in manifest.yml")
                        albertaPCFUtil.renameAppInManifest(APP_HOST_NAME)
                        sh "cat manifest.yml"

                        stash name: 'workspace'
                        commonUtil.echoSteps("Retrieved Artifact Package is Verified in the Workspace")
                        env.STAGE_STATUS = "RETRIEVE_PACKAGE"
                    }
                }
            }
            stage('Get Certs from CAAS') {
                agent { label "${CAAS_CLIENT_LABEL}" }
                steps {
                    script {
                        unstash 'workspace'
                        commonUtil.echoSteps("Fetching Certificates from CAAS")
                        caasUtil.getJKSFromCaaS(this, PCF_FOUNDATION, PCF_DEV_SPACE, keyMap, SYNAPSE_CLIENT_NAME)
                        commonUtil.echoSteps("Certificates Retrieved Successfully")
                        env.STAGE_STATUS = "GET_CERTS"
                    }
                }
            }
            stage('Deploy Green APP') {
                agent { label "${CF_CLI_LABEL}" }
                steps {
                    script {
                        unstash 'workspace'
                        commonUtil.echoSteps("Started Deploying Green Application")
                        commonUtil.echoSteps("Started Getting Environment Variables for Synapse")
                         envVar = org.mastercard.pipeline.utility.SynapseUtil.getEnvVar(this, keyMap, PCF_FOUNDATION, true)
                        commonUtil.echoSteps("Environment Variables for Synapse Successfully Set in map")
                        blueGreenDeployer = new org.mastercard.pipeline.deploy.BlueGreenDeployer(this, PCF_ORG, PCF_DEV_SPACE, PCF_CREDENTIALS, PCF_FOUNDATION)
                        //Pass custom live route to the method, if required. Default will be "green-<APP_NAME>".
                        blueGreenDeployer.deployGreenApp(null, envVar)
                        commonUtil.echoSteps("Green Application Deployed Successfully")
                        env.STAGE_STATUS = "DEPLOY_GREEN"
                    }
                }
            }
            stage('Integration Tests') {
                //   when {
                //      expression { selectStages(stages.integrationTestsStage, startStage, endStage) }
                //  }
                steps {
                    script {
                        commonUtil.echoSteps("Starting Integration Tests")
                        def pipelineConfigData = fileUtil.readPipelineConfig()
                        albertaPCFUtil.renameAppInManifest(pipelineConfigData.pipeline.hostname)
                        sh "cat manifest.yml"

                        contractMap = contractTestingUtil.backendCT(false ,STASH_CREDENTIALS , ORG_GRADLE_PROJECT_PACT_BROKER_URL,selectedEnvironment)
                        commonUtil.echoSteps("\nContract Map: ${contractMap}")
                        qaUtil.executeIntegrationTestsBackend(this, PCF_CREDENTIALS , false, keyMap)

                        commonUtil.echoSteps("Integration Tests Completed Successfully")
                        env.STAGE_STATUS = "INTEGRATION_TESTS"
                    }
                }
                post {
                    always{
                        script{
                            qaUtil.publishTestResults(this, "Integration Test", selectedEnvironment, "int", "build/reports/tests/integrationTest", "index.html")
                        }
                    }
                    failure{
                        script{
                            commonUtil.echoSteps("Renaming AppHostName in manifest.yml")
                            sh "ls -latr"
                            sh "cat manifest.yml"
                            def pipelineConfigData = fileUtil.readPipelineConfig()
                            albertaPCFUtil.renameAppInManifest(APP_HOST_NAME)
                            blueGreenDeployer = new org.mastercard.pipeline.deploy.BlueGreenDeployer(this, PCF_ORG, PCF_DEV_SPACE, PCF_CREDENTIALS, PCF_FOUNDATION)
                            blueGreenDeployer.deleteGreenApp(true)
                            albertaPCFUtil.renameAppInManifest(pipelineConfigData.pipeline.hostname)
                            sh "cat manifest.yml"
                        }
                    }
                }
            }
            stage('Pact Verification') {
                when {
                    expression { ("${contractMap['statusCodeProvider']}" == '0' || "${contractMap['statusCodeConsumerProvider']}" == '0')}
                }
                steps {
                    script{
                        commonUtil.echoSteps("Renaming AppHostName in manifest.yml")
                        albertaPCFUtil.renameAppInManifest(APP_HOST_NAME)
                        contractTestingUtil.pactVerify(selectedEnvironment)
                        commonUtil.echoSteps("Verifying Pacts Completed")
                        env.STAGE_STATUS = "VERIFY_PACT"
                    }
                }
                post {
                    failure{
                        script{
                            sh "ls -latr"
                            sh "cat manifest.yml"
                            def pipelineConfigData = fileUtil.readPipelineConfig()
                            commonUtil.echoSteps("Renaming AppHostName in manifest.yml")
                            albertaPCFUtil.renameAppInManifest(APP_HOST_NAME)
                            blueGreenDeployer = new org.mastercard.pipeline.deploy.BlueGreenDeployer(this, PCF_ORG, PCF_DEV_SPACE, PCF_CREDENTIALS, PCF_FOUNDATION)
                            blueGreenDeployer.deleteGreenApp(true)
                            albertaPCFUtil.renameAppInManifest(pipelineConfigData.pipeline.hostname)
                            sh "cat manifest.yml"
                        }
                    }
                }
            }
            stage('Flip Traffic to New Live APP') {
                agent { label "${CF_CLI_LABEL}" }
                steps {
                    script {
                        commonUtil.echoSteps("Started Flipping Traffic")
                        unstash 'workspace'

                        //def map = ['ENABLE_LOCUS_INIT':'true']
                        appRollBack = true
                        //Pass custom live route to the method, if required."
                        blueGreenDeployer.flipTraffic()

                        commonUtil.echoSteps("Traffic Successfully Flipped to New Live Application")
                        env.STAGE_STATUS = "FLIP_TRAFFIC"
                    }
                }
            }
            stage('Autoscale Application') {
                agent { label "${CF_CLI_LABEL}" }
                
                steps {
                    script {
                        unstash 'workspace'
                        commonUtil.echoSteps("Started Applying Auto-scaling Rules")
                      
                       albertaPCFUtil.renameAppInManifest(APP_HOST_NAME)
                       autoscaleUtil.autoscaleApplication(PCF_ORG, PCF_DEV_SPACE, PCF_CREDENTIALS, PCF_FOUNDATION, true)

                        //commonUtil.echoSteps("Auto-scaling Rules Successfully Applied to New Live Application")
                        env.STAGE_STATUS = "AUTOSCALE_APP"
                    }
                }
            }
            stage('Execute E2E Tests') {
                when {
                    expression {(selectedEnvironment=="pre-prod-release" || selectedEnvironment=="perf-release") && params.EXECUTE_E2E_STAGE == "ENABLE"}
                }
                steps {
                    script {
                        commonUtil.echoSteps("Executing E2E Tests")

                        qaUtil.executeE2ETests(this, PCF_CREDENTIALS, PCF_DEV_SPACE, ENTRY_URL, false)

                        commonUtil.echoSteps("E2E Tests Executed Successfully")
                        env.STAGE_STATUS = "E2E_TESTS"
                    }
                }
                post {
                    always{
                        script{
                            qaUtil.publishTestResults(this, "E2E", selectedEnvironment, "e2e", "extentreports", "report.html")
                        }
                    }
                }
            }
        } 
        post {
            /*failure{
                script{
                    if(appRollBack){
                        pcfUtil.appRollBack(this, envVar, artifactUpload)
                        commonUtil.echoSteps("Rolled back to previous version")

                    }
                }
            }
            success{
                script{
                    echo "Deleting the old back up file"
                    pcfUtil.deleteOldBackApp(this)
                    commonUtil.echoSteps("Deleted the old back up file")
                }
            } */
            always {
                script {
                    echo "Deleting the old back up file"
                    pcfUtil.deleteOldBackApp(this)
                    commonUtil.echoSteps("Deleted the old back up file")

                    if(e2eTearDown){
                        // Tearing down E2E Environment
                        albertaPCFUtil.deleteAppsDeployed(this, PCF_CREDENTIALS)
                        albertaPCFUtil.deletePcfServiceInstance(this, PCF_CREDENTIALS)
                    }
                    if ( selectedEnvironment == PROD_ENVIRONMENT || selectedEnvironment == PRE_PROD_ENVIRONMENT || selectedEnvironment == MTF_ENVIRONMENT)  {
                        emailUtil.prepareReleaseEmailNotification(this, STASH_CREDENTIALS, "${selectedEnvironment}", "${currentBuild.currentResult}")
                    } else {
                        emailUtil.prepareEmailNotification(this, STASH_CREDENTIALS, "${selectedEnvironment}", "${currentBuild.currentResult}")
                    }

                    commonUtil.echoSteps("Emptying current workspace directory")
                    deleteDir()

                    commonUtil.echoSteps("Sending ${currentBuild.currentResult} Notification Email")
                    emailext (
                            to: "${env.RECIPIENTS}",
                            subject: "${env.EMAIL_SUBJECT}",
                            body: "${env.EMAIL_BODY}"
                    )
                }
            }
            changed {
                script {
                    commonUtil.echoSteps("Sending Status Change Notification Email")
                    emailext (
                            to: "${env.PR_REVIEWERS}",
                            subject: "BUILD CHANGED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
                            body: "${env.STATUS_EMAIL_BODY}"
                    )
                }
            }
        }
    }
}
