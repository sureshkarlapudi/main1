class global implements Serializable {
//############# DEPRECATED ################
    public static String devServerJurisdictionId = '2c338a4eb73ac86e34d7fe7ef0b0f13dbd45b6f4'
    public static String stageServerJurisdictionId = '42c8cfcd605d8a74653ff12719901a69cbfe1a3e'
    public static String prodServerJurisdictionId = 'c6b808834388aa7836712cc91a2a8ede88dda98c'
    public static String devClientJurisdictionId = '2c338a4eb73ac86e34d7fe7ef0b0f13dbd45b6f4'
    public static String stageClientJurisdictionId = '42c8cfcd605d8a74653ff12719901a69cbfe1a3e'
    public static String prodClientJurisdictionId = 'c6b808834388aa7836712cc91a2a8ede88dda98c'
    public static String devServerProfileId = 'A18FC3E6643DA8'
    public static String stageServerProfileId = 'A9EAC4066441A1'
    public static String prodServerProfileId = 'A9A325D66438'
    public static String devClientProfileId = 'A18FC3E6643DA9'
    public static String stageClientProfileId = 'A9EAC406643D'
    public static String prodClientProfileId = 'A9A325D66437'
//##########################################
    public static String devCaaSEndpoint = 'https://dev.caas.mastercard.int:16181/v2/'
    public static String stageCaaSEndpoint = 'https://stage.caas.mastercard.int:16181/v2/'
    public static String prodCaaSEndpoint = 'https://stl.caas.mastercard.int:16181/v2/'
    public static String devDomain = "apps.stl.pcfdev00.mastercard.int"
    public static String stageDomain = "apps.stl.pcfstage00.mastercard.int"
    public static String prodDomain = "apps.bel.pcfprod00.mastercard.int"
    public static String devPaas_url = 'api.system.stl.pcfdev00.mastercard.int'
    public static String stagePaas_url = 'api.system.stl.pcfstage00.mastercard.int'
    public static String prodPaas_url = 'api.system.bel.pcfprod00.mastercard.int'
    //public static String sonarTestTrustStore = "/apps_data_01/security/keystores/cacerts-stage/cacerts"
    public static String sonarTestTrustStore = "/etc/pki/ca-trust/extracted/java/cacerts"

    public static String stl_devSynapseClientJurisdictionId = '2c338a4eb73ac86e34d7fe7ef0b0f13dbd45b6f4'
    public static String stl_devSynapseClientProfileId = 'A18FC3E6643DA9'
    public static String stl_devOtherClientJurisdictionId = '2c338a4eb73ac86e34d7fe7ef0b0f13dbd45b6f4'
    public static String stl_devOtherClientProfileId = 'A18FC3E6643DA9'

    public static String stl_stageSynapseClientJurisdictionId = '0e826832595fa83c483d6c0837d3a4a546d2683d'
    public static String stl_stageSynapseClientProfileId = 'A9EAC406643D'
    public static String stl_stageOtherClientJurisdictionId = '42c8cfcd605d8a74653ff12719901a69cbfe1a3e'
    public static String stl_stageOtherClientProfileId = 'A9EAC406643D'

    public static String bel_prodSynapseClientJurisdictionId = '4d7f0a7c3a7e01096c90df4207c7208a30b48e09'
    public static String bel_prodSynapseClientProfileId = 'A9A325D66437'
    public static String bel_prodOtherClientJurisdictionId = 'c6b808834388aa7836712cc91a2a8ede88dda98c'
    public static String bel_prodOtherClientProfileId = 'A9A325D66437'

    //new vars to differentiate prod
    public static String stl_devDomain = "apps.stl.pcfdev00.mastercard.int"
    public static String stl_stageDomain = "apps.stl.pcfstage00.mastercard.int"
    public static String bel_prodDomain = "apps.bel.pcfprod00.mastercard.int"
    public static String stl_prodDomain = "apps.stl.pcfprod00.mastercard.int"

    public static String stl_system_devDomain = "apps.system.stl.pcfdev00.mastercard.int"
    public static String stl_system_stageDomain = "apps.system.stl.pcfstage00.mastercard.int"
    public static String bel_system_prodDomain = "apps.system.bel.pcfprod00.mastercard.int"
    public static String stl_system_prodDomain = "apps.system.stl.pcfprod00.mastercard.int"

    public static String stl_devPaas_url = 'api.system.stl.pcfdev00.mastercard.int'
    public static String stl_stagePaas_url = 'api.system.stl.pcfstage00.mastercard.int'
    public static String bel_prodPaas_url = 'api.system.bel.pcfprod00.mastercard.int'
    public static String stl_prodPaas_url = 'api.system.stl.pcfprod00.mastercard.int'

    // Pact Broker defaults
    public static String pr_pactBrokerURL = "https://pr-int-pact-broker.apps.stl.pcfstage00.mastercard.int:443"
    public static String stage_pactBrokerURL = "https://int-pact-broker.apps.stl.pcfstage00.mastercard.int:443"
    public static String srcint_pactBrokerURL = "https://src-int-pact-broker.apps.stl.pcfstage00.mastercard.int:443"
    public static String mtf_pactBrokerURL = "https://src-mtf-pact-broker.apps.stl.pcfprod00.mastercard.int:443"
    public static String srcprerelease_pactBrokerURL = "https://src-pre-release-pact-broker.apps.stl.pcfstage00.mastercard.int:443"
    public static String preprod_pactBrokerURL = "https://pre-prod-pact-broker.apps.stl.pcfprod00.mastercard.int:443"
    public static String perf_pactBrokerURL = "https://src-stage-pact-broker.apps.stl.pcfstage00.mastercard.int:443"
    public static String prod_pactBrokerURL = "https://prod-pact-broker.apps.stl.pcfprod00.mastercard.int:443"
    public static String preprodKSC_pactBrokerURL = "https://prod-pact-broker.apps.ksc.pcfprod00.mastercard.int:443"
    public static String prodKSC_pactBrokerURL = "https://prod-pact-broker.apps.ksc.pcfprod00.mastercard.int:443"
    public static String src_prod_pactBrokerURL = "https://src-prod-pact-broker.apps.stl.pcfprod00.mastercard.int:443"

    public static String pr_pactBrokerHost = "https://pr-int-pact-broker.apps.stl.pcfstage00.mastercard.int"
    public static String stage_pactBrokerHost = "https://int-pact-broker.apps.stl.pcfstage00.mastercard.int"
    public static String preprod_pactBrokerHost = "https://pre-prod-pact-broker.apps.stl.pcfprod00.mastercard.int"
    public static String perf_pactBrokerHost = "https://src-stage-pact-broker.apps.stl.pcfstage00.mastercard.int"
    public static String prod_pactBrokerHost = "https://prod-pact-broker.apps.stl.pcfprod00.mastercard.int"
    public static String preprodKSC_pactBrokerHost = "https://prod-pact-broker.apps.ksc.pcfprod00.mastercard.int"
    public static String prodKSC_pactBrokerHost = "https://prod-pact-broker.apps.ksc.pcfprod00.mastercard.int"
    public static String src_prod_pactBrokerHost = "https://src-prod-pact-broker.apps.stl.pcfprod00.mastercard.int"

    public static String providerHost = "apps.stl.pcfstage00.mastercard.int"
    public static String preprodAndprodproviderHost = "apps.stl.pcfprod00.mastercard.int"
    public static String preprodAndProdKSCproviderHost = "apps.ksc.pcfprod00.mastercard.int"
    public static String providerPort = '443'
    public static String providerProtocol = 'https'

    // Artifactory URL
    public static String artifactory_url = "https://artifacts.mastercard.int/artifactory"

    //Lighthouse
    public static String varys_stage_lightHouseURL = "https://stage.varys.masterpass.com/?data=eyJjYXJkIjp7ImlkIjoiN2JhMjQzMTktY2FkNy00OGZhLWE5MjEtZWZlYzJmOGE4ZWMwIiwic3VmZml4IjoiMTIzNCIsImFydFVybCI6Imh0dHBzOi8vc3RhZ2UzLndhbGxldC5tYXN0ZXJwYXNzLmNvbS9saWdodGJveC9jYXJkYnJhbmRpbWFnZXMvTWFzdGVyY2FyZF9BbGJlcnRhLnN2ZyJ9LCJjb3JyZWxhdGlvbi1pZCI6IjZmMWZjYWQyLTk3YzAtNGMxZC05MjMzLTU5MTE1NTI3N2ZiMiIsInJlY2VpdmVyQ2xpZW50SWQiOiIxMTExMTEiLCJtZXJjaGFudCI6eyJhbW91bnQiOjE1MCwiYWxsb3dlZENhcmRUeXBlcyI6WyJtYXN0ZXJjYXJkIiwiYW1lcmljYW4tZXhwcmVzcyIsImRpbmVycy1jbHViIiwiZGlzY292ZXIiLCJqY2IiLCJtYWVzdHJvIiwidmlzYSJdLCJjdXJyZW5jeSI6IlVTRCIsIm5hbWUiOiJUZXN0IE1lcmNoYW50IiwidHJhbnNhY3Rpb25PcHRpb25zIjp7ImNyeXB0b2dyYW1Gb3JtYXQiOltdLCJjdmMyU3VwcG9ydGVkIjpmYWxzZSwidWNhZkJ5cGFzc1RUTE1pbnV0ZXMiOiIxNSIsInVucHJlZGljdGFibGVOdW1iZXIiOm51bGwsImZwYW5SZXF1ZXN0ZWQiOmZhbHNlLCJkdXJiaW5SaWdodHNSZXF1ZXN0ZWQiOmZhbHNlfSwidmFsaWRpdHlQZXJpb2RNaW51dGVzIjoxNSwic3VwcHJlc3NTaGlwcGluZyI6ZmFsc2V9LCJjYWxsYmFja1VybCI6Imh0dHBzOi8vc3JjLXN0YWdlLWNlcnNlaS5hcHBzLnN0bC5wY2ZzdGFnZTAwLm1hc3RlcmNhcmQuaW50L2NhbGxiYWNrP3NyY2lUeElkPWFsYmJlZmU3NjI5NDAzZTU4OGI3NzE2MmQyNmQyOWQzMWU0NTFiYjFhOTUiLCJsb2NhbGUiOiJlbi1VUyIsImp3dCI6ImV5SmhiR2NpT2lKU1V6STFOaUo5LmV5SnpkV0lpT2lKTllYTjBaWEp3WVhOeklFTnNZV2x0SWl3aVkyRnlaRWxrSWpvaU4ySmhNalF6TVRrdFkyRmtOeTAwT0daaExXRTVNakV0WldabFl6Sm1PR0U0WldNd0lpd2lhWE56SWpvaVRXRnpkR1Z5WTJGeVpDSXNJbU52Y25KbGJHRjBhVzl1U1dRaU9pSTJaakZtWTJGa01pMDVOMk13TFRSak1XUXRPVEl6TXkwMU9URXhOVFV5TnpkbVlqSWlMQ0psZUhBaU9qRTFOREF6TWpRNE56SXNJbWxoZENJNk1UVTBNRE15TXprM01uMC5iRi9DN1JTQVdpWmxxYUJhcHh6T0tSeG11YXo0dklxMDZzNzJldlFNZnJ4ck1aRlRMT0hES3hQWGsrR2dNSHp4Mmk2SU9SbnVXK1dISXlvbWZQWWtqNWR3S2xiRHpsdjEwZXFSSXpobU91MTEyK1V2RUI1SkZwcGxGWUlMdGhWKzlPK2NKd0tRUVVtNUM3UUQ2K294L09EVGdnZS85cVZmUE9aSXpOcTNDQkpYdDlSWWxqMjQ1TGtNT01JZC9JdGkwbVVoRElhb2tIc3haWVVRV2tDMTltQTZ2bnd0N0krWkdpaGpVaG5GWExQMm9mMkRNaENpSlJYYzNZbjhieEw0NnpESlRDNWdIdHJjeEhNVlNmN2FRK24yV1FGcEhkcFZ4bW9mbTRUTWZocDNTUzhPNW9jM1p4bDBRREI2UlJQLzVweW9GbEdlM2UwYXZyTnVjSnc3U2c9PSIsImFjdGlvbiI6ImVucm9sbCJ9"
    public static String cersei_stage_lightHouseURL = "https://stage.cersei.masterpass.com/enroll/register"

    // Pipeline Config Server defaults
    public static String configRepoSCM = "https://globalrepository.mclocal.int/stash/scm/ALBERTA/config-repo.git"
    public static String branchConfigRepoSCM = "dev"
    public static String prConfigurationEnvironment = "stage"
    public static String stageConfigurationEnvironment = "stage"
    public static String preprodConfigurationEnvironment = "pre-prod"
    public static String prodConfigurationEnvironment = "prod"
    public static String perfConfigurationEnvironment = "perf"
    public static String gitEAServiceRepoSCM = "https://globalrepository.mclocal.int/stash/scm/alberta/pcf-git-service.git"
    public static String branchGitEAServiceRepoSCM = "master"

    //E2E
    public static String E2E_Env_Stage = "stage"
    public static String E2E_Env_PreProd = "pre-prod"
    public static String E2E_Env_Prod = "prod"
  	public static String E2E_Env_Perf = "src-perf"
  	public static String E2E_Env_Default = "e2e"

    public static String E2E_e2e_Merchant_URL = "https://e2e-mrt.apps.stl.pcfstage00.mastercard.int/#/standardCheckout"
    public static String E2E_Stage_Merchant_URL = "https://src-stage-merchant-reference-tool.apps.stl.pcfstage00.mastercard.int/#/standardCheckout"
    public static String E2E_perf_Merchant_URL = "https://src-perf-merchant-reference-tool.apps.stl.pcfstage00.mastercard.int/#/standardCheckout"
    public static String E2E_preprod_Merchant_URL = "https://pre-prod-merchant-reference-tool.apps.stl.pcfprod00.mastercard.int/#/standardCheckout"
    public static String E2E_prod_Merchant_URL = "https://prod-merchant-reference-tool.apps.stl.pcfprod00.mastercard.int/#/standardCheckout"

    public static String E2E_e2e_Varys_URL = "https://e2e-varys.apps.stl.pcfstage00.mastercard.int"
    public static String E2E_Stage_Varys_URL = "https://src-stage-varys.apps.stl.pcfstage00.mastercard.int"
    public static String E2E_perf_Varys_URL = "https://src-perf-varys.apps.stl.pcfstage00.mastercard.int"
    public static String E2E_preprod_Varys_URL = "https://pre-prod-varys.apps.stl.pcfprod00.mastercard.int"
    public static String E2E_prod_Varys_URL = "https://prod-varys.apps.stl.pcfprod00.mastercard.int"
    public static String E2E_mtf_Varys_URL = "https://src-mtf-varys.apps.stl.pcfprod00.mastercard.int"

    // ################ REFACTORED Global Vars - START

    //STL_PreProd
    public static String SRCI_LIBRARY_URL_STL_PreProd = "https://pre-prod-cersei.apps.stl.pcfprod00.mastercard.int/lib/srci.lib.js"
    public static String SRC_MARK_URL_STL_PreProd = "https://pre-prod-alberta-js.apps.stl.pcfprod00.mastercard.int/AlbertaFlag.png"
    public static String JS_LIBRARY_URL__STL_PreProd = "https://pre-prod-alberta-js.apps.stl.pcfprod00.mastercard.int/dist/alberta.js"

    //KSC_PreProd
    public static String SRCI_LIBRARY_URL_KSC_PreProd = "https://pre-prod-cersei.apps.ksc.pcfprod00.mastercard.int/lib/srci.lib.js"
    public static String SRC_MARK_URL_KSC_PreProd = "https://pre-prod-alberta-js.apps.ksc.pcfprod00.mastercard.int/AlbertaFlag.png"
    public static String JS_LIBRARY_URL__KSC_PreProd = "https://pre-prod-alberta-js.apps.ksc.pcfprod00.mastercard.int/dist/alberta.js"

    //BEL_PreProd
    public static String SRCI_LIBRARY_URL_BEL_PreProd = "https://pre-prod-cersei.apps.bel.pcfprod00.mastercard.int/lib/srci.lib.js"
    public static String SRC_MARK_URL_BEL_PreProd = "https://pre-prod-alberta-js.apps.bel.pcfprod00.mastercard.int/AlbertaFlag.png"
    public static String JS_LIBRARY_URL__BEL_PreProd = "https://pre-prod-alberta-js.apps.bel.pcfprod00.mastercard.int/dist/alberta.js"

    //STL_Prod
    public static String SRCI_LIBRARY_URL_STL_Prod = "https://prod-cersei.apps.stl.pcfprod00.mastercard.int/lib/srci.lib.js"
    public static String SRC_MARK_URL_STL_Prod = "https://prod-alberta-js.apps.stl.pcfprod00.mastercard.int/AlbertaFlag.png"
    public static String JS_LIBRARY_URL_STL_Prod = "https://prod-alberta-js.apps.stl.pcfprod00.mastercard.int/alberta.js"
    //public static String E2E_Env_Prod = "prod"

    //KSC_Prod
    public static String SRCI_LIBRARY_URL_KSC_Prod = "https://prod-cersei.apps.ksc.pcfprod00.mastercard.int/lib/srci.lib.js"
    public static String SRC_MARK_URL_KSC_Prod = "https://prod-alberta-js.apps.ksc.pcfprod00.mastercard.int/AlbertaFlag.png"
    public static String JS_LIBRARY_URL_KSC_Prod = "https://prod-alberta-js.apps.ksc.pcfprod00.mastercard.int/alberta.js"

    //STL_Prod
    public static String SRCI_LIBRARY_URL_BEL_Prod = "https://prod-cersei.apps.bel.pcfprod00.mastercard.int/lib/srci.lib.js"
    public static String SRC_MARK_URL_BEL_Prod = "https://prod-alberta-js.apps.bel.pcfprod00.mastercard.int/AlbertaFlag.png"
    public static String JS_LIBRARY_URL_BEL_Prod = "https://prod-alberta-js.apps.bel.pcfprod00.mastercard.int/alberta.js"

    // Direct CAAS BASE_URL
    public static String DEV_CAAS_BASE_URL = 'https://dev.caas.mastercard.int:16181/v2/'
    public static String STAGE_CAAS_BASE_URL = 'https://stage.caas.mastercard.int:16181/v2/'
    public static String STL_PROD_CAAS_BASE_URL = 'https://stl.caas.mastercard.int:16181/v2/'
    public static String KSC_PROD_CAAS_BASE_URL = 'https://ksc.caas.mastercard.int:16181/v2/'
    public static String BEL_PROD_CAAS_BASE_URL = 'https://caas.bel.mastercard.int:16181/v2/'

    // PAAS BASE DOMAIN URLs
    public static String DEV_PAAS_DOMAIN = "apps.stl.pcfdev00.mastercard.int"
    public static String STAGE_PAAS_DOMAIN = "apps.stl.pcfstage00.mastercard.int"
    public static String STL_PROD_PAAS_DOMAIN = "apps.stl.pcfprod00.mastercard.int"
    public static String KSC_PROD_PAAS_DOMAIN = "apps.ksc.pcfprod00.mastercard.int"
    public static String BEL_PROD_PAAS_DOMAIN = "apps.bel.pcfprod00.mastercard.int"

    public static String DEV_PAAS_URL = 'api.system.stl.pcfdev00.mastercard.int'
    public static String STAGE_PAAS_URL = 'api.system.stl.pcfstage00.mastercard.int'
    public static String STL_PROD_PAAS_URL = 'api.system.stl.pcfprod00.mastercard.int'
    public static String KSC_PROD_PAAS_URL = 'api.system.ksc.pcfprod00.mastercard.int'
    public static String BEL_PROD_PAAS_URL = 'api.system.bel.pcfprod00.mastercard.int'

    // PAAS SYSTEM DOMAIN
    public static String DEV_SYSTEM_STL_DOMAIN = "apps.system.stl.pcfdev00.mastercard.int"
    public static String STAGE_SYSTEM_STL_DOMAIN = "apps.system.stl.pcfstage00.mastercard.int"
    public static String PROD_SYSTEM_BEL_DOMAIN = "apps.system.bel.pcfprod00.mastercard.int"
    public static String PROD_SYSTEM_STL_DOMAIN = "apps.system.stl.pcfprod00.mastercard.int"
    public static String PROD_SYSTEM_KSC_DOMAIN = "apps.system.ksc.pcfprod00.mastercard.int"
    // ################ REFACTORED Global Vars - END

    // DYNATRACE ENV VARS
    public static Map[] DYNATRACE_ENV_VARS = [
        [name: 'HTTPS_PROXY', value: 'https://10.157.246.220:15774'],
        [name: 'HTTP_PROXY', value: 'http://10.157.246.220:15774'],
        [name: 'https_proxy', value: 'https://10.157.246.220:15774'],
        [name: 'http_proxy', value: 'http://10.157.246.220:15774'],
        [name: 'DT_PROXY', value: 'http://10.157.246.220:15774'],
        [name: 'NO_PROXY', value: 'mastercard.int,mastercard.org,mastercard.com'],
        [name: 'no_proxy', value: 'mastercard.int,mastercard.org,mastercard.com']
    ]

    public static Map pcfEnvMap = [
            'stl-dev': [
                    appDomain: devDomain,
                    paasUrl: devPaas_url
            ],
            'stl-stage': [
                    appDomain: stageDomain,
                    paasUrl: stagePaas_url
            ],
            'bel-prod': [
                    appDomain: prodDomain,
                    paasUrl: prodPaas_url
            ],
            'stl-prod': [
                    appDomain: stl_prodDomain,
                    paasUrl: stl_prodPaas_url
            ]
    ]
}
