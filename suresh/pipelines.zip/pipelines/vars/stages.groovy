class stages implements Serializable {

    //PR Stages
    public static int buildUnitTestsPR=1
    public static int publishPactPR=2
    public static int sonarQubeStaticCodeAnalysisPR=3
    public static int getCertsForPR=4
    public static int integrationTestsPR=5
    public static int pactVerifyPR=6
    public static int prepareE2ETestsPR=7
    public static int executeE2ETestsPR=8

    //Merge Stages
    public static int buildUnitTestsStage=9
    public static int sonarQubeStaticCodeAnalysisStage=10
    public static int publishToArtifactoryStage=11
    public static int getCertsForStage=12
    public static int deployGreenStage=13
    public static int publishPactStage=14
    public static int integrationTestsStage=15
    public static int pactVerifyStage=16
    public static int flipTrafficStage=17
    public static int autoscaleApplicationStage=18
    public static int executeE2ETestsStage=19

    //Pre-prod Stage OR Perf Stage
    public static int retreiveFromArtifactoryPreprodOrPerf=20
    public static int getCertsForPreprodOrPerf=21
    public static int deployGreenPreprodOrPerf=22
    public static int integrationTestsPreprodOrPerf=23
    public static int flipTrafficPreprodOrPerf=24
    public static int autoscaleApplicationPreprodOrPerf=25
    public static int executeE2ETestsPreprodOrPerf=26

    //Prod Stage
    public static int retreiveFromArtifactoryProd=27
    public static int getCertsForProd=28
    public static int deployGreenProd=29
    public static int integrationTestsProd=30
    public static int flipTrafficProd=31
    public static int autoscaleApplicationProd=32

}
