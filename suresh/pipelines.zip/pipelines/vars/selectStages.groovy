def call(int currentStage, int startStage, int endStage) {
    if (currentStage < startStage) {
        return false
    } else if ((startStage <= currentStage) && (currentStage <= endStage)) {
        return true
    } else if (currentStage > endStage) {
        return false
    }
}