def call(def commonUtil) {
	commonUtil.echoSteps("Executing Unit Tests")
    sh "$GRADLE4/bin/gradle check test"
    commonUtil.echoSteps("Unit Tests Passed Successfully")
    env.STAGE_STATUS = "UNIT_TESTS"
    
    commonUtil.echoSteps("Building the Repository")
    commonUtil.addResourceFiles() //Adding manifest, autoscale, pipelineconfig files to resources
    sh "$GRADLE4/bin/gradle clean build -x test"
    commonUtil.echoSteps("Build Completed Successfully")
    env.STAGE_STATUS = "BUILD_ARTIFACT"
}
