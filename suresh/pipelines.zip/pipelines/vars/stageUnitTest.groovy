def call(def commonUtil) {

    commonUtil.echoSteps("Executing Unit Tests")
    sh "$GRADLE4/bin/gradle clean check test"
    commonUtil.echoSteps("Unit Tests Passed Successfully")
    env.STAGE_STATUS = "UNIT_TESTS"
}
