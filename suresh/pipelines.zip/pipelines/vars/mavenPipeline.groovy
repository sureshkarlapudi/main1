def call() {

    def gitUtil = new org.mastercard.alberta.GitUtil(this)
    def pcfUtil = new org.mastercard.pipeline.utility.PCFUtil(this)
    def albertaPCFUtil = new org.mastercard.alberta.AlbertaPCFUtil(this)
    def commonUtil = new org.mastercard.alberta.CommonUtil(this)
    def emailUtil = new org.mastercard.alberta.EmailUtil(this)
    def artifactoryUtil = new org.mastercard.alberta.ArtifactoryUtil(this)
    def qaUtil = new org.mastercard.alberta.QAUtil(this)
    def caasUtil = new org.mastercard.pipeline.utility.CaaSUtil(this)
    def autoscaleUtil = new org.mastercard.pipeline.utility.AutoscaleUtil(this)
    def fileUtil = new org.mastercard.pipeline.utility.FileUtil(this)
    def setEnvironmentVars = new org.mastercard.alberta.SetEnvironmentVarsUtil(this)
    def contractTestingUtil = new org.mastercard.alberta.ContractTestingUtil(this)
    def contractMap = [:]
    def keyMap = [:]
    def envVar = [:]
    def blueGreenDeployer
    def e2eTearDown = false
    def appRollBack = false
    def artifactUpload = false
    def startStage = ""
    def endStage = ""
    def vaultEnabled = false

    def selectedEnvironment = params.Environment
    def timer = (env.BRANCH_NAME == 'master') ? 'H H(20-23) * * */2' : ''

    def PROD_ENVIRONMENT = "prod-release"
    def PRE_PROD_ENVIRONMENT = "pre-prod-release"
    def PERFORMANCE_ENVIRONMENT = "perf-release"
    def PARALLEL_EXECUTION = "parallel"
    def SERIAL_EXECUTION = "serial"
    def VALIDATION_JOB_TYPE = "validation"

    // Setting up Dynamic Jenkins Agents
    def HIGHER_ENVIRONMENTS = [PRE_PROD_ENVIRONMENT, PROD_ENVIRONMENT]
    env.GRADLE_LABEL = HIGHER_ENVIRONMENTS.contains(selectedEnvironment) ? "GRADLE" : "DTL-GRADLE"
    env.CF_CLI_LABEL = HIGHER_ENVIRONMENTS.contains(selectedEnvironment) ? "CF-CLI" : "DTL-CF-CLI"
    env.CAAS_CLIENT_LABEL = HIGHER_ENVIRONMENTS.contains(selectedEnvironment) ? "CAAS_CLIENT" : "DTL-CAAS-CLIENT"

    pipeline {
        agent { label "${GRADLE_LABEL}" }
        triggers {
            cron(timer)
        }
        options {
            buildDiscarder(logRotator(numToKeepStr: '5'))
            skipDefaultCheckout()
            timestamps()
            disableConcurrentBuilds()
            timeout(time: 2, unit: 'HOURS')
        }
        environment {

            BROWSERSTACK_KEY = credentials('BrowserStackKey')
            BROWSERSTACK_USER = credentials('BrowserStackUser')
            CF_DIAL_TIMEOUT = 15

        }
        stages {
            stage('Checkout') {
                steps {
                    script {
                        deleteDir()
                        gitUtil.customCheckout( this, PERFORMANCE_ENVIRONMENT, PRE_PROD_ENVIRONMENT, PROD_ENVIRONMENT, selectedEnvironment, env.ChangeRequestID )
                        env.STAGE_STATUS = "SCM_CHECKOUT"
                    }
                }
            }
            stage('Initialize Environment') {
                steps {
                    script {
                        commonUtil.echoSteps("Reading pipelinecofig.yml file")
                        def pipelineConfigData = fileUtil.readPipelineConfig()

                        commonUtil.echoSteps("Reading environmentconfig.yml")
                        def envConfiguration = fileUtil.readEnvironmentsConfig()

                        commonUtil.echoSteps("Inspecting the current configuration parameters...")
                        steps.sh 'pwd'
                        steps.sh 'ls -avlh'
                        commonUtil.echoSteps("Pipeline Config file: ${pipelineConfigData}")
                        commonUtil.echoSteps("Environment Config file: ${envConfiguration}")

                        commonUtil.echoSteps("Current git branch: - ${currentGitBranch}")

                        setEnvironmentVars.setDefaultVars()

                        if( selectedEnvironment == PRE_PROD_ENVIRONMENT ) {
                            setEnvironmentVars.setPreProdVars()
                        } else if( selectedEnvironment == PROD_ENVIRONMENT ) {
                            setEnvironmentVars.setProdVars()
                        } else if (selectedEnvironment == PERFORMANCE_ENVIRONMENT) {
                            setEnvironmentVars.setPerfVars()
                        } else if ( currentGitBranch == INTEGRATION_BRANCH) {
                            setEnvironmentVars.setStageVars()
                        } else if ( currentGitBranch != INTEGRATION_BRANCH ) {
                            setEnvironmentVars.setPrVars()
                        }

                        if(env.jobType == VALIDATION_JOB_TYPE){
                            setEnvironmentVars.setValidationJobVars(VALIDATION_JOB_TYPE)
                        }

                        APP_HOST_NAME = PCF_DEV_SPACE + '-' + pipelineConfigData.pipeline.hostname
                        env.APP_NAME = pipelineConfigData.pipeline.hostname
                        env.SERVICE_TYPE = pipelineConfigData.pipeline.serviceType

                        commonUtil.echoSteps("\nGlobal Envionment Veriables: \n\nPCF Foundation: ${PCF_FOUNDATION} \nPCF ORG: ${PCF_ORG} \nPCF Dev space: ${PCF_DEV_SPACE} \nPCF Credential ID: ${PCF_CREDENTIALS} \nStash Credential ID: ${STASH_CREDENTIALS} \nArtifactory Credential ID: ${ARTIFACTORY_CREDENTIALS} \nSonar Credential ID: ${SONAR_CREDENTIALS} \nStage Branch Name: ${INTEGRATION_BRANCH} \nSynapse Client Name: ${SYNAPSE_CLIENT_NAME} \nEntry URL: ${ENTRY_URL} \nApp Host Name: ${APP_HOST_NAME} \nBuild and Test execution: ${BUILD_TEST_EXECUTION}\nSERVICE_TYPE: ${SERVICE_TYPE}\nGRADLE LABEL: ${GRADLE_LABEL}\nCAAS-CLIENT LABEL: ${CAAS_CLIENT_LABEL}\nCF-CLI LABEL: ${CF_CLI_LABEL}")
                        
                        if(null == env.startStage){
                            commonUtil.echoSteps("WARNING: No environment start stage found. Replacing value with zero.")
                            env.startStage = 0
                        }

                        startStage = "${env.startStage}".toInteger()

                        if(null == env.endStage){
                            commonUtil.echoSteps("WARNING: No environment end stage found. Replacing value with zero.")
                            env.endStage = 0
                        }

                        endStage = "${env.endStage}".toInteger()
                        

                        env.STAGE_STATUS = "INITIALIZE_ENV"
                        steps.sh "printenv"

                        //doing for re-deployment on automatic build, currently only for stage
                        def versionDeployed = org.mastercard.pipeline.utility.AppInfoUtil.getBuildVersionOfRunningApp(this, APP_HOST_NAME, PCF_FOUNDATION, INFO_ENDPOINT)
                        def currentVersion = artifactoryUtil.getVersion()
                        if(!currentVersion.contains('SNAPSHOT') && !versionDeployed.contains('SNAPSHOT')) {
                            if (currentVersion == versionDeployed) {
                                //we will just start at getting certs
                                startStage = stages.getCertsForStage
                            }//else is a new deployment
                        }

                    }
                }
            }

            stage('Unit Test ') {
                steps {
                    script {
                        sh "$M3/bin/mvn -Dtest=*Test test -DfailIfNoTests=false"
                    }
                }
            }

            stage('Build ') {
                steps {
                    script {
                        sh "$M3/bin/mvn clean install"
                        stash includes: 'application/target/**/*,*.yml', name: 'build_workspace'
                    }
                }
            }
            stage('Sonar Qube Static Code Analysis Stage') {
                when {
                    expression { selectStages(stages.sonarQubeStaticCodeAnalysisStage, startStage, endStage) }
                }
                steps {
                    script {
                        commonUtil.echoSteps("Starting SonarQube Static Code Analysis")
                        withCredentials([usernamePassword(credentialsId: SONAR_CREDENTIALS, passwordVariable: 'SONAR_PASSWORD', usernameVariable: 'SONAR_USER')]) {
                            sh "$M3/bin/mvn sonar:sonar"
                            commonUtil.echoSteps("SonarQube Static Code Analysis Completed Successfully")
                            env.STAGE_STATUS = "SONAR_CHECK"
                        }
                    }
                }
            }
            stage('Get Certs For Stage') {
                agent { label "${CAAS_CLIENT_LABEL}" }
                when {
                    expression { selectStages(stages.getCertsForStage, startStage, endStage) }
                }
                steps {
                    script {
                        commonUtil.echoSteps("Fetching certificates from CAAS")
                        caasUtil.getJKSFromCaaS(this, PCF_FOUNDATION, PCF_DEV_SPACE, keyMap, SYNAPSE_CLIENT_NAME, APP_HOST_NAME )
                        commonUtil.echoSteps("Certificates retrieved successfully")
                        env.STAGE_STATUS = "GET_CERTS"
                    }
                }
            }
            // TODO : get command for maven pact publish
            stage('Publish Pact Stage') {
                when {
                    expression { selectStages(stages.publishPactStage, startStage, endStage) && (SERVICE_TYPE == "consumer"  || SERVICE_TYPE == "consumer-provider")}
                }
                steps {
                    figlet "Pact Publish"
                    script{
                        try{
                            withCredentials([usernamePassword(credentialsId: 'pactbroker_credentials', passwordVariable: 'PB_PASSWORD', usernameVariable: 'PB_USERNAME')]) {
                                sh "$M3/bin/mvn pact:publish -Dusername=${PB_USERNAME} -Dpassword=${PB_PASSWORD}"
                            }
                            commonUtil.echoSteps("Publishing Pacts Completed Successfully")
                            env.STAGE_STATUS = "PUBLISH_PACT"
                        }
                        catch(e){throw e}
                    }
                }
            }
            stage('Deploy Green Stage') {
                agent { label "${CF_CLI_LABEL}" }
                when {
                    expression { selectStages(stages.deployGreenStage, startStage, endStage) }
                }
                steps {
                    script {
                        unstash 'build_workspace' //TODO come up with packaging artifact along wit h manifest.yml files
                        sh "ls -ltr"
                        sh "ls -ltr application/target"
                        //  commonUtil.echoSteps("Retrieving manifest file")  // Make sure you download manifest before downloading artifact
                        // commonUtil.getManifest(artifactID)

                        // commonUtil.echoSteps("Retrieving Artifact from Artifactory")
                        //artifactoryUtil.artifactoryDownload(this, ARTIFACTORY_CREDENTIALS)
                        //commonUtil.echoSteps("Artifact Package Successfully Retrieved from Artifactory")

                        sh "cat manifest.yml"
                        commonUtil.echoSteps("Renaming AppHostName in manifest.yml")
                        albertaPCFUtil.renameAppInManifest(APP_HOST_NAME)
                        sh "cat manifest.yml"

                        commonUtil.echoSteps("Started Getting Environment Variables for Synapse")
                        if(APP_HOST_NAME.contains("card-art-service")) {
                            vaultEnabled = true
                        }
                        envVar = org.mastercard.pipeline.utility.SynapseUtil.getEnvVar(this, keyMap, PCF_FOUNDATION, true, vaultEnabled)
                        commonUtil.echoSteps("Environment Variables for Synapse Successfully Set in map")
                        blueGreenDeployer = new org.mastercard.pipeline.deploy.BlueGreenDeployer(this, PCF_ORG, PCF_DEV_SPACE, PCF_CREDENTIALS, PCF_FOUNDATION)
                        //Pass custom live route to the method, if required."
                        // envVar = ['ENABLE_LOCUS_INIT':'true']
                        println "this is apphostname ${APP_HOST_NAME}"
                        blueGreenDeployer.deployGreenApp(null, envVar)
                        commonUtil.echoSteps("Green Application Deployed Successfully")
                        env.STAGE_STATUS = "DEPLOY_GREEN"
                    }
                }
            }
             stage('Integration Tests Stage') {
                when {
                    expression { selectStages(stages.integrationTestsStage, startStage, endStage) }
                }
                steps {
                    script {
                        commonUtil.echoSteps("Starting Integration Tests")
                        contractMap = contractTestingUtil.backendCT(false ,STASH_CREDENTIALS , ORG_GRADLE_PROJECT_PACT_BROKER_URL)
                        qaUtil.executeIntegrationTestsBackend(this, PCF_CREDENTIALS , false, keyMap)

                        commonUtil.echoSteps("Integration Tests Completed Successfully")
                        env.STAGE_STATUS = "INTEGRATION_TESTS"
                    }
                }
                post {
                    always{
                        script{
                            stash includes: '**', name: 'int'
                            sh "$M3/bin/mvn clean install surefire-report:report-only"
                            echo "DONE"
                            qaUtil.publishTestResults(this, "Integration Test", "Stage", "int", "application/target/site", "surefire-report.html")
                        }
                    }
                    failure{
                        script{
                            commonUtil.echoSteps("Renaming AppHostName in manifest.yml")
                            sh "ls -latr"
                            sh "cat manifest.yml"
                            def pipelineConfigData = fileUtil.readPipelineConfig()
                            albertaPCFUtil.renameAppInManifest(APP_HOST_NAME)
                            blueGreenDeployer = new org.mastercard.pipeline.deploy.BlueGreenDeployer(this, PCF_ORG, PCF_DEV_SPACE, PCF_CREDENTIALS, PCF_FOUNDATION)
                            blueGreenDeployer.deleteGreenApp(true)
                            albertaPCFUtil.renameAppInManifest(pipelineConfigData.pipeline.hostname)
                            sh "cat manifest.yml"
                        }
                    }
                }
            }
            stage('Pact Verification Stage') {
                when {
                    expression { (selectStages(stages.pactVerifyStage, startStage, endStage)) && ("${contractMap['statusCodeProvider']}" == '0' || "${contractMap['statusCodeConsumerProvider']}" == '0')}
                }
                steps {
                    script{
                        commonUtil.echoSteps("Renaming AppHostName in manifest.yml")
                        albertaPCFUtil.renameAppInManifest(APP_HOST_NAME)
                        withCredentials([usernamePassword(credentialsId: 'pactbroker_credentials', passwordVariable: 'PB_PASSWORD', usernameVariable: 'PB_USERNAME')]) {
                            sh "$M3/bin/mvn pact:publish -Dusername=${PB_USERNAME} -Dpassword=${PB_PASSWORD}"
                        }
                        commonUtil.echoSteps("Verifying Pacts Completed")
                        env.STAGE_STATUS = "VERIFY_PACT"
                    }
                }
                post {
                    failure{
                        script{
                            sh "ls -latr"
                            sh "cat manifest.yml"
                            def pipelineConfigData = fileUtil.readPipelineConfig()
                            commonUtil.echoSteps("Renaming AppHostName in manifest.yml")
                            albertaPCFUtil.renameAppInManifest(APP_HOST_NAME)
                            blueGreenDeployer = new org.mastercard.pipeline.deploy.BlueGreenDeployer(this, PCF_ORG, PCF_DEV_SPACE, PCF_CREDENTIALS, PCF_FOUNDATION)
                            blueGreenDeployer.deleteGreenApp(true)
                            albertaPCFUtil.renameAppInManifest(pipelineConfigData.pipeline.hostname)
                            sh "cat manifest.yml"
                        }
                    }
                }
            }
            stage('Flip Traffic Stage') {
                agent { label "${CF_CLI_LABEL}" }
                when {
                    expression { selectStages(stages.flipTrafficStage, startStage, endStage) }
                }
                steps {
                    script {
                        commonUtil.echoSteps("Started Flipping Traffic")
                        
                        commonUtil.echoSteps("Retrieving manifest file")
                        commonUtil.getManifest(artifactID)

                        // Avoid restarting the App after flip
                        //def map = ['ENABLE_LOCUS_INIT':'true']

                        //Pass custom live route to the method, if required."
                        appRollBack = true
                        blueGreenDeployer.flipTraffic()

                        commonUtil.echoSteps("Traffic Successfully Flipped to New Live Application")
                        env.STAGE_STATUS = "FLIP_TRAFFIC"
                    }
                }
            }
            stage('Autoscale Application Stage') {
                agent { label "${CF_CLI_LABEL}" }
                when {
                    expression { selectStages(stages.autoscaleApplicationStage, startStage, endStage) }
                }
                steps {
                    script {
                        deleteDir()
                        unstash 'build_workspace'
                     //   commonUtil.echoSteps("Retrieving manifest file")
                     //   commonUtil.getManifest(artifactID)

                     //   commonUtil.echoSteps("Retrieving autoscale file")
                      //  commonUtil.getAutoscale(artifactID)

                        albertaPCFUtil.renameAppInManifest(APP_HOST_NAME)
                        autoscaleUtil.autoscaleApplication(PCF_ORG, PCF_DEV_SPACE, PCF_CREDENTIALS, PCF_FOUNDATION, true)

                        commonUtil.echoSteps("Auto-scaling Rules Successfully Applied to New Live Application")
                        env.STAGE_STATUS = "AUTOSCALE_APP"
                    }
                }
            }
           /* stage('Execute E2E Tests Stage') {
                when {
                    expression { selectStages(stages.executeE2ETestsStage, startStage, endStage) && params.EXECUTE_E2E_STAGE != "DISABLE" }
                }
                steps {
                    script {
                        commonUtil.echoSteps("Executing E2E Tests")

                        qaUtil.executeE2ETests(this, PCF_CREDENTIALS, PCF_DEV_SPACE, ENTRY_URL, false)

                        commonUtil.echoSteps("E2E Tests Executed Successfully")
                        env.STAGE_STATUS = "E2E_TESTS"
                    }
                }
                post {
                    always{
                        script{
                            qaUtil.publishTestResults(this, "E2E", "Stage", "e2e",'build/reports/allure-report', 'index.html')
                        }
                    }
                    failure{
                        script{
                            pcfUtil.setArtifactURL( this, null, artifactoryUtil.getArtifactVersion() )
                        }
                    }
                }
            } */
            stage('Publish To Artifactory Stage') {
                when {
                    expression { selectStages(stages.publishToArtifactoryStage, startStage, endStage) }
                }
                steps {
                    script {
                        unstash 'build_workspace'
                        sh "ls -ltr application/target"
                        commonUtil.echoSteps("Publishing Artifact to Artifactory")
                        artifactoryUtil.artifactoryUpload(this, ARTIFACTORY_CREDENTIALS)
                        pcfUtil.setArtifactURL(this)
                        commonUtil.echoSteps("Artifact Successfully Published to Artifactory")
                        env.STAGE_STATUS = "ARTIFACTORY_PUBLISH"
                    }
                }
            }

        }
        post {
            /*failure{
                script{
                    if(appRollBack){
                        pcfUtil.appRollBack(this, envVar, artifactUpload)
                        commonUtil.echoSteps("Rolled back to previous version")

                    }
                }
            }
            success{
                script{
                    echo "Deleting the old back up file"
                    pcfUtil.deleteOldBackApp(this)
                    commonUtil.echoSteps("Deleted the old back up file")
                }
            }*/
            always {
                script {
                    echo "Deleting the old back up file"
                    pcfUtil.deleteOldBackApp(this)
                    commonUtil.echoSteps("Deleted the old back up file")

                    if(e2eTearDown){
                        // Tearing down E2E Environment
                        albertaPCFUtil.deleteAppsDeployed(this, PCF_CREDENTIALS)
                        albertaPCFUtil.deletePcfServiceInstance(this, PCF_CREDENTIALS)
                    }
                    if ( selectedEnvironment == PROD_ENVIRONMENT || selectedEnvironment == PRE_PROD_ENVIRONMENT ) {
                        emailUtil.prepareReleaseEmailNotification(this, STASH_CREDENTIALS, "${selectedEnvironment}", "${currentBuild.currentResult}")
                    } else {
                        emailUtil.prepareEmailNotification(this, STASH_CREDENTIALS, "${selectedEnvironment}", "${currentBuild.currentResult}")
                    }

                    commonUtil.echoSteps("Emptying current workspace directory")
                    deleteDir()

                    commonUtil.echoSteps("Sending ${currentBuild.currentResult} Notification Email")
                    emailext (
                            to: "${env.RECIPIENTS}",
                            subject: "${env.EMAIL_SUBJECT}",
                            body: "${env.EMAIL_BODY}"
                    )
                }
            }
            changed {
                script {
                    commonUtil.echoSteps("Sending Status Change Notification Email")
                    emailext (
                            to: "${env.PR_REVIEWERS}",
                            subject: "BUILD CHANGED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
                            body: "${env.STATUS_EMAIL_BODY}"
                    )
                }
            }
        }
    }
}
