def call() {

    def gitUtil = new org.mastercard.alberta.GitUtil(this)
    def pcfUtil = new org.mastercard.pipeline.utility.PCFUtil(this)
    def albertaPCFUtil = new org.mastercard.alberta.AlbertaPCFUtil(this)
    def commonUtil = new org.mastercard.alberta.CommonUtil(this)
    def pipelineUtil = new org.mastercard.alberta.PipelineUtil(this)
    def emailUtil = new org.mastercard.alberta.EmailUtil(this)
    def artifactoryUtil = new org.mastercard.alberta.ArtifactoryUtil(this)
    def qaUtil = new org.mastercard.alberta.QAUtil(this)
    def caasUtil = new org.mastercard.pipeline.utility.CaaSUtil(this)
    def autoscaleUtil = new org.mastercard.pipeline.utility.AutoscaleUtil(this)
    def fileUtil = new org.mastercard.pipeline.utility.FileUtil(this)
    def setEnvironmentVars = new org.mastercard.alberta.SetEnvironmentVarsUtil(this)
    def contractTestingUtil = new org.mastercard.alberta.ContractTestingUtil(this)
    def contractMap = [:]
    def keyMap = [:]
    def envVar = [:]
    def blueGreenDeployer
    def e2eTearDown = false
    def appRollBack = false
    def artifactUpload = false
    def startStage = ""
    def endStage = ""

    def selectedEnvironment = params.Environment
    def timer = (env.BRANCH_NAME == 'master') ? 'H H(20-23) * * */2' : ''

    def PROD_ENVIRONMENT = "prod-release"
    def PRE_PROD_ENVIRONMENT = "pre-prod-release"
    def PERFORMANCE_ENVIRONMENT = "perf-release"
    def PARALLEL_EXECUTION = "parallel"
    def SERIAL_EXECUTION = "serial"
    def VALIDATION_JOB_TYPE = "validation"

    // Setting up Dynamic Jenkins Agents
    def HIGHER_ENVIRONMENTS = [PRE_PROD_ENVIRONMENT, PROD_ENVIRONMENT]
    env.GRADLE_LABEL = HIGHER_ENVIRONMENTS.contains(selectedEnvironment) ? "GRADLE" : "DTL-GRADLE"
    env.CF_CLI_LABEL = HIGHER_ENVIRONMENTS.contains(selectedEnvironment) ? "CF-CLI" : "DTL-CF-CLI"
    env.CAAS_CLIENT_LABEL = HIGHER_ENVIRONMENTS.contains(selectedEnvironment) ? "CAAS_CLIENT" : "DTL-CAAS-CLIENT"

    pipeline {
        agent { label "${GRADLE_LABEL}" }
        triggers {
            cron(timer)
        }
        options {
            buildDiscarder(logRotator(numToKeepStr: '5'))
            skipDefaultCheckout()
            timestamps()
            disableConcurrentBuilds()
            timeout(time: 2, unit: 'HOURS')
        }
        parameters {
            choice(name: 'EXECUTE_E2E_STAGE', choices: 'DISABLE\nENABLE', description: "Select 'DISABLE' option to exclude E2E Stage")
        }
        environment {
            BROWSERSTACK_KEY = credentials('BrowserStackKey')
            BROWSERSTACK_USER = credentials('BrowserStackUser')
            CF_DIAL_TIMEOUT = 15
        }
        stages {
            stage('Checkout') {
                steps {
                    script {
                        deleteDir()
                        gitUtil.customCheckout( this )
                        env.STAGE_STATUS = "SCM_CHECKOUT"
                        echo("source code checked out")
                    }
                }
            }
            stage('Calculate Semantic Version') {
                steps {
                    script {
                        env.STAGE_STATUS = "CALC_VERSION"
                        gitUtil.fetchTags()
                        org.mastercard.alberta.VersionTool.checkoutCanonicalVersion(this, gitUtil)

                        org.mastercard.alberta.VersionTool.setArtifactVersioningVars(this, gitUtil, artifactoryUtil)
                        echo(String.format("versions calculated: prev: %s, new: %s, found in file: %s",
                            env.PREV_TAG_VERSION, env.NEW_TAG_VERSION, env.VERSION_FROM_FILE) )

                        //sh pipelineUtil.scriptUpdateVersionInAppProps(env.NEW_TAG_VERSION)
                        sh pipelineUtil.scriptUpdateVersionInGradleBuild(env.NEW_TAG_VERSION)
                        sh pipelineUtil.scriptUpdateJarInManifest(
                            String.format("%s.jar", artifactoryUtil.generateArtifactBaseName(artifactID, env.NEW_TAG_VERSION))
                        )
                    }
                }
            }
            stage('Initialize Environment') {
                steps {
                    script {
                        commonUtil.echoSteps("Reading pipelinecofig.yml file")
                        def pipelineConfigData = fileUtil.readPipelineConfig()

                        commonUtil.echoSteps("Reading environmentconfig.yml")
                        def envConfiguration = fileUtil.readEnvironmentsConfig()

                        commonUtil.echoSteps("Inspecting the current configuration parameters...")
                        steps.sh 'pwd'
                        steps.sh 'ls -avlh'
                        commonUtil.echoSteps("Pipeline Config file: ${pipelineConfigData}")
                        commonUtil.echoSteps("Environment Config file: ${envConfiguration}")

                        commonUtil.echoSteps("Current git branch: - ${currentGitBranch}")

                        setEnvironmentVars.setDefaultVars()

                        if ( currentGitBranch == INTEGRATION_BRANCH) {
                            setEnvironmentVars.setStageVars()
                        } else if ( currentGitBranch != INTEGRATION_BRANCH ) {
                            setEnvironmentVars.setPrVars()
                        }

                        if(env.jobType == VALIDATION_JOB_TYPE){
                            setEnvironmentVars.setValidationJobVars(VALIDATION_JOB_TYPE)
                        }

                        APP_HOST_NAME = PCF_DEV_SPACE + '-' + pipelineConfigData.pipeline.hostname
                        env.SERVICE_TYPE = pipelineConfigData.pipeline.serviceType
                      	
                        commonUtil.echoSteps("\nGlobal Envionment Veriables: \n\nPCF Foundation: ${PCF_FOUNDATION} \nPCF ORG: ${PCF_ORG} \nPCF Dev space: ${PCF_DEV_SPACE} \nPCF Credential ID: ${PCF_CREDENTIALS} \nStash Credential ID: ${STASH_CREDENTIALS} \nArtifactory Credential ID: ${ARTIFACTORY_CREDENTIALS} \nSonar Credential ID: ${SONAR_CREDENTIALS} \nStage Branch Name: ${INTEGRATION_BRANCH} \nSynapse Client Name: ${SYNAPSE_CLIENT_NAME} \nEntry URL: ${ENTRY_URL} \nApp Host Name: ${APP_HOST_NAME} \nSRCi URL (Cersei): ${CERSEI_URL} \nDCF URL (Varys): ${VARYS_URL} \nBuild and Test execution: ${BUILD_TEST_EXECUTION} \nSERVICE_TYPE: ${SERVICE_TYPE} \nGRADLE LABEL: ${GRADLE_LABEL} \nCAAS-CLIENT LABEL: ${CAAS_CLIENT_LABEL} \nCF-CLI LABEL: ${CF_CLI_LABEL}")

                        if(null == env.startStage){
                            commonUtil.echoSteps("WARNING: No environment start stage found. Replacing value with zero.")
                            env.startStage = 0
                        }

                        startStage = "${env.startStage}".toInteger()

                        if(null == env.endStage){
                            commonUtil.echoSteps("WARNING: No environment end stage found. Replacing value with zero.")
                            env.endStage = 0
                        }

                        endStage = "${env.endStage}".toInteger()
                        
                        env.STAGE_STATUS = "INITIALIZE_ENV"
                        steps.sh "printenv"

                        //doing for re-deployment on automatic build, currently only for stage
                        def versionDeployed = org.mastercard.pipeline.utility.AppInfoUtil.getBuildVersionOfRunningApp(this, APP_HOST_NAME, PCF_FOUNDATION, INFO_ENDPOINT)
                        def currentVersion = artifactoryUtil.getVersion()
                        if(!currentVersion.contains('SNAPSHOT') && !versionDeployed.contains('SNAPSHOT')) {
                            if (currentVersion == versionDeployed) {
                                //we will just start at getting certs
                                startStage = stages.getCertsForStage
                            }//else is a new deployment
                        }
                    }
                }
            }
            stage('Test And Build PR: Parallel') {
                when {
                    expression { BUILD_TEST_EXECUTION == PARALLEL_EXECUTION && selectStages(stages.buildUnitTestsPR, startStage, endStage)}
                }
                failFast true
                parallel {
                    stage('Unit Tests PR: Parallel') {
                        steps {
                            script {
                                stageUnitTest(commonUtil)
                            }
                        }
                    }
                    stage('Build PR: Parallel') {
                        steps {
                            script {
                                stageBuild(commonUtil)
                            }
                        }
                    }
                }
            }
            stage('Test And Build PR: Serial') {
                when {
                    expression { BUILD_TEST_EXECUTION == SERIAL_EXECUTION && selectStages(stages.buildUnitTestsPR, startStage, endStage)}
                }
                steps {
                    script {
                        stageBuildUnitTest(commonUtil)
                    }
                }
            }
            stage('Publish Pact PR') {
                when {
                    expression { selectStages(stages.publishPactPR, startStage, endStage) && (SERVICE_TYPE == "consumer"  || SERVICE_TYPE == "consumer-provider")}
                }
                steps {
                    figlet "Pact Publish"
                    script{
                        try{
                            withCredentials([usernamePassword(credentialsId: 'pactbroker_credentials', passwordVariable: 'PB_PASSWORD', usernameVariable: 'PB_USERNAME')]) {
                                sh "$GRADLE4/bin/gradle pactPublish -Dusername=${PB_USERNAME} -Dpassword=${PB_PASSWORD}"
                            }
                            commonUtil.echoSteps("Publishing Pacts Completed Successfully")
                            env.STAGE_STATUS = "PUBLISH_PACT"
                        }
                        catch(e){throw e}
                    }
                }
            }
            stage('Sonar Qube Static Code Analysis PR') {
                when {
                    expression { selectStages(stages.sonarQubeStaticCodeAnalysisPR, startStage, endStage) }
                }
                steps {
                    script {
                        commonUtil.echoSteps("Starting SonarQube Static Code Analysis")
                        withCredentials([usernamePassword(credentialsId: SONAR_CREDENTIALS, passwordVariable: 'SONAR_PASSWORD', usernameVariable: 'SONAR_USER')]) {
                            sh "$GRADLE4/bin/gradle --info sonarqube"
                            commonUtil.echoSteps("SonarQube Static Code Analysis Completed Successfully")
                            env.STAGE_STATUS = "SONAR_CHECK"
                        }
                    }
                }
            }
            stage('Get Certs For PR') {
                agent { label "${CAAS_CLIENT_LABEL}" }
                when {
                    expression { selectStages(stages.getCertsForPR, startStage, endStage) }
                }
                steps {
                    script {
                        commonUtil.echoSteps("Fetching certificates from CAAS")
                        caasUtil.getJKSFromCaaS(this, PCF_FOUNDATION, PCF_DEV_SPACE, keyMap, SYNAPSE_CLIENT_NAME, APP_HOST_NAME)
                        commonUtil.echoSteps("Certificates retrieved successfully")
                        env.STAGE_STATUS = "GET_CERTS"
                    }
                }
            }
            stage('Integration Tests PR') {
                when {
                    expression { selectStages(stages.integrationTestsPR, startStage, endStage) }
                }
                steps {
                    script {
                        commonUtil.echoSteps("Starting Integration Tests")

                        contractMap = contractTestingUtil.backendCT(false ,STASH_CREDENTIALS , ORG_GRADLE_PROJECT_PACT_BROKER_URL)
                        commonUtil.echoSteps("\nContract Map: ${contractMap}")

                        if("${contractMap['statusCodeProvider']}" == '0' || "${contractMap['statusCodeConsumerProvider']}" == '0'){
                            qaUtil.executeIntegrationTestsBackend(this, PCF_CREDENTIALS , false, keyMap)
                        }else{
                            qaUtil.executeIntegrationTestsBackend(this, PCF_CREDENTIALS, true, keyMap)
                        }
                        commonUtil.echoSteps("Integration Tests Completed Successfully")
                        env.STAGE_STATUS = "INTEGRATION_TESTS"
                    }
                }
                post {
                    always{
                        script{
                            qaUtil.publishTestResults(this, "Integration Test", "PR", "int", "build/reports/tests/integrationTest", "index.html")
                        }
                    }
                }
            }
            stage('Pact Verification PR') {
                when {
                    expression { (selectStages(stages.pactVerifyPR, startStage, endStage)) && ("${contractMap['statusCodeProvider']}" == '0' || "${contractMap['statusCodeConsumerProvider']}" == '0')}
                }
                steps {
                    script{
                        contractTestingUtil.pactVerify()
                        commonUtil.echoSteps("Verifying Pacts Completed")
                        env.STAGE_STATUS = "VERIFY_PACT"
                    }
                }
                post {
                    always{
                        script{
                            commonUtil.echoSteps("Removing all the Apps deployed as a part of Integration Tests")
                            albertaPCFUtil.deleteAppsDeployed(this, PCF_CREDENTIALS, true)
                            commonUtil.echoSteps("Removed all deployed Apps Successfully")
                            commonUtil.echoSteps("Removing all the Services deployed as a part of Integration Tests")
                            albertaPCFUtil.deletePcfServiceInstance(this,PCF_CREDENTIALS, true)
                            commonUtil.echoSteps("Removed all deployed Services Successfully")
                        }
                    }
                }
            }
            stage('Prepare E2E Tests PR') {
                when {
                    expression { selectStages(stages.executeE2ETestsPR, startStage, endStage) }
                }
                steps {
                    script {
                        commonUtil.echoSteps("Preparing E2E Test Environment")
                        qaUtil.prepareForE2ETests(this, PCF_CREDENTIALS, null, keyMap)
                        commonUtil.echoSteps("E2E Test Environmnet Prepared Successfully")
                        e2eTearDown = true
                    }
                }
            }
            stage('Execute E2E Tests PR') {
                when {
                    expression { selectStages(stages.executeE2ETestsPR, startStage, endStage) }
                }
                steps {
                    script {
                        commonUtil.echoSteps("Executing E2E Tests")
                        qaUtil.executeE2ETests(this, PCF_CREDENTIALS, PCF_DEV_SPACE)
                        commonUtil.echoSteps("E2E Tests Executed Successfully")
                        env.STAGE_STATUS = "E2E_TESTS"
                    }
                }
                post {
                    always{
                        script{
                            qaUtil.publishTestResults(this, "E2E", "PR", "e2e",'build/reports/allure-report', 'index.html')
                        }
                    }
                }
            }
            stage('Test And Build Stage: Parallel') {
                when {
                    expression { BUILD_TEST_EXECUTION == PARALLEL_EXECUTION && selectStages(stages.buildUnitTestsStage, startStage, endStage)}
                }
                failFast true
                parallel {
                    stage('Unit Tests Stage: Parallel') {
                        steps {
                            script {
                                stageUnitTest(commonUtil)
                            }
                        }
                    }
                    stage('Build Stage: Parallel') {
                        steps {
                            script {
                                stageBuild(commonUtil)
                                stash includes: 'build/libs/**/*,manifest.yml', name: 'build_workspace'
                            }
                        }
                    }
                }
            }
            stage('Test And Build Stage: Serial') {
                when {
                    expression { BUILD_TEST_EXECUTION == SERIAL_EXECUTION && selectStages(stages.buildUnitTestsStage, startStage, endStage)}
                }
                steps {
                    script {
                        stageBuildUnitTest(commonUtil)
                        stash includes: 'build/libs/**/*,manifest.yml', name: 'build_workspace'
                    }
                }
            }
            stage('Sonar Qube Static Code Analysis Stage') {
                when {
                    expression { selectStages(stages.sonarQubeStaticCodeAnalysisStage, startStage, endStage) }
                }
                steps {
                    script {
                        commonUtil.echoSteps("Starting SonarQube Static Code Analysis")
                        withCredentials([usernamePassword(credentialsId: SONAR_CREDENTIALS, passwordVariable: 'SONAR_PASSWORD', usernameVariable: 'SONAR_USER')]) {
                            sh "$GRADLE4/bin/gradle --info sonarqube"
                            //stash name: 'workspace' TODO why stashing here?
                            commonUtil.echoSteps("SonarQube Static Code Analysis Completed Successfully")
                            env.STAGE_STATUS = "SONAR_CHECK"
                        }
                    }
                }
            }
            stage('Get Certs For Stage') {
                agent { label "${CAAS_CLIENT_LABEL}" }
                when {
                    expression { selectStages(stages.getCertsForStage, startStage, endStage) }
                }
                steps {
                    script {
                        commonUtil.echoSteps("Fetching certificates from CAAS")
                        caasUtil.getJKSFromCaaS(this, PCF_FOUNDATION, PCF_DEV_SPACE, keyMap, SYNAPSE_CLIENT_NAME, APP_HOST_NAME )
                        commonUtil.echoSteps("Certificates retrieved successfully")
                        env.STAGE_STATUS = "GET_CERTS"
                    }
                }
            }
            stage('Deploy Green Stage') {
                agent { label "${CF_CLI_LABEL}" }
                when {
                    expression { selectStages(stages.deployGreenStage, startStage, endStage) }
                }
                steps {
                    script {
                        unstash 'build_workspace' //TODO come up with packaging artifact along wit h manifest.yml files
                        // commonUtil.echoSteps("Retrieving manifest file")  // Make sure you download manifest before downloading artifact
                        // commonUtil.getManifest(artifactID)

                        // commonUtil.echoSteps("Retrieving Artifact from Artifactory")
                        // artifactoryUtil.artifactoryDownload(this, ARTIFACTORY_CREDENTIALS)
                        // commonUtil.echoSteps("Artifact Package Successfully Retrieved from Artifactory")

                        sh "cat manifest.yml"
                        commonUtil.echoSteps("Renaming AppHostName in manifest.yml")
                        albertaPCFUtil.renameAppInManifest(APP_HOST_NAME)
                        sh "cat manifest.yml"

                        commonUtil.echoSteps("Started Getting Environment Variables for Synapse")
                        envVar = org.mastercard.pipeline.utility.SynapseUtil.getEnvVar(this, keyMap, PCF_FOUNDATION, true)
                        commonUtil.echoSteps("Environment Variables for Synapse Successfully Set in map")
                        blueGreenDeployer = new org.mastercard.pipeline.deploy.BlueGreenDeployer(this, PCF_ORG, PCF_DEV_SPACE, PCF_CREDENTIALS, PCF_FOUNDATION)
                        //Pass custom live route to the method, if required."
                        // envVar = ['ENABLE_LOCUS_INIT':'true']
                        blueGreenDeployer.deployGreenApp(null, envVar)
                        commonUtil.echoSteps("Green Application Deployed Successfully")
                        env.STAGE_STATUS = "DEPLOY_GREEN"
                    }
                }
            }
            stage('Publish Pact Stage') {
                when {
                    expression { selectStages(stages.publishPactStage, startStage, endStage) && (SERVICE_TYPE == "consumer"  || SERVICE_TYPE == "consumer-provider")}
                }
                steps {
                    figlet "Pact Publish"
                    script{
                        try{
                            withCredentials([usernamePassword(credentialsId: 'pactbroker_credentials', passwordVariable: 'PB_PASSWORD', usernameVariable: 'PB_USERNAME')]) {
                                sh "$GRADLE4/bin/gradle pactPublish -Dusername=${PB_USERNAME} -Dpassword=${PB_PASSWORD}"
                            }
                            commonUtil.echoSteps("Publishing Pacts Completed Successfully")
                            env.STAGE_STATUS = "PUBLISH_PACT"
                        }
                        catch(e){throw e}
                    }
                }
            }
            stage('Integration Tests Stage') {
                when {
                    expression { selectStages(stages.integrationTestsStage, startStage, endStage) }
                }
                steps {
                    script {
                        commonUtil.echoSteps("Starting Integration Tests")

                        contractMap = contractTestingUtil.backendCT(false ,STASH_CREDENTIALS , ORG_GRADLE_PROJECT_PACT_BROKER_URL)
                        commonUtil.echoSteps("\nContract Map: ${contractMap}")

                        qaUtil.executeIntegrationTestsBackend(this, PCF_CREDENTIALS , false, keyMap)

                        commonUtil.echoSteps("Integration Tests Completed Successfully")
                        env.STAGE_STATUS = "INTEGRATION_TESTS"
                    }
                }
                post {
                    always{
                        script{
                            qaUtil.publishTestResults(this, "Integration Test", "Stage", "int", "build/reports/tests/integrationTest", "index.html")
                        }
                    }
                    failure{
                        script{
                            commonUtil.echoSteps("Renaming AppHostName in manifest.yml")
                            sh "ls -latr"
                            sh "cat manifest.yml"
                            def pipelineConfigData = fileUtil.readPipelineConfig()
                            albertaPCFUtil.renameAppInManifest(APP_HOST_NAME)
                            blueGreenDeployer = new org.mastercard.pipeline.deploy.BlueGreenDeployer(this, PCF_ORG, PCF_DEV_SPACE, PCF_CREDENTIALS, PCF_FOUNDATION)
                            blueGreenDeployer.deleteGreenApp(true)
                            albertaPCFUtil.renameAppInManifest(pipelineConfigData.pipeline.hostname)
                            sh "cat manifest.yml"
                        }
                    }
                }
            }
            stage('Pact Verification Stage') {
                when {
                    expression { (selectStages(stages.pactVerifyStage, startStage, endStage)) && ("${contractMap['statusCodeProvider']}" == '0' || "${contractMap['statusCodeConsumerProvider']}" == '0')}
                }
                steps {
                    script{
                        commonUtil.echoSteps("Renaming AppHostName in manifest.yml")
                        albertaPCFUtil.renameAppInManifest(APP_HOST_NAME)
                        contractTestingUtil.pactVerify()
                        commonUtil.echoSteps("Verifying Pacts Completed")
                        env.STAGE_STATUS = "VERIFY_PACT"
                    }
                }
                post {
                    failure{
                        script{
                            sh "ls -latr"
                            sh "cat manifest.yml"
                            def pipelineConfigData = fileUtil.readPipelineConfig()
                            commonUtil.echoSteps("Renaming AppHostName in manifest.yml")
                            albertaPCFUtil.renameAppInManifest(APP_HOST_NAME)
                            blueGreenDeployer = new org.mastercard.pipeline.deploy.BlueGreenDeployer(this, PCF_ORG, PCF_DEV_SPACE, PCF_CREDENTIALS, PCF_FOUNDATION)
                            blueGreenDeployer.deleteGreenApp(true)
                            albertaPCFUtil.renameAppInManifest(pipelineConfigData.pipeline.hostname)
                            sh "cat manifest.yml"
                        }
                    }
                }
            }
            stage('Flip Traffic Stage') {
                agent { label "${CF_CLI_LABEL}" }
                when {
                    expression { selectStages(stages.flipTrafficStage, startStage, endStage) }
                }
                steps {
                    script {
                        commonUtil.echoSteps("Started Flipping Traffic")
                        //unstash 'workspace'
                        commonUtil.echoSteps("Retrieving manifest file")
                        commonUtil.getManifest(artifactID)

                        // Avoid restarting the App after flip
                        // def map = ['ENABLE_LOCUS_INIT':'true']

                        // Pass custom live route to the method, if required."
                        appRollBack = true
                        blueGreenDeployer.flipTraffic()

                        commonUtil.echoSteps("Traffic Successfully Flipped to New Live Application")
                        env.STAGE_STATUS = "FLIP_TRAFFIC"
                    }
                }
            }
            stage('Autoscale Application Stage') {
                agent { label "${CF_CLI_LABEL}" }
                when {
                    expression { selectStages(stages.autoscaleApplicationStage, startStage, endStage) }
                }
                steps {
                    script {
                        deleteDir()
                        // unstash 'workspace'
                        commonUtil.echoSteps("Retrieving manifest file")
                        commonUtil.getManifest(artifactID)

                        commonUtil.echoSteps("Retrieving autoscale file")
                        commonUtil.getAutoscale(artifactID)

                        albertaPCFUtil.renameAppInManifest(APP_HOST_NAME)
                        autoscaleUtil.autoscaleApplication(PCF_ORG, PCF_DEV_SPACE, PCF_CREDENTIALS, PCF_FOUNDATION, true)

                        commonUtil.echoSteps("Auto-scaling Rules Successfully Applied to New Live Application")
                        env.STAGE_STATUS = "AUTOSCALE_APP"
                    }
                }
                post {
                    failure{
                        script{
                            pcfUtil.setArtifactURL( this, null, artifactoryUtil.getArtifactVersion() )
                        }
                    }
                }
            }
            stage('Execute E2E Tests Stage') {
                when {
                    expression { selectStages(stages.executeE2ETestsStage, startStage, endStage) && params.EXECUTE_E2E_STAGE != "DISABLE" }
                }
                steps {
                    script {
                        commonUtil.echoSteps("Executing E2E Tests")

                        qaUtil.executeE2ETests(this, PCF_CREDENTIALS, PCF_DEV_SPACE, ENTRY_URL, false)

                        commonUtil.echoSteps("E2E Tests Executed Successfully")
                        env.STAGE_STATUS = "E2E_TESTS"
                    }
                }
                post {
                    always{
                        script{
                            qaUtil.publishTestResults(this, "E2E", "Stage", "e2e",'build/reports/allure-report', 'index.html')
                        }
                    }
                    failure{
                        script{
                            pcfUtil.setArtifactURL( this, null, artifactoryUtil.getArtifactVersion() )
                        }
                    }
                }
            }
            stage('Publish To Artifactory Stage') {
                when {
                   expression { selectStages(stages.publishToArtifactoryStage, startStage, endStage) }
                }
                steps {
                    script {
                       unstash 'build_workspace'
                       sh "ls -ltr build/libs/"
                       commonUtil.echoSteps("Publishing Artifact to Artifactory if not already there")
                       artifactoryUtil.artifactoryUpload(this, ARTIFACTORY_CREDENTIALS)
                       // artifactUpload = true
                       pcfUtil.setArtifactURL(this)
                       commonUtil.echoSteps("Artifact Successfully Published to Artifactory")
                       env.STAGE_STATUS = "ARTIFACTORY_PUBLISH"
                       org.mastercard.alberta.VersionTool.tagIfNeeded(this, gitUtil, artifactoryUtil, commonUtil)
                    }
                }
                post {
                    failure{
                        script{
                            pcfUtil.setArtifactURL( this, null, artifactoryUtil.getArtifactVersion() )
                        }
                    }
                }
            }
        }
        post {
            /*failure{
                script{
                    if(appRollBack){
                        pcfUtil.appRollBack(this, envVar, artifactUpload)
                        commonUtil.echoSteps("Rolled back to previous version")

                    }
                }
            }
            success{
                script{
                    echo "Deleting the old back up file"
                    pcfUtil.deleteOldBackApp(this)
                    commonUtil.echoSteps("Deleted the old back up file")
                }
            }*/
            always {
                script {
                    echo "Deleting the old back up file"
                    pcfUtil.deleteOldBackApp(this)
                    commonUtil.echoSteps("Deleted the old back up file")

                    if(e2eTearDown){
                        // Tearing down E2E Environment
                        albertaPCFUtil.deleteAppsDeployed(this, PCF_CREDENTIALS)
                        albertaPCFUtil.deletePcfServiceInstance(this, PCF_CREDENTIALS)
                    }
                    if ( selectedEnvironment == PROD_ENVIRONMENT || selectedEnvironment == PRE_PROD_ENVIRONMENT ) {
                        emailUtil.prepareReleaseEmailNotification(this, STASH_CREDENTIALS, "${selectedEnvironment}", "${currentBuild.currentResult}")
                    } else {
                        emailUtil.prepareEmailNotification(this, STASH_CREDENTIALS, "${selectedEnvironment}", "${currentBuild.currentResult}")
                    }

                    commonUtil.echoSteps("Emptying current workspace directory")
                    deleteDir()

                    commonUtil.echoSteps("Sending ${currentBuild.currentResult} Notification Email")
                    emailext (
                            to: "${env.RECIPIENTS}",
                            subject: "${env.EMAIL_SUBJECT}",
                            body: "${env.EMAIL_BODY}"
                    )
                }
            }
            changed {
                script {
                    commonUtil.echoSteps("Sending Status Change Notification Email")
                    emailext (
                            to: "${env.PR_REVIEWERS}",
                            subject: "BUILD CHANGED: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
                            body: "${env.STATUS_EMAIL_BODY}"
                    )
                }
            }
        }
    }
}
