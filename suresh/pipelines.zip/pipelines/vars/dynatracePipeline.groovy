def albertaPCFUtil = new org.mastercard.alberta.AlbertaPCFUtil(this)
def setEnvironmentVars = new org.mastercard.alberta.SetEnvironmentVarsUtil(this)
def CF_CLI_LABEL = "DTL-CF-CLI"
def listOfApps = null
def SERVICE_NAME = "switch-dynatrace"
def didChooseEnable = null

pipeline {
	agent { label "${CF_CLI_LABEL}"}
	parameters {
		choice(
			name: 'space_name',
			choices: 'src-perf\nsrc-stage',
			description: 'What space is the app in?'
		)
		string(
			name: 'app_names',
			description: 'App name or comma seperated list of app names for which Dynatrace to be enabled that are deployed in the space. Example: appName1, appName2, appName3'
		)
		choice(
			name: 'set_state',
			choices: 'Enable\nDisable',
			description: 'Choose to enable or disable dynatrace for the apps listed.'
		)
	}
	stages {
		stage('Initialize Environment and Login') {
			steps {
				script {
					withEnv(["CF_HOME=."]) {
						didChooseEnable = params.set_state == "Enable"

						// Set env vars depending on user selected space
						switch (params.space_name) {
							case 'src-perf':
								setEnvironmentVars.setPerfVars()
								break
							case 'src-stage':
								setEnvironmentVars.setStageDynatraceVars()
								break
						}

						// Login
						albertaPCFUtil.pcfAuthenticate(this, PCF_CREDENTIALS)

						// Check if app names are valid
						listOfApps  = params.app_names.tokenize(", ")
						echo "${listOfApps}"
						albertaPCFUtil.validateAppNameList(listOfApps)
						albertaPCFUtil.validateAppsAreRunning(listOfApps)
					}
				}
			}
		}
		stage('Check For Dynatrace Service') {
			steps {
				script {
					withEnv(["CF_HOME=."]) {
						try{
							// Check if dynatrace service does not exists
							if(!albertaPCFUtil.isServiceCreated(SERVICE_NAME) && didChooseEnable) {
								sh "cf create-service Dynatrace DT_SaaS_Plan ${SERVICE_NAME}"
							}
						}catch(e){
							throw e
							sh "exit 1"
						}
					}
				}
			}
		}
		stage('Toggle Dynatrace Service') {
			steps {
				script {
					def envVarsList = globalVars.DYNATRACE_ENV_VARS

					try {
						withEnv(["CF_HOME=."]) {
							if(didChooseEnable){
								listOfApps.each{ appName ->
									if(albertaPCFUtil.isServiceBoundToApp(SERVICE_NAME, appName)) {
										echo "${appName} already has Dynatrace enabled."
									} else {
										albertaPCFUtil.enableService(envVarsList, appName, SERVICE_NAME)
										sh "cf restage ${appName}"
										echo "${appName} has been bound to Dynatrace"
									}
								}
							} else {
								listOfApps.each{ appName ->
									if(!albertaPCFUtil.isServiceBoundToApp(SERVICE_NAME, appName)) {
										echo "${appName} already has Dynatrace disabled."
									} else {
										albertaPCFUtil.disableService(envVarsList, appName, SERVICE_NAME)
										sh "cf restage ${appName}"
										echo "${appName} has been unbound to Dynatrace"
									}
								}
							}
						}
					} catch(e) {
						throw e
						sh "exit 1"
					}
				}
			}
		}
		stage('Logout') {
			steps {
				withEnv(["CF_HOME=."]) {
					sh "cf logout"
				}
			}
		}
	}
}
