#!groovy
@Library('AlbertaUtility') _

def releaseUtil = new org.mastercard.alberta.ReleaseSpecGenUtil(this)
def commonUtil = new org.mastercard.alberta.CommonUtil(this)

def timer = (env.BRANCH_NAME == 'master') ? 'H H(20-23) * * */2' : ''
env.PCF_ORG = "Alberta"

pipeline {
    agent { label "DTL" }
    triggers {
        cron(timer)
    }
    options {
        buildDiscarder(logRotator(numToKeepStr: '5'))
        skipDefaultCheckout()
        timestamps()
        disableConcurrentBuilds()
        timeout(time: 2, unit: 'HOURS')
    }
    parameters {
        // Create these below parameters in the job for each environment.

        //choice(name: 'PCF_FOUNDATION', choices: 'stl-stage', description: "Select a PCF Foundation")
        //choice(name: 'PCF_ORG', choices: 'Alberta', description: "Select a PCF Org")
        //choice(name: 'PCF_DEV_SPACE', choices: '\ne2e\nsrc-stage', description: "Select a PCF Space")
        //string(defaultValue: '', description: 'Enter the Release Spec File URL. e.g: https://globalrepository.mclocal.int/stash/users/e071815/repos/alberta_release_spec_files/raw/src-stage/2018-10-08-11-57.json?at=refs%2Fheads%2Fmaster', name: 'RELEASE_SPEC_URL')

        string(name: 'E2E_COMMIT', defaultValue: '', description: 'Provide the E2E Commit ID')
        string(name: 'EXECUTED_BY', defaultValue: '', description: 'Provide your Employee ID or Name for reference')
    }
    environment {
        CF_DIAL_TIMEOUT = 15
    }
    stages {
        stage('Generate Rel Spec'){
            steps{
                script{

                    switch(env.PCF_FOUNDATION) {
                        case 'stl-stage':
                            env.paasUrl = 'api.system.stl.pcfstage00.mastercard.int';
                            env.STASH_CREDENTIALS = 'alberta-pcfstage';
                            env.PCF_CREDENTIALS = 'alberta-pcf-creds-stl-stage'
                            break;
                        case 'stl-prod':
                            env.paasUrl = 'api.system.stl.pcfprod00.mastercard.int';
                            env.STASH_CREDENTIALS = 'stash-creds';
                            env.PCF_CREDENTIALS = 'alberta-pcf-creds-stl-prod';
                            break;
                        case 'stl-dev': env.paasUrl = 'api.system.stl.pcfdev00.mastercard.int'; break;
                        case 'bel-prod': env.paasUrl = 'api.system.bel.pcfprod00.mastercard.int'; break;
                        case 'ksc-prod': env.paasUrl = 'api.system.ksc.pcfprod00.mastercard.int'; break;
                    }
                    releaseUtil.generateReleaseSpecFile()
                }
            }
        }
    }
    post {
        always {
            echo 'I have finished Successfully'
            deleteDir() // clean up workspace
            script {
              commonUtil.echoSteps("Sending ${currentBuild.currentResult} Notification Email")
              env.RECIPIENTS = emailextrecipients([[$class: 'RequesterRecipientProvider']])
              env.EMAIL_BODY = "\nBUILD ${currentBuild.currentResult}: \n\n\n Application Deployment is ${currentBuild.currentResult} in PCF ${env.PCF_FOUNDATION} --> ${env.PCF_ORG} \n\n\nJenkins Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]' \nBuild URL: ${env.BUILD_URL}"
              emailext (
                    to: "${env.RECIPIENTS}",
                    subject: "BUILD ${currentBuild.currentResult}: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
                    body: "${env.EMAIL_BODY}"
              )
            }
        }
    }
}
