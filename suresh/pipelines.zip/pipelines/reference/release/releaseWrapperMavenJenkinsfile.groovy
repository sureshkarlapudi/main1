#!groovy
@Library('AlbertaUtility') _

def releaseUtil = new org.mastercard.alberta.ReleaseSpecGenUtil(this)

def jobName
def appNameList = []
def ARTIFACT_URL
def deployedArtifactURL
params.e2eReleaseTag?:""
params.ChangeRequestID?:""

pipeline {
    agent {label "DTL"}
    /*  parameters {
         Below environment variables need to be defined at Jenkins job configuration level accordingly, for Release Pipeline.
         *
         *      ChangeRequestID = "CHG12345"
         *      ArtifactName = "durable-data-service-1.0-20180511.224921-1.jar"
         *      Environment = "pre-prod-release" or "prod-release" or "perf-release"
         *      e2eReleaseTag = "release/alpha"
         *
         choice(choices: 'perf-release', description: "Please select Environment", name: 'Environment')
         string(defaultValue: '', description: 'Enter the Release Spec File URL. e.g: https://globalrepository.mclocal.int/stash/users/e071815/repos/alberta_release_spec_files/raw/src-stage/2018-10-08-11-57.json?at=refs%2Fheads%2Fmaster', name: 'RELEASE_SPEC_URL')
         string(name: 'APPS_LIST', defaultValue: 'mdes-facade,card-art-service,remote-logging-service,srci-merchantdata-services,utility-service,consumer-service,app-instance-service,address-service,srci-middleware,checkout-service,precheckout-service',
                 description: """Add Order of App Names separated by Comma (,):
                                          mdes-facade,card-art-service,remote-logging-service,srci-merchantdata-services,utility-service,consumer-service,app-instance-service,address-service,srci-middleware,checkout-service,precheckout-service""")
         choice(choices: 'DISABLE\nENABLE', description: "Please select 'DISABLE' option to exclude E2E Stage", name: 'EXECUTE_E2E_STAGE')

    } */
    stages {
        stage('Retrieve Release Spec') {
            steps {
                script {
                    def info = sh(returnStdout: true, script: "curl ${RELEASE_SPEC_URL}").trim()
                    relSpecJson = readJSON text: info
                }
            }
        }
        stage("build") {
            steps {
                script {
                    switch (params.Environment) {
                        case 'perf-release':  jobName = 'alberta-release-pipeline-backend-perf'; break;
                        case 'pre-prod-release': jobName = 'Alberta-release-pipeline-maven'; break;
                        case 'prod-release': jobName = 'Alberta-release-pipeline-maven'; break;
                    }
                    appNameList = APPS_LIST.tokenize( ',' )

                    appNameList.each { pcfAppName ->

                        ARTIFACT_URL = relSpecJson.services.backend."${pcfAppName}".ARTIFACT_URL

                        deployedArtifactURL = releaseUtil.getDeployedArtifactURL(pcfAppName, params.Environment)
                        def splitArtifactURL =  ARTIFACT_URL.split("artifactory")[1]

                        println "Deployed URL: " + deployedArtifactURL
                        println "Artifact URL from Spec: " + splitArtifactURL

                        if(deployedArtifactURL == splitArtifactURL ){
                            echo "Skipping to next service as the deployed artifact version matches to one in Release Spec."
                            return
                        }
                        build(
                                job: "${jobName}",
                                parameters: [
                                        [
                                                $class: 'StringParameterValue',
                                                name  : 'Environment',
                                                value : params.Environment
                                        ],
                                        [
                                                $class: 'StringParameterValue',
                                                name  : 'ARTIFACT_URL',
                                                value : ARTIFACT_URL
                                        ],
                                        [
                                                $class: 'StringParameterValue',
                                                name  : 'ChangeRequestID',
                                                value : params.ChangeRequestID
                                        ],
                                        [
                                                $class: 'StringParameterValue',
                                                name  : 'e2eReleaseTag',
                                                value : params.e2eReleaseTag
                                        ],
                                        [
                                                $class: 'StringParameterValue',
                                                name  : 'EXECUTE_E2E_STAGE',
                                                value : params.EXECUTE_E2E_STAGE
                                        ]
                                ]
                        )
                    }
                }
            }
        }
    }
}