#!/bin/bash
# set -e

# M2_Releases
# wget --no-check-certificate -O build/libs/address-service.jar http://artifacts.mastercard.int/artifactory/snapshots/com/mastercard/alberta/address-service/1.0-SNAPSHOT/address-service-201808131055-6859e29.jar
# wget --no-check-certificate -O build/libs/app-instance-service.jar http://artifacts.mastercard.int/artifactory/snapshots/com/mastercard/alberta/app-instance-service/1.0-SNAPSHOT/app-instance-service-1.0-20180807.181846-1.jar
# wget --no-check-certificate -O build/libs/checkout-service.jar http://artifacts.mastercard.int/artifactory/snapshots/com/mastercard/alberta/checkout-service/1.0-SNAPSHOT/M2_Release/checkout-service-201808171005-2a56d60.jar
# wget --no-check-certificate -O build/libs/cersei.zip http://artifacts.mastercard.int/artifactory/snapshots/com/mastercard/alberta/cersei/stage/cersei-dist-201809251327-e90afba.zip
# wget --no-check-certificate -O build/libs/consumer-service.jar http://artifacts.mastercard.int/artifactory/snapshots/com/mastercard/alberta/consumer-service/1.0-SNAPSHOT/M2_Release/consumer-service-201808201154-669fea7.jar
# wget --no-check-certificate -O build/libs/durable-data-service.jar http://artifacts.mastercard.int/artifactory/snapshots/com/mastercard/alberta/durable-data-service/1.0-SNAPSHOT/M2_Release/durable-data-service-201808171010-a67b4da.jar
# wget --no-check-certificate -O build/libs/mdes-facade.jar http://artifacts.mastercard.int/artifactory/snapshots/com/mastercard/alberta/mdes-facade/1.0.0-SNAPSHOT/M2_Release/mdes-facade-201808171020-5c824c1.jar
# wget --no-check-certificate -O build/libs/precheckout-service.jar http://artifacts.mastercard.int/artifactory/snapshots/com/mastercard/alberta/precheckout-service/1.0-SNAPSHOT/M2_Release/precheckout-service-201808171035-e136220.jar
# wget --no-check-certificate -O build/libs/remote-logging-service.jar http://artifacts.mastercard.int/artifactory/snapshots/com/mastercard/alberta/remote-logging-service/1.0-SNAPSHOT/M2_Release/remote-logging-service-201808171023-79148f4.jar
# wget --no-check-certificate -O build/libs/srci-merchantdata-services.jar http://artifacts.mastercard.int/artifactory/snapshots/com/mastercard/alberta/srci-merchantdata-services/1.0-SNAPSHOT/M2_Release/srci-merchantdata-services-201808171026-335f892.jar
# wget --no-check-certificate -O build/libs/srci-middleware.jar http://artifacts.mastercard.int/artifactory/snapshots/com/mastercard/alberta/srci-middleware/1.0-SNAPSHOT/M2_Release/srci-middleware-201808171031-88b96d2.jar
# wget --no-check-certificate -O build/libs/utility-service.jar http://artifacts.mastercard.int/artifactory/snapshots/com/mastercard/alberta/utility-service/1.0.0-SNAPSHOT/M2_Release/utility-service-201808171040-ba3c274.jar
# wget --no-check-certificate -O build/libs/varys.zip http://artifacts.mastercard.int/artifactory/snapshots/com/mastercard/alberta/varys/stage/varys-dist-201809241617-a2730d2.zip


export GRADLE4=/usr/local
export ALL_COMPONENTS=( address-service app-instance-service cersei checkout-service consumer-service durable-data-service mdes-facade precheckout-service remote-logging-service srci-merchantdata-service srci-middleware utility-service varys )
export CREDS_USER=$1
export CREDS_PASSWORD=$2

export COMPONENT="checkout-service"
export OTHER_COMPONENTS=( "${ALL_COMPONENTS[@]/$COMPONENT}" )
export BRANCH="dev"
# export SCM="fusion.mastercard.int"
export SCM="globalrepository.mclocal.int"
export ORG_GRADLE_PROJECT_PACT_BROKER_URL="https://int-pact-broker.apps.stl.pcfstage00.mastercard.int:443"

# Sonar
export SONAR_USER=${CREDS_USER}
export SONAR_PASSWORD=${CREDS_PASSWORD}

# GitEA
export gitEA_USERNAME=scsconfig
export gitEA_PASSWORD=scsconfig

# CF
export CF_API="api.system.stl.pcfstage00.mastercard.int"
export CF_ORG="Alberta"
export ENV="stl-stage"
export SPACE="pr-e2e"
export CF_HOME=`pwd`/.cf/

export APP_DOMAIN="apps.stl.pcfstage00.mastercard.int"
export CF_ORG_LOWER=`echo "$CF_ORG" | awk '{print tolower($0)}'`
export CF_SPACE_LOWER=`echo "$SPACE" | awk '{print tolower($0)}'`

rm -rf ${COMPONENT}

git clone -b ${BRANCH} https://${CREDS_USER}@${SCM}/stash/scm/alberta/${COMPONENT}.git

pushd ${COMPONENT}

    ${GRADLE4}/bin/gradle clean build -x test
    ${GRADLE4}/bin/gradle check test
    # ${GRADLE4}/bin/gradle --info sonarqube

    git clone --depth=1 https://${CREDS_USER}@${SCM}/stash/scm/digops/alberta-space-configuration.git

    cp -R alberta-space-configuration/${ENV}/${SPACE}/${COMPONENT}/ ./

popd

rm -rf contract-validator-java

git clone --depth=1 https://${CREDS_USER}@${SCM}/stash/scm/alberta/contract-validator-java.git

pushd contract-validator-java

    ${GRADLE4}/bin/gradle test -DURL=${ORG_GRADLE_PROJECT_PACT_BROKER_URL} -DSERVICE_NAME=${COMPONENT} -DPROVIDER_CHECK=false -DCONSUMER_CHECK=true > /dev/null 2>&1
    ${GRADLE4}/bin/gradle test -DURL=${ORG_GRADLE_PROJECT_PACT_BROKER_URL} -DSERVICE_NAME=${COMPONENT} -DPROVIDER_CHECK=true -DCONSUMER_CHECK=false > /dev/null 2>&1
    ${GRADLE4}/bin/gradle test -DURL=${ORG_GRADLE_PROJECT_PACT_BROKER_URL} -DSERVICE_NAME=${COMPONENT} -DPROVIDER_CHECK=true -DCONSUMER_CHECK=true > /dev/null 2>&1

popd

git clone https://${CREDS_USER}@${SCM}/stash/scm/alberta/pcf-git-service.git
git clone https://${CREDS_USER}@${SCM}/stash/scm/alberta/config-repo.git

mkdir -p pcf-git-service/config-repo/
cp -a config-repo/stage/. pcf-git-service/config-repo/

cf login \
-a ${CF_API} \
--skip-ssl-validation \
-o ${CF_ORG} \
-s ${SPACE} \
-u ${CREDS_USER} \
-p ${CREDS_PASSWORD}

pushd pcf-git-service/
    pushd config-repo/
        git init
        git add .
        git commit -m 'Loaded Config Repo Files from stage environment to gitEA Server'
    popd
    scripts/gitSvcCtl.sh config-repo ${gitEA_PASSWORD} -s
popd

echo "{\"git\": { \"uri\": \"https://${CF_ORG_LOWER}-${CF_SPACE_LOWER}-git-svc.${appDomain}/${gitEA_USERNAME}/config-repo.git\", \"username\": \"${gitEA_USERNAME}\", \"password\": \"${gitEA_PASSWORD}\", \"cloneOnStart\": true} }"

# Config Server
cf create-service \
p-config-server \
standard \
config-server \
-c "{\"git\": { \"uri\": \"https://${CF_ORG_LOWER}-${CF_SPACE_LOWER}-git-svc.${appDomain}/${gitEA_USERNAME}/config-repo.git\", \"username\": \"${gitEA_USERNAME}\", \"password\": \"${gitEA_PASSWORD}\", \"cloneOnStart\": true} }"

# Create services
cf create-service \
p-redis \
dedicated-vm \
alberta-redis

cf create-service \
p-redis \
dedicated-vm \
srci-middleware-redis

cf create-service \
p-redis \
dedicated-vm \
srci-merchantdata-services-redis

cf create-service \
p-redis \
dedicated-vm \
precheckout-service-redis

# cf push