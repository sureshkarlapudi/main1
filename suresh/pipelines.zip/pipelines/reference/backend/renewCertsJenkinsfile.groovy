#!groovy
@Library('AlbertaUtility') _


def pcfUtil = new org.mastercard.pipeline.utility.PCFUtil(this)
def commonUtil = new org.mastercard.alberta.CommonUtil(this)
def caasUtil = new org.mastercard.pipeline.utility.CaaSUtil(this)
def qaUtil = new org.mastercard.alberta.QAUtil(this)
def keyMap = [:]
def envVarMap = [:]
def envVar = [:]
def appNameList = ['stage-1-remote-logging-service-blue']
def artifactURLMap = [:]
def HIGHER_FOUNDATIONS = ['stl-prod', 'bel-prod' ,'ksc-prod']
def CF_CLI_LABEL = HIGHER_FOUNDATIONS.contains(params.PCF_FOUNDATION) ? "CF-CLI" : "DTL-CF-CLI"
def CAAS_CLIENT_LABEL = HIGHER_FOUNDATIONS.contains(params.PCF_FOUNDATION) ? "CAAS_CLIENT" : "DTL-CAAS-CLIENT"
def paasUrl

pipeline {
    agent { label "${CF_CLI_LABEL}" }
    environment {
        BROWSERSTACK_KEY = credentials('BrowserStackKey')
        BROWSERSTACK_USER = credentials('BrowserStackUser')
    }
    // parameters {
    //     choice(name: 'PCF_FOUNDATION', choices: '\nstl-stage\nstl-prod', description: "Select a PCF Foundation")
    //     choice(name: 'PCF_ORG', choices: 'Alberta', description: "Select a PCF Org")
    //     choice(name: 'PCF_SPACE', choices: '\ne2e\nsrc-perf\npre-prod\nprod', description: "Select a PCF Space")
    //     string(name: 'APPS_LIST', defaultValue: '',
    //             description: 'Add multiple App Names separated by Comma (,): ' +
    //                     'e2e-remote-logging-service,e2e-address-service,e2e-app-instance-service,e2e-checkout-service,e2e-consumer-serivce,e2e-precheckout-service,e2e-srci-merchantdata-services,e2e-srci-middleware,e2e-utility-service')
    //     booleanParam(name: 'E2E', defaultValue: false, description: 'Execute E2E? ')
    // }
    stages {
        stage('Intialization'){
            steps{
                script{
                    // TODO changes when common pipeline is in place
                    if ( HIGHER_FOUNDATIONS.contains(params.PCF_FOUNDATION) ) {
                        if ( params.CHG_REQUEST_ID ) {
                            commonUtil.echoSteps("This is Certificate Renewal for Change Request: ${params.CHG_REQUEST_ID}")
                        }
                        else {
                            println "Aborting the Job, since CHG# is not entered."
                            sh "exit 1"
                        }
                    }

                    env.ALBERTA_ARTIFACTORY_URL = globalVars.artifactory_url
                    env.PCF_FOUNDATION = params.PCF_FOUNDATION
                    env.PCF_ORG = params.PCF_ORG
                    env.PCF_SPACE = params.PCF_SPACE
                    env.SYNAPSE_CLIENT_NAME = 'srcsystem-alberta-services'
                    env.ORG_GRADLE_PROJECT_PROVIDER_PORT='443'
                    env.ORG_GRADLE_PROJECT_PROVIDER_PROTOCOL='https'

                    appNameList = APPS_LIST.tokenize( ',' )
                    println "This is the List of Apps for Cert Renewal:"+ appNameList

                    switch(PCF_FOUNDATION) {
                        case 'stl-stage':
                            paasUrl = 'api.system.stl.pcfstage00.mastercard.int';
                            env.STASH_CREDENTIALS = 'alberta-pcfstage';
                            env.PCF_CREDENTIALS = 'alberta-pcf-creds-stl-stage';
                            env.ORG_GRADLE_PROJECT_PROVIDER_HOST="apps.stl.pcfstage00.mastercard.int";
                            env.ORG_GRADLE_PROJECT_PACT_BROKER_URL = "https://int-pact-broker.apps.stl.pcfstage00.mastercard.int:443";
                            env.ENTRY_URL = "${PCF_SPACE}-cersei.apps.stl.pcfstage00.mastercard.int";
                            break;
                        case 'stl-prod':
                            paasUrl = 'api.system.stl.pcfprod00.mastercard.int';
                            env.STASH_CREDENTIALS = 'stash-creds';
                            env.PCF_CREDENTIALS = 'alberta-pcf-creds-stl-prod';
                            env.ORG_GRADLE_PROJECT_PROVIDER_HOST="apps.stl.pcfprod00.mastercard.int";
                            env.ORG_GRADLE_PROJECT_PACT_BROKER_URL = "https://${PCF_SPACE}-pact-broker.apps.stl.pcfprod00.mastercard.int:443";
                            env.ENTRY_URL = "${PCF_SPACE}-cersei.apps.stl.pcfprod00.mastercard.int";
                            break;
                        case 'stl-dev': paasUrl = 'api.system.stl.pcfdev00.mastercard.int'; break;
                        case 'bel-prod': paasUrl = 'api.system.bel.pcfprod00.mastercard.int'; break;
                        case 'ksc-prod': paasUrl = 'api.system.ksc.pcfprod00.mastercard.int'; break;
                    }
                }
            }
        }
        stage('Get Artifact URLs'){
            agent { label "${CF_CLI_LABEL}" }
            steps{
                script{
                    withEnv(["CF_HOME=."]) {
                        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: PCF_CREDENTIALS, usernameVariable: 'PCF_USER', passwordVariable: 'PCF_PASSWORD']]) {

                            sh "cf login -a ${paasUrl} -u ${PCF_USER} -p ${PCF_PASSWORD} -o ${PCF_ORG} -s ${PCF_SPACE}"

                            appNameList.each { pcfAppName ->
                                artifactURLMap[pcfAppName] = sh(script: "cf env ${pcfAppName} | grep ArtifactURL | awk '{print \$2}'", returnStdout: true).trim()
                                println "This is the Artifact URL for ${pcfAppName}: " + artifactURLMap[pcfAppName]

                                if( (!artifactURLMap[pcfAppName] || artifactURLMap[pcfAppName] == "null") ){
                                    echo "Aborting Pipeline, since Artifact URL is not Found for ${pcfAppName}"
                                    sh "exit 1"
                                }
                            }
                            println "This is artifactURL Map - " + artifactURLMap
                            sh 'cf logout'
                        }
                    }
                }
            }
        }
        stage('Get Certs') {
            agent { label "${CAAS_CLIENT_LABEL}" }
            steps {
                script {
                    deleteDir()
                    commonUtil.echoSteps("Fetching Certificates from CAAS")
                    appNameList.each { pcfAppName ->
                        caasUtil.getJKSFromCaaS(this, PCF_FOUNDATION, PCF_SPACE, keyMap, SYNAPSE_CLIENT_NAME, pcfAppName)
                        env.artifactURL = artifactURLMap[pcfAppName]
                        envVar = org.mastercard.pipeline.utility.SynapseUtil.getEnvVar(this, keyMap, PCF_FOUNDATION, true)
                        envVarMap[pcfAppName] = envVar

                    }
                    commonUtil.echoSteps("Certificates retrieved successfully")
                }
            }
        }
        stage('Renew Apps after Certs Renewal') {
            agent { label "${CF_CLI_LABEL}" }
            steps {
                script {
                    deleteDir()
                    println "Re-Deploying Blue Apps after Certs are Renewed"

                    appNameList.each{ pcfAppName ->
                        commonUtil.echoSteps("Re-Deploying ${pcfAppName} after Certificate Renewal")
                        def artifactUrlPath = "${env.ALBERTA_ARTIFACTORY_URL}/${artifactURLMap[pcfAppName]}"
                        sh "curl -O --fail ${artifactUrlPath}"
                        def artifactId = sh(script: "basename ${artifactUrlPath}", returnStdout: true).trim()
                        def repoBaseName = commonUtil.getRepoName(artifactUrlPath)
                        println "this is repo name" + repoBaseName
                        try{
                            if(repoBaseName.contains('varys') ){
                                sh "unzip -o ${artifactId} -d dist"
                                artifactId = "dist"
                            }else if(repoBaseName.contains('cersei') ) {
                                sh "unzip -o ${artifactId} -d dist"
                                artifactId = "dist/cersei"
                            }
                            else
                            {
                                sh("jar xf ${artifactId} BOOT-INF/classes/manifest.yml")
                            }
                        }catch(Exception e){
                            echo("The app does not have the files required for pipeline configuration")
                        }

                        sh """
                            curl -ks -o manifest.yml "https://globalrepository.mclocal.int/stash/projects/ALBERTA/repos/${repoBaseName}/raw/manifest.yml?at=refs%2Fheads%2Fdev"
                        """
                        if (fileExists("manifest.yml")) {
                            echo "Found manifest.yml file, will update the path value with the downloaded artifact path"
                            def manifestData = readFile("manifest.yml")
                            writeFile(file: "manifest.yml", text: manifestData.replaceAll(/path:[a-zA-Z0-9. \/-]+/,"path: ${artifactId}"))
                            sh("more manifest.yml")
                        }
                        sh "ls -ltr"
                        pcfUtil.zeroDowntimeRefreshToPCFGoRouter(
                                this,
                                pcfAppName,
                                PCF_FOUNDATION,
                                PCF_ORG,
                                PCF_SPACE,
                                PCF_CREDENTIALS,
                                null,
                                null,
                                envVarMap[pcfAppName],
                                true,
                                false,
                                'pcf' // TODO: Shared Util this
                        )

                    }
                }
            }
        }
        stage('Execute E2E Tests Stage') {
            when {
                expression {  return params.E2E }
            }
            steps {
                script {
                    commonUtil.echoSteps("Executing E2E Tests")

                    qaUtil.executeE2ETests(this, PCF_CREDENTIALS, PCF_SPACE, ENTRY_URL, false)

                    commonUtil.echoSteps("E2E Tests Executed Successfully")
                    env.STAGE_STATUS = "E2E_TESTS"
                }
            }
            post {
                always{
                    script{
                        qaUtil.publishTestResults(this, "E2E", "Stage", "e2e", "extentreports", "report.html")
                    }
                }
            }
        }

    }
    post {
        always {
            echo 'I have finished'
            deleteDir() // clean up workspace
            script {
              commonUtil.echoSteps("Sending ${currentBuild.currentResult} Notification Email")
              env.RECIPIENTS = emailextrecipients([[$class: 'RequesterRecipientProvider']])
              env.EMAIL_BODY = "\nBUILD ${currentBuild.currentResult}: \n\n\n Application Deployment is ${currentBuild.currentResult} in PCF ${env.PCF_FOUNDATION} --> ${env.PCF_ORG} \n\n\nJenkins Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]' \nBuild URL: ${env.BUILD_URL}"
              emailext (
                    to: "${env.RECIPIENTS}",
                    subject: "BUILD ${currentBuild.currentResult}: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
                    body: "${env.EMAIL_BODY}"
              )
            }
        }
    }
}
