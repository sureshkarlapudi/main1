#!groovy
@Library('AlbertaUtility') _

def DotEnvUtil = new org.mastercard.alberta.DotEnvUtil(this)
def YarnUtil = new org.mastercard.alberta.YarnUtil(this)

def pcfUtil = new org.mastercard.pipeline.utility.PCFUtil(this)
def caasUtil = new org.mastercard.pipeline.utility.CaaSUtil(this)

def pcfAppName = 'trident-dashboard'
def keyMap = [:]

pipeline {
    agent { label 'DEVCLD-YARN' }
    environment { PATH = "$PATH:$NODE8/bin:$YARN1/bin" }
    stages {
        stage('Install Dependencies') {
            steps {
                script {
                    env.STASH_CREDENTIALS = 'alberta-stash-credentials'
                    env.SYNAPSE_CLIENT_NAME = 'srcsystem-alberta-services'
                    env.PCF_ORG = 'Alberta'
                    env.PCF_FOUNDATION = 'stl-stage'
                    env.PCF_DEV_SPACE = 'kick-one'
                    env.PCF_CREDENTIALS = 'alberta-pcf-credentials'

                    deleteDir()
                    git branch: 'dev', url: "https://globalrepository.mclocal.int/stash/scm/alberta/trident-dashboard.git", credentialsId: 'alberta-stash-credentials'
                    YarnUtil.install(this)
                }
            }
        }

        stage('Configure') {
            steps {
                script {
                    // TODO: Use Alberta shared libs for pcf information and parameter-tize
                    def cerseiHost = 'https://src-stage-cersei.apps.stl.pcfstage00.mastercard.int'
                    def varysHost = 'https://src-stage-varys.apps.stl.pcfstage00.mastercard.int'
                    DotEnvUtil.create(cerseiHost, varysHost)
                }
            }
        }

        /* stage('Lint') {
             steps {
                 script {
                     sh 'yarn lint'
                 }
             }
         }

         stage('Unit Testing') {
             steps {
                 script {
                     sh 'yarn unit:ci'
                 }
             }
         }*/

        stage('Build') {
            steps {
                script {
                    sh 'yarn build'
                    stash includes: '**', name: 'built_workspace'
                }
            }
        }
        stage('Get Certs For PR') {
            agent { label "DTL-CAAS-CLIENT" }
            steps {
                script {
                    unstash 'built_workspace'
                    caasUtil.getJKSFromCaaS(this, PCF_FOUNDATION, PCF_DEV_SPACE, keyMap, SYNAPSE_CLIENT_NAME)
                }
            }
        }
        stage('Deploy') {
            agent { label 'DTL-CF-CLI' }
            steps {
                script {
                    try {
                        unstash 'built_workspace'
                        pcfUtil.deployToPCFGoRouter(
                                this,
                                pcfAppName,
                                'stl-stage',
                                'Alberta',
                                'kick-one',
                                'alberta-pcf-credentials',
                                null,
                                null,
                                keyMap,
                                false,
                                false,
                                null
                        )
                    } catch (e) {
                        throw e
                    }
                }
            }
        }
    }
}