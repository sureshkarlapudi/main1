@Library('AlbertaUtility') _

def artifactoryUtil = new org.mastercard.alberta.ArtifactoryUtil(this)

pipeline{
    agent { label "DTL-GRADLE" }
    environment {
        ORG_GRADLE_PROJECT_PROVIDER_PORT = 443
        ORG_GRADLE_PROJECT_PROVIDER_HOST = "apps.stl.pcfstage00.mastercard.int"
        ORG_GRADLE_PROJECT_PROVIDER_PROTOCOL = 'https'
        ORG_GRADLE_PROJECT_PACT_BROKER_URL = "https://int-pact-broker.apps.stl.pcfstage00.mastercard.int:443"
        PATH = "$PATH:$NODE6/bin:$YARN1/bin"
    }
    parameters{
        //string(defaultValue: 'projects-metadata', description: 'Please Provide the applicationName you want to deploy?', name: 'applicationName')
        //string(defaultValue: 'dev', description: 'Please Provide the branch', name: 'branchName')
        //string(defaultValue: 'kick-one', description: 'Please Provide the Space where you want to deploy to? ', name: 'space')
        string(defaultValue: "com/mastercard/trident", description: 'Please Provide the group ID where you want to upload the artifact to? ', name: 'artifact_upload_to')
        booleanParam(defaultValue: false, description: 'Run Sonar Qube? ', name: 'sonarQube')
        booleanParam(defaultValue: true, description: 'Run aritfact upload? ', name: 'artifactUpload')
        booleanParam(defaultValue: true, description: 'Deploy to PCF? ', name: 'deployToPCF')
    }
    stages{
        stage('Test And Build') {
            steps {
                deleteDir()
                git branch: 'dev', url: "https://globalrepository.mclocal.int/stash/scm/alberta/tests-metadata.git", credentialsId: 'alberta-stash-credentials'

                script {
                    sh "$GRADLE4/bin/gradle clean build -x test"
                    sh "$GRADLE4/bin/gradle check test"
                    stash includes: '**', name: 'workspace'
                }
            }
        }
        stage('Sonar Qube Static Code Analysis ') {
            when {
                expression { return params.sonarQube}
            }
            steps {
                script {
                    withCredentials([usernamePassword(credentialsId: 'sonar-publisher', passwordVariable: 'SONAR_PASSWORD', usernameVariable: 'SONAR_USER')]) {
                        sh "$GRADLE4/bin/gradle --info sonarqube"
                        stash name: 'workspace', includes: '**/*', excludes: '**/.git,**/.git/**'
                    }
                }
            }
        }
        stage('Publish To Artifactory') {
            when {
                expression {  return params.artifactUpload }
            }
            steps {
                script {
                    deleteDir()
                    unstash 'workspace'
                    sh "ls -ltr build/libs/"
                    env.ARTIFACTORY_ORGSPACE = "${artifact_upload_to}"
                    artifactoryUtil.artifactoryUpload(this, 'alberta-uploader')
                }
            }
        }
        stage('Deploy') {
            agent { label "DTL-CF-CLI" }
            when {
                expression {  return params.deployToPCF }
            }
            steps {
                deleteDir()
                unstash 'workspace'
                script {

                    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'alberta-pcf-credentials', usernameVariable: 'ARA_USER', passwordVariable: 'ARA_PASSWORD']]) {
                        sh 'cf login -a api.system.stl.pcfstage00.mastercard.int -u "${ARA_USER}" -p "${ARA_PASSWORD}" -o Alberta -s kick-one '

                        sh "cf push tests-metadata --no-start"
                        sh "cf restage tests-metadata"
                        sh "cf start tests-metadata"
                        sh 'cf logout'

                    }
                }
            }
        }
    }
    post {
        always{
            deleteDir()
            script {
              commonUtil.echoSteps("Sending ${currentBuild.currentResult} Notification Email")
              env.RECIPIENTS = emailextrecipients([[$class: 'RequesterRecipientProvider']])
              env.EMAIL_BODY = "\nBUILD ${currentBuild.currentResult}: \n\n\n Application Deployment is ${currentBuild.currentResult} in PCF ${env.PCF_FOUNDATION} --> ${env.PCF_ORG} \n\n\nJenkins Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]' \nBuild URL: ${env.BUILD_URL}"
              emailext (
                    to: "${env.RECIPIENTS}",
                    subject: "BUILD ${currentBuild.currentResult}: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
                    body: "${env.EMAIL_BODY}"
              )
            }
        }
    }
}
