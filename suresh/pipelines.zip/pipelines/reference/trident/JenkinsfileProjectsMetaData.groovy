@Library('AlbertaUtility') _

def artifactoryUtil = new org.mastercard.alberta.ArtifactoryUtil(this)
def commonUtil = new org.mastercard.alberta.CommonUtil(this)
def fileUtil = new org.mastercard.pipeline.utility.FileUtil(this)
def setEnvironmentVars = new org.mastercard.alberta.SetEnvironmentVarsUtil(this)

// def STAGE_ENVIRONMENT = "src-stage"
// def KICK_ONE_ENVIRONMENT = "kick-one"

pipeline{
    agent { label "DTL-GRADLE" }
    options {
        buildDiscarder(logRotator(numToKeepStr: '5'))
        skipDefaultCheckout()
        timestamps()
        disableConcurrentBuilds()
        timeout(time: 3, unit: 'HOURS')
    }
    environment {
        PATH = "$PATH:$NODE6/bin:$YARN1/bin"
    }
    parameters{
        choice(
            choices: 'projects-metadata\nstash-etl-service\ntests-metadata',
            description: 'Choose a component',
            name: 'componentName'
        )
        string(
            defaultValue: "com/mastercard/trident", 
            description: 'Please Provide the group ID where you want to upload the artifact to? ', 
            name: 'artifact_upload_to'
        )
        booleanParam(
            defaultValue: false, 
            description: 'Run Sonar Qube? ', 
            name: 'sonarQube'
        )
        booleanParam(
            defaultValue: true, 
            description: 'Run aritfact upload? ', 
            name: 'artifactUpload'
        )
        booleanParam(
            defaultValue: true, 
            description: 'Deploy to PCF? ', 
            name: 'deployToPCF'
        )
    }
    stages{
        stage('Checkout') {
            steps {
                script {
                    deleteDir()
                    git branch: 'dev', url: "https://globalrepository.mclocal.int/stash/scm/alberta/${params.componentName}.git", credentialsId: 'alberta-stash-credentials'
                }
            }
        }
        stage('Initialize Environment') {
            steps {
                script {
                     
                    commonUtil.echoSteps("Reading pipelinecofig.yml file")
                    def pipelineConfigData = fileUtil.readPipelineConfig()

                    commonUtil.echoSteps("Inspecting the current configuration parameters...")
                    steps.sh 'pwd'
                    steps.sh 'ls -avlh'
                    commonUtil.echoSteps("Pipeline Config file: ${pipelineConfigData}")

                    setEnvironmentVars.setDefaultVars()
                    setEnvironmentVars.setStageVars()

                    APP_HOST_NAME = PCF_DEV_SPACE + '-' + pipelineConfigData.pipeline.hostname
                    commonUtil.echoSteps("\nGlobal Envionment Veriables: \n\nPCF Foundation: ${PCF_FOUNDATION} \nPCF ORG: ${PCF_ORG} \nPCF Dev space: ${PCF_DEV_SPACE} \nPCF Credential ID: ${PCF_CREDENTIALS} \nStash Credential ID: ${STASH_CREDENTIALS} \nArtifactory Credential ID: ${ARTIFACTORY_CREDENTIALS} \nSonar Credential ID: ${SONAR_CREDENTIALS} \nStage Branch Name: ${INTEGRATION_BRANCH} \nSynapse Client Name: ${SYNAPSE_CLIENT_NAME} \nEntry URL: ${ENTRY_URL} \nApp Host Name: ${APP_HOST_NAME} \nBuild and Test execution: ${BUILD_TEST_EXECUTION}")
                }
            }
        }
        stage('Test And Build') {
            steps {
                script {
                    sh "$GRADLE4/bin/gradle clean build -x test"
                    sh "$GRADLE4/bin/gradle check test"
                    stash includes: '**', name: 'workspace'
                }
            }
        }
        stage('Sonar Qube Static Code Analysis ') {
            when {
                expression { return params.sonarQube}
            }
            steps {
                script {
                    withCredentials([usernamePassword(credentialsId: "${env.SONAR_CREDENTIALS}", passwordVariable: 'SONAR_PASSWORD', usernameVariable: 'SONAR_USER')]) {
                        sh "$GRADLE4/bin/gradle --info sonarqube"
                        stash name: 'workspace', includes: '**/*', excludes: '**/.git,**/.git/**'
                    }
                }
            }
        }
        stage('Publish To Artifactory') {
            when {
                expression {  return params.artifactUpload }
            }
            steps {
                script {
                    deleteDir()
                    unstash 'workspace'
                    sh "ls -ltr build/libs/"
                    env.ARTIFACTORY_ORGSPACE = "${artifact_upload_to}"
                    artifactoryUtil.artifactoryUpload(this, 'alberta-uploader')
                }
            }
        }
        stage('Deploy') {
            agent { label "DTL-CF-CLI" }
            when {
                expression {  return params.deployToPCF }
            }
            steps {
                deleteDir()
                unstash 'workspace'
                script {
                    withEnv(["CF_HOME=."]) {
                        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${env.PCF_CREDENTIALS}", usernameVariable: 'ARA_USER', passwordVariable: 'ARA_PASSWORD']]) {
                            sh "cf login -a ${globalVars.STAGE_PAAS_URL} -u ${ARA_USER} -p ${ARA_PASSWORD} -o Alberta -s ${env.PCF_DEV_SPACE}"

                            sh "cf push ${APP_HOST_NAME} -n ${APP_HOST_NAME} --no-start"
                            sh "cf start ${APP_HOST_NAME}"
                            sh 'cf logout'

                        }
                    }
                }
            }
        }
    }
    post {
        always{
            deleteDir()
            script {
              commonUtil.echoSteps("Sending ${currentBuild.currentResult} Notification Email")
              env.RECIPIENTS = emailextrecipients([[$class: 'RequesterRecipientProvider']])
              env.EMAIL_BODY = "\nBUILD ${currentBuild.currentResult}: \n\n\n Application Deployment is ${currentBuild.currentResult} in PCF ${env.PCF_FOUNDATION} --> ${env.PCF_ORG} \n\n\nJenkins Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]' \nBuild URL: ${env.BUILD_URL}"
              emailext (
                    to: "${env.RECIPIENTS}",
                    subject: "BUILD ${currentBuild.currentResult}: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
                    body: "${env.EMAIL_BODY}"
              )
            }
        }
    }
}
