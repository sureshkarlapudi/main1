def nodeName = "DEVCLD-GRADLE"

pipeline {
    agent { label "${nodeName}" }
    options {
        buildDiscarder(logRotator(numToKeepStr: '20'))
        // skipDefaultCheckout()
        timestamps()
        disableConcurrentBuilds()
        timeout(time: 2, unit: 'HOURS')
    }
    environment {
        BROWSERSTACK_KEY = credentials('BrowserStackKey')
        BROWSERSTACK_USER = credentials('BrowserStackUser')
        CF_DIAL_TIMEOUT = 15
    }
    stages {
        stage('unit tests'){
            steps{
                script{
                    sh "$GRADLE4/bin/gradle test --tests com.mastercard.trident.unit.*"
                }
            }
            post{
                always{
                    publishReport('build/reports/tests/test','index.html',"Unit Test Report" )
                    publishReport('build/reports/jacoco/test/html','index.html',"Jacoco Coverage Report" )
                }
            }
        }
        stage('parallel stages'){
            parallel {
                stage('find bugs Main'){
                    agent {label "${nodeName}"}
                    steps{
                        script{
                            sh "$GRADLE4/bin/gradle findbugsMain"
                        }
                    }
                    post{
                        always{
                            publishReport('build/reports/findbugs','main.html',"Findbugs Source Code Report")
                        }
                    }
                }
                stage('find bugs Test'){
                    agent {label "${nodeName}"}
                    steps{
                        script{
                            sh "$GRADLE4/bin/gradle findbugsTest"
                        }
                    }
                    post{
                        always{
                            publishReport('build/reports/findbugs','test.html',"Findbugs Test Report")
                        }
                    }
                }
                stage('check style main'){
                    agent {label "${nodeName}"}
                    steps{
                        script{
                            sh "$GRADLE4/bin/gradle checkstyleMain"
                        }
                    }
                    post{
                        always{
                            publishReport('build/reports/checkstyle','main.html', "Checkstyle Source Code Report")
                        }
                    }
                }
                stage('check style test'){
                    agent {label "${nodeName}"}
                    steps{
                        script{
                            sh "$GRADLE4/bin/gradle checkstyleTest"
                        }
                    }
                    post{
                        always{
                            publishReport('build/reports/checkstyle','test.html', "Checkstyle Test Report")
                        }
                    }
                }
                stage('PMD Main'){
                    agent {label "${nodeName}"}
                    steps{
                        script{
                            sh "$GRADLE4/bin/gradle pmdMain"
                        }
                    }
                    post{
                        always{
                            publishReport('build/reports/pmd','main.html', "PMD Source Code Report")
                        }
                    }
                }
                stage('PMD Test'){
                    agent {label "${nodeName}"}
                    steps{
                        script{
                            sh "$GRADLE4/bin/gradle pmdTest"
                        }
                    }
                    post{
                        always{
                            publishReport('build/reports/pmd','test.html',"PMD Test Report")
                        }
                    }
                }
            }
        }
    }
    post{
        always{
            deleteDir()
            script {
              commonUtil.echoSteps("Sending ${currentBuild.currentResult} Notification Email")
              env.RECIPIENTS = emailextrecipients([[$class: 'RequesterRecipientProvider']])
              env.EMAIL_BODY = "\nBUILD ${currentBuild.currentResult}: \n\n\n Application Deployment is ${currentBuild.currentResult} in PCF ${env.PCF_FOUNDATION} --> ${env.PCF_ORG} \n\n\nJenkins Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]' \nBuild URL: ${env.BUILD_URL}"
              emailext (
                    to: "${env.RECIPIENTS}",
                    subject: "BUILD ${currentBuild.currentResult}: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
                    body: "${env.EMAIL_BODY}"
              )
            }
        }
    }
}

def publishReport(String reportDir, String reportFile, String reportName){
    publishHTML (target: [
            allowMissing: false,
            alwaysLinkToLastBuild: false,
            keepAll: true,
            reportDir: reportDir,
            reportFiles: reportFile,
            reportName: reportName
    ])
}
