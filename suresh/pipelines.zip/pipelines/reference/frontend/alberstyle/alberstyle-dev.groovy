#!groovy

def util = new org.helix.Utilities()
def pcfUtil = new org.mastercard.pipeline.utility.PCFUtil(this)

// CF Project
def pcfAppName = 'alberstyle'
// Git Repo to pull from (codebase)
def gitRepo = 'https://globalrepository.mclocal.int/stash/scm/ALBERTA/alberstyle.git'
// Git Repo branch name
def gitBranch = 'dev'
// Git Repo credentials
def gitCredentialId = '7e6798cf-2edb-43ae-be20-f26c730fae91'
def keyMap = [:]

pipeline {
  agent none
  stages {
    stage('Pull code') {
      agent { label "M3" }
      steps {
        script {
          git branch: gitBranch, credentialsId: gitCredentialId, url: gitRepo
          stash includes: '**', name: 'workspace'
        }
      }
    }

    stage('Install application dependencies') {
      agent { label 'YARN' }
      environment { PATH = "$PATH:$NODE8/bin:$YARN1/bin" }
      steps {
        script {
          unstash 'workspace'
          if (this.fileExists('yarn.lock')) {
            echo '*** replacing registry url for CI ***'
            sh "sed -i 's,https://registry.yarnpkg.com,${env.ALBERTA_ARTIFACTORY_URL}/api/npm/npm-all,g' yarn.lock"
          }
          sh "SASS_BINARY_SITE=${env.ALBERTA_ARTIFACTORY_URL}/archive-external-release/node-sass/ CYPRESS_INSTALL_BINARY=0 yarn"
          stash includes: '**', name: 'workspace'
        }
      }
    }

    stage('Run Linter') {
      agent { label 'YARN' }
      environment { PATH = "$PATH:$NODE8/bin:$YARN1/bin" }
      steps {
        script {
          unstash 'workspace'
          sh 'yarn lint'
        }
      }
    }

    stage('Build the application') {
      agent { label 'YARN' }
      environment { PATH = "$PATH:$NODE8/bin:$YARN1/bin" }
      steps {
        script {
          unstash 'workspace'
          sh 'yarn build'
        }
      }
    }

    stage('Build demo page') {
      agent { label 'YARN' }
      environment { PATH = "$PATH:$NODE8/bin:$YARN1/bin" }
      steps {
        script {
          unstash 'workspace'
          dir('demo') {
            if (this.fileExists('yarn.lock')) {
              echo '*** replacing registry url for CI ***'
              sh "sed -i 's,https://registry.yarnpkg.com,${env.ALBERTA_ARTIFACTORY_URL}/api/npm/npm-all,g' yarn.lock"
            }
            sh "SASS_BINARY_SITE=${env.ALBERTA_ARTIFACTORY_URL}/archive-external-release/node-sass/ CYPRESS_INSTALL_BINARY=0 yarn"
            sh 'yarn lint'
            sh 'yarn build'
            sh 'rm -rf node_modules'
            stash includes: '**', name: 'demo'
          }
        }
      }
    }

    stage('Deploy demo page to PCF') {
      agent { label 'DTL-CF-CLI' }
      steps {
        script {
          try {
            unstash 'demo'
            pcfUtil.deployToPCFGoRouter(
              this,
              pcfAppName,
              'stl-stage',
              'Alberta',
              'berta',
              'alberta-pcf-credentials',
              null,
              null,
              keyMap,
              false,
              false,
              null
            )
          } catch (e) {
            throw e
          }
        }
      }
    }
  }
}
