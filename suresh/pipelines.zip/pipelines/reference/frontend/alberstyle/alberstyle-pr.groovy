#!groovy

pipeline {
  agent { label 'YARN' }
  environment { PATH = "$PATH:$NODE8/bin:$YARN1/bin" }
  stages {
    stage('Install alberstyle dependencies') {
      steps {
        script {
          if (this.fileExists('yarn.lock')) {
            echo '*** replacing registry url for CI ***'
            sh "sed -i 's,https://registry.yarnpkg.com,${env.ALBERTA_ARTIFACTORY_URL}/api/npm/npm-all,g' yarn.lock"
          }
          sh "SASS_BINARY_SITE=${env.ALBERTA_ARTIFACTORY_URL}/archive-external-release/node-sass/ CYPRESS_INSTALL_BINARY=0 yarn"
        }
      }
    }

    stage('Lint alberstyle') {
      steps {
        script {
          sh 'yarn lint'
        }
      }
    }

    stage('Build alberstyle') {
      steps {
        script {
          sh 'yarn build'
        }
      }
    }

    stage('Lint and Build demo application') {
      steps {
        script {
          dir('demo') {
            if (this.fileExists('yarn.lock')) {
              echo '*** replacing registry url for CI ***'
              sh "sed -i 's,https://registry.yarnpkg.com,${env.ALBERTA_ARTIFACTORY_URL}/api/npm/npm-all,g' yarn.lock"
            }
            sh "SASS_BINARY_SITE=${env.ALBERTA_ARTIFACTORY_URL}/archive-external-release/node-sass/ CYPRESS_INSTALL_BINARY=0 yarn"
            sh 'yarn lint'
            sh 'yarn build'
          }
        }
      }
    }
  }
}
