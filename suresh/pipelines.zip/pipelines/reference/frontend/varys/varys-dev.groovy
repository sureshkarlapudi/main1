#!groovy
@Library('AlbertaUtility') _

def pcfUtil = new org.mastercard.pipeline.utility.PCFUtil(this) // configured in jenkins shared pipelines
def pcfAppName = "src-stage-varys"
def commonUtil = new org.mastercard.alberta.CommonUtil(this)
def qaUtil = new org.mastercard.alberta.QAUtil(this)
def keyMap = [:]
import java.text.SimpleDateFormat
def dateFormat = new SimpleDateFormat("yyyyMMddHHmm")
def date = new Date()
env.currentYear = dateFormat.format(date)
def YarnUtil = new org.mastercard.alberta.YarnUtil(this)
def appRollBack = false
def artifactUpload = false
env.CF_CLI_LABEL =  "DTL-CF-CLI"

pipeline {
    agent { label "DEVCLD-YARN" }
    options {
        buildDiscarder(logRotator(numToKeepStr: '20'))
        skipDefaultCheckout()  //TODO why skipping here and manually checking out the code??
        timestamps()
        disableConcurrentBuilds()
        timeout(time: 2, unit: 'HOURS')
    }
    environment {
        PATH = "$PATH:$NODE8/bin:$YARN1/bin"
        BROWSERSTACK_KEY = credentials('BrowserStackKey')
        BROWSERSTACK_USER = credentials('BrowserStackUser')
        CF_DIAL_TIMEOUT = 15
    }
    stages {
        stage('checkout'){
            steps{
                script{
                    deleteDir()
                    checkout scm //TODO why checkout again?
                    env.commit = sh(returnStdout: true, script: "git log -n 1 --pretty=format:'%h'").trim()
                    env.version = "${currentYear}-${commit}"
                }
            }
        }
        stage('Intialization'){
            steps{
                script{
                    //TODO changes when common pipeline is in place
                    env.STASH_CREDENTIALS = 'alberta-stash-credentials'
                    env.SYNAPSE_CLIENT_NAME = 'srcsystem-alberta-services'
                    env.PCF_ORG = 'Alberta'
                    env.PCF_FOUNDATION = 'stl-stage'
                    env.PCF_DEV_SPACE = 'src-stage'
                    env.PCF_CREDENTIALS = 'alberta-pcf-credentials'
                    env.ENTRY_URL = 'src-stage-cersei.apps.stl.pcfstage00.mastercard.int'
                    env.ORG_GRADLE_PROJECT_PROVIDER_PORT='443'
                    env.ORG_GRADLE_PROJECT_PROVIDER_HOST="apps.stl.pcfstage00.mastercard.int"
                    env.ORG_GRADLE_PROJECT_PROVIDER_PROTOCOL='https'
                    env.ORG_GRADLE_PROJECT_PACT_BROKER_URL = "https://int-pact-broker.apps.stl.pcfstage00.mastercard.int:443"
                    env.redisCustomPlan = 'shared-vm'
                }
            }
        }
        stage('Install dependencies') {
            steps {
                script {
                    YarnUtil.install(this)
                    stash name: 'workspace', useDefaultExcludes: false
                }
            }
        }

        stage('Publish Contract') {
            agent { label "DTL-YARN" }
            steps {
                script {
                    deleteDir()
                    unstash 'workspace'
                    sh 'yarn contract:ci'
                    sh 'PACT_BROKER_URL=https://int-pact-broker.apps.stl.pcfstage00.mastercard.int yarn contract:publish'
                }
            }
        }

      //  stage('Vet and Prepare Changes') {  TODO dont really need it
         //   parallel() {
                stage('Lint') {
                    steps {
                        script {
                            sh 'yarn lint'
                        }
                    }
                }

                stage('Unit Testing') {
                    steps {
                        script {
                            sh 'yarn unit:ci'
                        }
                    }
                }

                stage('Build') {
                    steps {
                        script {
                            sh 'yarn build:stage'
                            env.artifactName = "varys-dist-${version}.zip"
                            zip zipFile: "${artifactName}", archive: false, dir: 'dist'
                            withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "alberta-uploader", usernameVariable: 'UNAME', passwordVariable: 'PASS']]) {
                                sh "curl -X PUT -u ${UNAME}:${PASS} -T ${artifactName} ${env.ALBERTA_ARTIFACTORY_URL}/snapshots/com/mastercard/alberta/varys/stage/${artifactName}"
                            }
                            artifactUpload = true
                            env.artifactURL = "snapshots/com/mastercard/alberta/varys/stage/${artifactName}"
                            stash includes: 'dist/**/*,manifest.yml', name: 'built_workspace'
                        }
                    }
                }
          //  }
      //  }

        stage('Deploy to stl-stage alberta') {
            agent { label 'DTL-CF-CLI || DTL' }
            steps {
                script {
                    try {
                        deleteDir()
                        unstash 'built_workspace'
                        keyMap['ArtifactURL'] = "${env.artifactURL}"
                        pcfUtil.deployToPCFGoRouter(
                                this,
                                pcfAppName,
                                PCF_FOUNDATION,
                                PCF_ORG,
                                PCF_DEV_SPACE,
                                PCF_CREDENTIALS,
                                null,
                                null,
                                keyMap,
                                false,
                                false,
                                null,
                                null,
                                true// TODO: Shared Util this
                        )
                        appRollBack = true
                    } catch (e) {
                        throw e
                    }
                }
            }
        }
        stage('Execute E2E Tests Stage') {
            steps {
                script {
                    commonUtil.echoSteps("Executing E2E Tests")

                    qaUtil.executeE2ETests(this, PCF_CREDENTIALS, PCF_DEV_SPACE, ENTRY_URL, false)

                    commonUtil.echoSteps("E2E Tests Executed Successfully")
                    env.STAGE_STATUS = "E2E_TESTS"
                }
            }
            post {
                always{
                    script{
                        qaUtil.publishTestResults(this, "E2E", "Stage", "e2e", "extentreports", "report.html")
                    }
                }
            }
        }
        stage('Upload to Artifactory'){
            failFast true
            parallel() {
                stage('Upload to perf'){
                    agent { label "DEVCLD-YARN" }
                    steps{
                        script{
                            deleteDir()
                            //unstash 'workspace'
                            git branch: 'dev', url: 'https://globalrepository.mclocal.int/stash/scm/alberta/varys.git', credentialsId: 'ashok-mc'
                            sh "ls -latr"
                            YarnUtil.install(this)

                            if (steps.fileExists("config/environment.js")) {
                                applicationPcfData = steps.readFile("config/environment.js")
                                // Todo: Update this code to perform search and replace in an optimized way over replacing static value
                                applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys.apps.stl.pcfstage00.mastercard.int/, "src-perf-varys.apps.stl.pcfstage00.mastercard.int")
                                steps.writeFile(file: "config/environment.js", text: applicationPcfData)
                            }
                            sh "cat config/environment.js"
                            sh 'yarn build:stage'
                            zip zipFile: "${artifactName}", archive: false, dir: 'dist'
                            withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "alberta-uploader", usernameVariable: 'UNAME', passwordVariable: 'PASS']]) {
                                sh "curl -X PUT -u ${UNAME}:${PASS} -T ${artifactName} ${env.ALBERTA_ARTIFACTORY_URL}/snapshots/com/mastercard/alberta/varys/perf/${artifactName}"
                            }
                        }
                    }
                }
                stage('Upload to pre-prod-stl'){
                    agent { label "DEVCLD-YARN" }
                    steps{
                        script{
                            deleteDir()
                            //unstash 'workspace'
                            git branch: 'dev', url: 'https://globalrepository.mclocal.int/stash/scm/alberta/varys.git', credentialsId: 'ashok-mc'
                            sh "ls -latr"

                            YarnUtil.install(this)

                            if (steps.fileExists("config/environment.js")) {
                                applicationPcfData = steps.readFile("config/environment.js")
                                // Todo: Update this code to perform search and replace in an optimized way over replacing static value
                                applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys.apps.stl.pcfstage00.mastercard.int/, "pre-prod-varys.apps.stl.pcfprod00.mastercard.int")
                                steps.writeFile(file: "config/environment.js", text: applicationPcfData)
                            }
                            sh "cat config/environment.js"
                            sh 'yarn build:stage'
                            zip zipFile: "${artifactName}", archive: false, dir: 'dist'
                            withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "alberta-uploader", usernameVariable: 'UNAME', passwordVariable: 'PASS']]) {
                                sh "curl -X PUT -u ${UNAME}:${PASS} -T ${artifactName} ${env.ALBERTA_ARTIFACTORY_URL}/snapshots/com/mastercard/alberta/varys/pre-prod-stl/${artifactName}"
                            }
                        }
                    }
                }
                stage('Upload to pre-prod-ksc'){
                    agent { label "DEVCLD-YARN" }
                    steps{
                        script{
                            deleteDir()
                            //unstash 'workspace'
                            git branch: 'dev', url: 'https://globalrepository.mclocal.int/stash/scm/alberta/varys.git', credentialsId: 'ashok-mc'
                            sh "ls -latr"

                            YarnUtil.install(this)

                            if (steps.fileExists("config/environment.js")) {
                                applicationPcfData = steps.readFile("config/environment.js")
                                // Todo: Update this code to perform search and replace in an optimized way over replacing static value
                                applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys.apps.stl.pcfstage00.mastercard.int/, "pre-prod-varys.apps.ksc.pcfprod00.mastercard.int")
                                steps.writeFile(file: "config/environment.js", text: applicationPcfData)
                            }
                            sh "cat config/environment.js"
                            sh 'yarn build:stage'
                            zip zipFile: "${artifactName}", archive: false, dir: 'dist'
                            withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "alberta-uploader", usernameVariable: 'UNAME', passwordVariable: 'PASS']]) {
                                sh "curl -X PUT -u ${UNAME}:${PASS} -T ${artifactName} ${env.ALBERTA_ARTIFACTORY_URL}/snapshots/com/mastercard/alberta/varys/pre-prod-ksc/${artifactName}"
                            }
                        }
                    }
                }
                stage('Upload to prod-stl'){
                    agent { label "DEVCLD-YARN" }
                    steps{
                        script{
                            deleteDir()
                            //unstash 'workspace'
                            git branch: 'dev', url: 'https://globalrepository.mclocal.int/stash/scm/alberta/varys.git', credentialsId: 'ashok-mc'
                            sh "ls -latr"
                            YarnUtil.install(this)

                            if (steps.fileExists("config/environment.js")) {
                                applicationPcfData = steps.readFile("config/environment.js")
                                // Todo: Update this code to perform search and replace in an optimized way over replacing static value
                                applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys.apps.stl.pcfstage00.mastercard.int/, "prod-varys.apps.stl.pcfprod00.mastercard.int")
                                steps.writeFile(file: "config/environment.js", text: applicationPcfData)
                            }
                            sh "cat config/environment.js"
                            sh 'yarn build:stage'
                            zip zipFile: "${artifactName}", archive: false, dir: 'dist'
                            withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "alberta-uploader", usernameVariable: 'UNAME', passwordVariable: 'PASS']]) {
                                sh "curl -X PUT -u ${UNAME}:${PASS} -T ${artifactName} ${env.ALBERTA_ARTIFACTORY_URL}/snapshots/com/mastercard/alberta/varys/prod-stl/${artifactName}"
                            }
                        }
                    }
                }
                stage('Upload to prod-ksc'){
                    agent { label "DEVCLD-YARN" }
                    steps{
                        script{
                            deleteDir()
                            //unstash 'workspace'
                            git branch: 'dev', url: 'https://globalrepository.mclocal.int/stash/scm/alberta/varys.git', credentialsId: 'ashok-mc'
                            sh "ls -latr"
                            YarnUtil.install(this)

                            if (steps.fileExists("config/environment.js")) {
                                applicationPcfData = steps.readFile("config/environment.js")
                                // Todo: Update this code to perform search and replace in an optimized way over replacing static value
                                applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys.apps.stl.pcfstage00.mastercard.int/, "prod-varys.apps.ksc.pcfprod00.mastercard.int")
                                steps.writeFile(file: "config/environment.js", text: applicationPcfData)
                            }
                            sh "cat config/environment.js"
                            sh 'yarn build:stage'
                            zip zipFile: "${artifactName}", archive: false, dir: 'dist'
                            withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "alberta-uploader", usernameVariable: 'UNAME', passwordVariable: 'PASS']]) {
                                sh "curl -X PUT -u ${UNAME}:${PASS} -T ${artifactName} ${env.ALBERTA_ARTIFACTORY_URL}/snapshots/com/mastercard/alberta/varys/prod-ksc/${artifactName}"
                            }
                        }
                    }
                }
            }
        }
    }
    post {
        always {
            echo 'I have finished'
            deleteDir() // clean up workspace
            script {
              commonUtil.echoSteps("Sending ${currentBuild.currentResult} Notification Email")
              env.RECIPIENTS = emailextrecipients([[$class: 'RequesterRecipientProvider']])
              env.EMAIL_BODY = "\nBUILD ${currentBuild.currentResult}: \n\n\n Application Deployment is ${currentBuild.currentResult} in PCF ${env.PCF_FOUNDATION} --> ${env.PCF_ORG} \n\n\nJenkins Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]' \nBuild URL: ${env.BUILD_URL}"
              emailext (
                    to: "${env.RECIPIENTS}",
                    subject: "BUILD ${currentBuild.currentResult}: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
                    body: "${env.EMAIL_BODY}"
              )
            }
        }
    }
}
