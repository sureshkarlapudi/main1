#!groovy
@Library('AlbertaUtility') _

def commonUtil = new org.mastercard.alberta.CommonUtil(this)
def qaUtil = new org.mastercard.alberta.QAUtil(this)
def caasUtil = new org.mastercard.pipeline.utility.CaaSUtil(this)
def YarnUtil = new org.mastercard.alberta.YarnUtil(this)
def e2eTearDown = false

def keyMap = [:]

pipeline {
    agent { label "DEVCLD-YARN" }
    options {
        buildDiscarder(logRotator(numToKeepStr: '20'))
        skipDefaultCheckout()
        timestamps()
        disableConcurrentBuilds()
        timeout(time: 2, unit: 'HOURS')
    }
    environment {
        PATH = "$PATH:$NODE8/bin:$YARN1/bin"
        BROWSERSTACK_KEY = credentials('BrowserStackKey')
        BROWSERSTACK_USER = credentials('BrowserStackUser')
        CF_DIAL_TIMEOUT = 15
    }
    stages {
        stage('checkout'){
            steps{
                script{
                    deleteDir()
                    checkout scm
                }
            }
        }
        stage('Intialization'){
            steps{
                script{
                    env.STASH_CREDENTIALS = 'alberta-stash-credentials'
                    env.SYNAPSE_CLIENT_NAME = 'srcsystem-alberta-services'
                    env.PCF_ORG = 'SealTeam6-Stage'
                    env.PCF_FOUNDATION = 'stl-stage'
                    env.PCF_DEV_SPACE = 'pr-e2e'
                    env.PCF_CREDENTIALS = 'alberta-pcf-credentials'
                    env.ENTRY_URL = 'pr-e2e-cersei.apps.stl.pcfstage00.mastercard.int'
                    env.ORG_GRADLE_PROJECT_PROVIDER_PORT='443'
                    env.ORG_GRADLE_PROJECT_PROVIDER_HOST="apps.stl.pcfstage00.mastercard.int"
                    env.ORG_GRADLE_PROJECT_PROVIDER_PROTOCOL='https'
                    env.ORG_GRADLE_PROJECT_PACT_BROKER_URL = "https://pr-int-pact-broker.apps.stl.pcfstage00.mastercard.int:443"
                    env.redisCustomPlan = 'dedicated-vm'

                }
            }
        }
        stage('Install Dependencies') {
            steps {
                script {
                    YarnUtil.install(this)
                    stash name: 'workspace', useDefaultExcludes: false
                }
            }
        }
        stage('Publish Contract') {
            agent { label "DTL-YARN" }
            steps {
                script {
                    deleteDir()
                    unstash 'workspace'
                    sh 'yarn contract:ci'
                    sh 'PACT_BROKER_URL=https://pr-int-pact-broker.apps.stl.pcfstage00.mastercard.int yarn contract:publish'
                }
            }
        }
        stage('Lint') {
            steps {
                script {
                    sh 'yarn lint'
                }
            }
        }

        stage('Unit Testing') {
            steps {
                script {
                    sh 'yarn unit:ci'
                }
            }
        }

        stage('Build') {
            steps {
                script {
                    sh 'yarn build'
                }
            }
        }
        stage('Get Certs For PR') {
            agent { label "DTL-CAAS_CLIENT" }
            steps {
                script {
                    deleteDir()
                    commonUtil.echoSteps("Fetching certificates from CAAS")
                    caasUtil.getJKSFromCaaS(this, PCF_FOUNDATION, PCF_DEV_SPACE, keyMap, SYNAPSE_CLIENT_NAME,'varys')
                    commonUtil.echoSteps("Certificates retrieved successfully")
                }
            }
        }
        stage('Prepare E2E Tests PR') {
            steps {
                script {
                    commonUtil.echoSteps("Preparing E2E Test Environment")
                    qaUtil.prepareForE2ETests(this, PCF_CREDENTIALS, null, keyMap)
                    commonUtil.echoSteps("E2E Test Environmnet Prepared Successfully")
                    e2eTearDown = true
                }
            }
        }
        stage('Execute E2E Tests PR') {
            steps {
                script {
                    commonUtil.echoSteps("Executing E2E Tests")
                    qaUtil.executeE2ETests(this, PCF_CREDENTIALS, PCF_DEV_SPACE)
                    commonUtil.echoSteps("E2E Tests Executed Successfully")
                }
            }
            post {
                always{
                    script{
                        qaUtil.publishTestResults(this, "E2E", "PR", "e2e", "extentreports", "report.html")
                    }
                }
            }
        }
    }
    post {
        always {
            echo 'I have finished'
            if(e2eTearDown){
                // Tearing down E2E Environment
                albertaPCFUtil.deleteAppsDeployed(this, PCF_CREDENTIALS)
                albertaPCFUtil.deletePcfServiceInstance(this, PCF_CREDENTIALS)
            }
            deleteDir() // clean up workspace
            script {
              commonUtil.echoSteps("Sending ${currentBuild.currentResult} Notification Email")
              env.RECIPIENTS = emailextrecipients([[$class: 'RequesterRecipientProvider']])
              env.EMAIL_BODY = "\nBUILD ${currentBuild.currentResult}: \n\n\n Application Deployment is ${currentBuild.currentResult} in PCF ${env.PCF_FOUNDATION} --> ${env.PCF_ORG} \n\n\nJenkins Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]' \nBuild URL: ${env.BUILD_URL}"
              emailext (
                    to: "${env.RECIPIENTS}",
                    subject: "BUILD ${currentBuild.currentResult}: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
                    body: "${env.EMAIL_BODY}"
              )
            }
        }
    }
}
