_Time to reduce duplication :)_
