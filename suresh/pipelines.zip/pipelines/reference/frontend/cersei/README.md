# Cersei Pipelines

_Specifics for the cersei pipeline scripts will go here_

cersei-dev: the pipeline for the dev branch
cersei-pr: the pipeline for all pull requests
