#!groovy
@Library('AlbertaUtility') _

def commonUtil = new org.mastercard.alberta.CommonUtil(this)
def qaUtil = new org.mastercard.alberta.QAUtil(this)
def caasUtil = new org.mastercard.pipeline.utility.CaaSUtil(this)
def YarnUtil = new org.mastercard.alberta.YarnUtil(this)


def keyMap = [:]

pipeline {
    agent { label "DEVCLD-YARN" }
    options {
        buildDiscarder(logRotator(numToKeepStr: '20'))
        skipDefaultCheckout()
        timestamps()
        disableConcurrentBuilds()
        timeout(time: 2, unit: 'HOURS')
    }
    environment {
        PATH = "$PATH:$NODE8/bin:$YARN1/bin"
        BROWSERSTACK_KEY = credentials('BrowserStackKey')
        BROWSERSTACK_USER = credentials('BrowserStackUser')
        CF_DIAL_TIMEOUT = 15
    }
    stages {
        stage('checkout'){
            steps{
                script{
                    deleteDir()
                    checkout scm //  TODO why checking out again?
                    env.currentGitBranch = env.BRANCH_NAME
                    stash name: 'workspace', useDefaultExcludes: false
                }
            }
        }
        stage('Intialization'){
            steps{
                script{

                    commonUtil.echoSteps("Reading pipelinecofig.yml file")
                    def pipelineConfigData = fileUtil.readPipelineConfig()

                    commonUtil.echoSteps("Reading environmentconfig.yml")
                    def envConfiguration = fileUtil.readEnvironmentsConfig()

                    commonUtil.echoSteps("Inspecting the current configuration parameters...")
                    steps.sh 'pwd'
                    steps.sh 'ls -avlh'
                    commonUtil.echoSteps("Pipeline Config file: ${pipelineConfigData}")
                    commonUtil.echoSteps("Environment Config file: ${envConfiguration}")

                    commonUtil.echoSteps("Current git branch: - ${currentGitBranch}")

                    setEnvironmentVars.setDefaultVars()

                    if ( currentGitBranch == INTEGRATION_BRANCH) {
                        setEnvironmentVars.setStageVars()
                    } else if ( currentGitBranch != INTEGRATION_BRANCH ) {
                        setEnvironmentVars.setPrVars()
                    }

                    if(env.jobType == VALIDATION_JOB_TYPE){
                        setEnvironmentVars.setValidationJobVars(VALIDATION_JOB_TYPE)
                    }

                    APP_HOST_NAME = PCF_DEV_SPACE + '-' + pipelineConfigData.pipeline.hostname
                    env.SERVICE_TYPE = pipelineConfigData.pipeline.serviceType

                    commonUtil.echoSteps("\nGlobal Envionment Veriables: \n\nPCF Foundation: ${PCF_FOUNDATION} \nPCF ORG: ${PCF_ORG} \nPCF Dev space: ${PCF_DEV_SPACE} \nPCF Credential ID: ${PCF_CREDENTIALS} \nStash Credential ID: ${STASH_CREDENTIALS} \nArtifactory Credential ID: ${ARTIFACTORY_CREDENTIALS} \nSonar Credential ID: ${SONAR_CREDENTIALS} \nStage Branch Name: ${INTEGRATION_BRANCH} \nSynapse Client Name: ${SYNAPSE_CLIENT_NAME} \nEntry URL: ${ENTRY_URL} \nApp Host Name: ${APP_HOST_NAME} \nBuild and Test execution: ${BUILD_TEST_EXECUTION}\nSERVICE_TYPE: ${SERVICE_TYPE}")
                    if(null == env.startStage){
                        commonUtil.echoSteps("WARNING: No environment start stage found. Replacing value with zero.")
                        env.startStage = 0
                    }

                    startStage = "${env.startStage}".toInteger()

                    if(null == env.endStage){
                        commonUtil.echoSteps("WARNING: No environment end stage found. Replacing value with zero.")
                        env.endStage = 0
                    }

                    endStage = "${env.endStage}".toInteger()

                    env.STAGE_STATUS = "INITIALIZE_ENV"
                    steps.sh "printenv"

                }
            }
        }
        stage('Install Dependencies') {
            steps {
                script {
                    YarnUtil.install(this)
                    stash name: 'workspace', useDefaultExcludes: false
                }
            }
        }
        stage('Configure') {
            steps {
                script {
                    // TODO: Use Alberta shared libs for pcf information and parameter-tize
                    def cerseiHost = 'https://cersei.apps.stl.pcfstage00.mastercard.int'
                    def varysHost = 'https://varys.apps.stl.pcfstage00.mastercard.int'
                    DotEnvUtil.create(cerseiHost, varysHost)
                }
            }
        }
        stage('Publish Contract') {
            agent { label "DTL-YARN" }
            steps {
                script {
                    deleteDir()
                    unstash 'workspace'
                    sh 'yarn contract:ci'
                    sh 'PACT_BROKER_URL=https://pr-int-pact-broker.apps.stl.pcfstage00.mastercard.int yarn contract:publish'
                }
            }
        }
        stage('Lint') {
            steps {
                script {
                    sh 'yarn lint'
                }
            }
        }

        stage('Unit Testing') {
            steps {
                script {
                    sh 'yarn unit:ci'
                }
            }
        }

        stage('Build') {
            steps {
                script {
                    sh 'yarn build'
                }
            }
        }
        stage('Get Certs For PR') {
            agent { label "DTL-CAAS_CLIENT" }
            steps {
                script {
                    deleteDir()
                    commonUtil.echoSteps("Fetching certificates from CAAS")
                    caasUtil.getJKSFromCaaS(this, PCF_FOUNDATION, PCF_DEV_SPACE, keyMap, SYNAPSE_CLIENT_NAME, APP_HOST_NAME)
                    commonUtil.echoSteps("Certificates retrieved successfully")
                }
            }
        }
        stage('Prepare E2E Tests PR') {
            steps {
                script {
                    commonUtil.echoSteps("Preparing E2E Test Environment")
                    qaUtil.prepareForE2ETests(this, PCF_CREDENTIALS, null, keyMap)
                    commonUtil.echoSteps("E2E Test Environmnet Prepared Successfully")
                }
            }
        }
        stage('Execute E2E Tests PR') {
            steps {
                script {
                    commonUtil.echoSteps("Executing E2E Tests")
                    qaUtil.executeE2ETests(this, PCF_CREDENTIALS, PCF_DEV_SPACE)
                    commonUtil.echoSteps("E2E Tests Executed Successfully")
                }
            }
            post {
                always{
                    script{
                        qaUtil.publishTestResults(this, "E2E", "PR", "e2e", "extentreports", "report.html")
                    }
                }
            }
        }
    }
    post {
        always {
            echo 'I have finished'
            deleteDir() // clean up workspace
            script {
              commonUtil.echoSteps("Sending ${currentBuild.currentResult} Notification Email")
              env.RECIPIENTS = emailextrecipients([[$class: 'RequesterRecipientProvider']])
              env.EMAIL_BODY = "\nBUILD ${currentBuild.currentResult}: \n\n\n Application Deployment is ${currentBuild.currentResult} in PCF ${env.PCF_FOUNDATION} --> ${env.PCF_ORG} \n\n\nJenkins Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]' \nBuild URL: ${env.BUILD_URL}"
              emailext (
                    to: "${env.RECIPIENTS}",
                    subject: "BUILD ${currentBuild.currentResult}: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'",
                    body: "${env.EMAIL_BODY}"
              )
            }
        }
    }
}
