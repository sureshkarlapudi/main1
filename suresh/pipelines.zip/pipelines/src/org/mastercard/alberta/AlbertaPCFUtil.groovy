package org.mastercard.alberta


/**
 * PCF Utility functions used to extend functionality of pipeline related to PCF
 *
 * @Author neel.shah@mastercard.com
 */

class AlbertaPCFUtil implements Serializable {

    /**
     * a reference to the pipeline that allows you to run pipeline steps in your shared libary
     */
    def steps

    /**
     * Constructor
     *
     * @param steps a reference to the pipeline that allows you to run pipeline steps in your shared libary
     */
    public AlbertaPCFUtil(steps) { this.steps = steps }

    /**
     * Get the Foundation name to be used during the build for PCF
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param customFoundation optional to allow providing custom foundation name for PCF Environment, default value is "stl-stage"
     * @return pcfFoundation the foundation name for PCF Environment where all applications should be deployed
     */
    public getPcfFoundation(script, String customFoundation = null) {
        def defaultPcfFoundation = "stl-stage"
        if (!customFoundation) {
            if (!script.PCF_FOUNDATION) {
                return defaultPcfFoundation
            }
            return script.PCF_FOUNDATION
        }
        return customFoundation
    }

    /**
     * Get the URL for the Foundation specified to be used during the build for PCF
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param pcfFoundation the foundation name for PCF Environment where all applications should be deployed
     * @return paas_url the login url for the given PCF Foundation
     */
    public getPcfFoundationUrl(script, String pcfFoundation = null) {
        def paas_url
        if (!pcfFoundation) {
            pcfFoundation = getPcfFoundation(script)
        }
        switch (pcfFoundation) {
            case 'stl-dev': paas_url = script.globalVars.DEV_PAAS_URL; break;
            case 'stl-stage': paas_url = script.globalVars.STAGE_PAAS_URL; break;
            case 'bel-prod': paas_url = script.globalVars.BEL_PROD_PAAS_URL; break;
            case 'stl-prod': paas_url = script.globalVars.STL_PROD_PAAS_URL; break;
            case 'ksc-prod': paas_url = script.globalVars.KSC_PROD_PAAS_URL; break;
        }
        return paas_url
    }

    /**
     * Get the Domain name for the Foundation specified to be used during the build for PCF
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param pcfFoundation the foundation name for PCF Environment where all applications should be deployed
     * @return appDomain the main app domain for the given PCF Foundation
     */
    public getPcfFoundationDomain(script, String pcfFoundation = null) {
        def appDomain
        if (!pcfFoundation) {
            pcfFoundation = getPcfFoundation(script)
        }
        switch (pcfFoundation) {
            case 'stl-dev': appDomain = steps.globalVars.DEV_PAAS_DOMAIN; break
            case 'stl-stage': appDomain = steps.globalVars.STAGE_PAAS_DOMAIN; break
            case 'bel-prod': appDomain = steps.globalVars.BEL_PROD_PAAS_DOMAIN; break
            case 'stl-prod': appDomain = steps.globalVars.STL_PROD_PAAS_DOMAIN; break
            case 'ksc-prod': appDomain = steps.globalVars.KSC_PROD_PAAS_DOMAIN; break
        }
        return appDomain
    }

    /**
     * Get the Org name to be used during the build for PCF
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param customOrg optional to allow providing custom org name in PCF Foundation, default value is "Alberta" org
     * @return pcfOrg the org name in PCF Foundation where all applications should be deployed
     */
    public getPcfOrg(script, String customOrg = null) {
        def defaultPcfOrg = "Alberta"
        if (!customOrg) {
            if (!script.PCF_ORG) {
                return defaultPcfOrg
            }
            return script.PCF_ORG
        }
        return customOrg
    }

    /**
     * Get the End to End Test Environment Space name based on Pull Request or non Pull Request build for PCF from the Pipeline script using pipelineconfig.yml file
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @return it will return the PCF Space Name where the app should be deployed based on a pull request or regular branch build job
     */
    
    public getE2ESpaceName(script, String customSpace = null) {
        def defaultPcfSpace = "pr-e2e"
        if (!customSpace) {
            if (!script.PCF_DEV_SPACE) {
                return defaultPcfSpace
            }
            return script.PCF_DEV_SPACE
        }
        return customSpace
    }

    /**
     * Get the Integration Test Environment Space name based on Pull Request or non Pull Request build for PCF
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @return it will return the PCF Space Name where the app should be deployed based on a pull request or regular branch build job
     */
    public getIntSpaceName(script) {
        def prIntSpaceName = "pr-int"
        def intSpaceName = "src-stage"


        if (script.env.CHANGE_ID) {
            // This is the name of the space in PCF when it is a Pull Request
            return prIntSpaceName
        }
        // This is the name of the space in PCF when it is NOT a Pull Request
        return script.PCF_DEV_SPACE

    }

    /**
     * Get the list of Services required to be created for all components before deploying them to PCF
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param pcfServicesList optional comma separated value for list of all services from marketplace required to be created before deploying apps to PCF
     * @return pcfServicesList list of all services that need to be created in PCF before deploying apps
     */
    public getPcfServicesList(script, String pcfServicesList = null) {
        // it is a comma separated value
        def defaultServicesList = "redis"

        if (!pcfServicesList) {
            if (!script.env.PCF_SERVICES) {

                def manifestData = steps.readYaml file: "manifest.yml"
                def services = manifestData.applications["services"][0]
                pcfServicesList = ""

                if (services) {
                    def serviceListSize = services.size()
                    for (def i=0; i<serviceListSize; i++) {
                        pcfServicesList = pcfServicesList + "," + services[i]
                    }
                }

                if (!pcfServicesList) {
                    return defaultServicesList
                }
                else {
                    return pcfServicesList
                }
            }
            return script.env.PCF_SERVICES
        }
        else {
            return pcfServicesList
        }
    }

    /**
     * Set custom PCF route name for a pre existing app deployed to PCF in given Org and Space
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param pcfCredentials name of the credentialsId you want to use to access pcf and git
     * @param appHostName current host name for the app which already exists and needs to be mapped
     * @param newSubDomain new host name or sub domain to be mapped to the same app
     * @param path new path at the end of domain to be mapped with the application
     */
    public void setCustomPcfRoute(script, String pcfCredentials, String appHostName, String newSubDomain, String path = null) {
        def appDomain = getPcfFoundationDomain(script)

        steps.node('DTL-CF-CLI') {
            steps.withEnv(["CF_HOME=."]) {
                try {
                    pcfAuthenticate(script, pcfCredentials)
                    if ( ! path ) {
                        steps.sh "cf map-route ${appHostName} ${appDomain} -n ${newSubDomain}"
                    }
                    else {
                        steps.sh "cf map-route ${appHostName} ${appDomain} -n ${newSubDomain} --path ${path}"
                    }
                } finally {
                    steps.sh "cf logout"
                }
            }
        }
    }

    /**
     * Update manifest.yml file with the new hostname and app name if provided
     *
     * @param newAppHostName
     * @param newAppName
     */
    public void renameAppInManifest(String newAppHostName, String newAppName = null) {
        // TODO: Need to use "readYaml" and "writeYaml" instead of "readFile" then replacing ocurrence of string and writeFile to update file.
        if (steps.fileExists("manifest.yml")) {
            def manifestData = steps.readFile("manifest.yml")
            manifestData = manifestData.replaceAll(/host:[a-zA-Z0-9. \/-]+/, "host: ${newAppHostName}")
            if ( ! newAppName ) {
                newAppName = newAppHostName
            }
            manifestData = manifestData.replaceAll(/name:[a-zA-Z0-9. \/-]+/, "name: ${newAppName}")
            steps.writeFile(file: "manifest.yml", text: manifestData)
        }
    }

    /**
     * Update manifest.yml file with the new service name based on the suffix
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param mainAppHostName host name of the main app which triggered the build as that will be suffixed to the service name
     */
    public void renameServicesInManifest(script, String newAppHostName, String mainAppHostName = null) {
        def servicesList = getPcfServicesList(script).tokenize(',')

        if (steps.fileExists("manifest.yml")) {
            def manifestData = steps.readFile("manifest.yml")
            for (service in servicesList) {
                // Todo: should be improved in a way to pass the service name variable in the regex itself to avoid code duplication for each service name
             //    if (service.contains('redis')) {
             //       manifestData = manifestData.replaceAll(/-[a-zA-Z0-9. \/-]*redis[a-zA-Z0-9. \/-]*/, "- redis-${newAppHostName}")
             //   }
                if (service.contains('config')) {
                    if (mainAppHostName) {
                        manifestData = manifestData.replaceAll(/-[a-zA-Z0-9. \/-]*config[a-zA-Z0-9. \/-]*/, "- config-server-${mainAppHostName}")
                    }
                    else {
                        manifestData = manifestData.replaceAll(/-[a-zA-Z0-9. \/-]*config[a-zA-Z0-9. \/-]*/, "- config-server-${newAppHostName}")
                    }
                }
                if (service.contains('autoscale')) {
                    manifestData = manifestData.replaceAll(/-[a-zA-Z0-9. \/-]*autoscale[a-zA-Z0-9. \/-]*/, "- autoscaler-${newAppHostName}")
                }
                if (service.contains('rabbitmq')) {
                    manifestData = manifestData.replaceAll(/-[a-zA-Z0-9. \/-]*rabbitmq[a-zA-Z0-9. \/-]*/, "- rabbitmq-${newAppHostName}")
                }
            }
            steps.writeFile(file: "manifest.yml", text: manifestData)
        }
    }

    /**
     * Delete all the apps deployed and their routes during the utility functions one by one from the given org and space in PCF
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param pcfCredentials name of the credentialsId you want to use to access pcf and git
     */
    public void deleteAppsDeployed(script, String pcfCredentials, Boolean intTest = false) {
        def pcfFoundation = getPcfFoundation(script)
        def pcfOrg = getPcfOrg(script)
        def pcfSpace = intTest == false ? getE2ESpaceName(script) : getIntSpaceName(script)

        def listOfAppsDeployed = ""

        if ( intTest ) {
            steps.echo "list of Apps deployed until now are: ${script.env.LIST_OF_APPS_DEPLOYED_INT}"
            listOfAppsDeployed = script.env.LIST_OF_APPS_DEPLOYED_INT
        } else {
            steps.echo "list of Apps deployed until now are: ${script.env.LIST_OF_APPS_DEPLOYED_E2E}"
            listOfAppsDeployed = script.env.LIST_OF_APPS_DEPLOYED_E2E
        }
        
        if ( ! listOfAppsDeployed ) {
            return
        }
        def appsList = listOfAppsDeployed.tokenize(',')

        steps.echo "Deleting the apps deployed during this pipeline to ${pcfFoundation} -> ${pcfOrg} -> ${pcfSpace}"
        steps.node('DTL-CF-CLI') {
            steps.withEnv(["CF_HOME=."]) {
                try {
                    pcfAuthenticate(script, pcfCredentials, intTest)
                    for (item in appsList) {
                        try {
                            steps.sh "cf delete ${item} -f -r"
                        } catch (Exception ex) {
                            steps.echo "${ex}"
                            steps.echo "Error trying to delete app ${item} from PCF in ${pcfFoundation} -> ${pcfOrg} -> ${pcfSpace}"
                        }
                    }
                } finally {
                    steps.sh "cf logout"
                }
            }
        }
    }
    /**
     * Authenticate cf cli using given credentials, foundation, org and space name
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param pcfCredentials name of the credentialsId you want to use to access pcf and git
     */
    public void pcfAuthenticate(script, String pcfCredentials, Boolean intTest = false) {
        def pcfFoundation = getPcfFoundation(script)
        def paas_url = getPcfFoundationUrl(script, pcfFoundation)
        def pcfOrg = getPcfOrg(script)
        def pcfSpace = intTest == false ? getE2ESpaceName(script) : getIntSpaceName(script)

                steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${pcfCredentials}", usernameVariable: 'PCF_USERNAME', passwordVariable: 'PCF_PASSWORD']]) {
                    steps.sh "cf login -a ${paas_url} -u ${script.PCF_USERNAME} -p ${script.PCF_PASSWORD} -o ${pcfOrg} -s ${pcfSpace}"
                }
    }

    /**
     * Create a new service instance for the given service name in PCF and set a custom name to it by suffixing host name of main app to the service name
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param pcfCredentials name of the credentialsId you want to use to access pcf and git
     * @param mainAppHostName host name of the main app which triggered the build as that will be suffixed to the service name
     * @param servicePlan optional if want to set custom service plan other than default small-plan
     */
    public void createPcfServiceInstance(script, String pcfCredentials, String mainAppHostName, String customRedisServicePlan = null, Boolean intTest = false) {
        def pcfFoundation = getPcfFoundation(script)
        def pcfOrg = getPcfOrg(script)
        def pcfSpace = intTest == false ? getE2ESpaceName(script) : getIntSpaceName(script)
        def servicesList = getPcfServicesList(script).tokenize(',')
        def serviceType = ""
        def serviceName = ""
        def servicePlan = ""

        if ( ! servicesList ) {
            steps.echo "There are no services to be created in PCF"
            return
        }
        else {
            steps.echo "Creating service instances required in PCF ${pcfFoundation} -> ${pcfOrg} -> ${pcfSpace}"
            steps.node('DTL-CF-CLI') {
                steps.withEnv(["CF_HOME=."]) {
                    try {
                        pcfAuthenticate(script, pcfCredentials, intTest)
                        for (service in servicesList) {
                            if ( ! customRedisServicePlan ) {
                                if ( service.matches(/.*redis.*/) ) {
                                    servicePlan = "dedicated-vm"
                                }
                                else {
                                    servicePlan = "standard"
                                }
                            }
                            else {
                                if ( service.matches(/.*redis.*/) ) {
                                    servicePlan = customRedisServicePlan
                                }
                                else {
                                    servicePlan = "standard"
                                }
                            }

                            if ( service.matches(/.*redis.*/) ) {
                               // serviceType = "redis"
                               // service = "redis"
                            }
                            if (service.matches(/.*autoscale.*/)) {
                                serviceType = "app-autoscaler"
                                service = "autoscaler"
                            }

                            if ( service.matches(/.*config.*/) ) {
                                if (intTest) {
                                    createConfigServerInstance(script, pcfCredentials, mainAppHostName, intTest)
                                }
                            }
                            else {
                                if(serviceName) {
                                    serviceName = "${service}-${mainAppHostName}"
                                }

                                if (!intTest) {
                                    script.env.LIST_OF_SERVICES_DEPLOYED_E2E = "${script.env.LIST_OF_SERVICES_DEPLOYED_E2E},${serviceName}"
                                    steps.echo "list of Services deployed until now are: ${script.env.LIST_OF_SERVICES_DEPLOYED_E2E}"
                                }
                                else {
                                    script.env.LIST_OF_SERVICES_DEPLOYED_INT = "${script.env.LIST_OF_SERVICES_DEPLOYED_INT},${serviceName}"
                                    steps.echo "list of Services deployed until now are: ${script.env.LIST_OF_SERVICES_DEPLOYED_INT}"
                                }
                                if(serviceName){
                                    steps.sh "cf create-service p-${serviceType} ${servicePlan} ${serviceName}"
                                    checkServiceStatus(script, serviceName)
                                }

                            }
                        }
                    }  
                    catch (e) {
                        throw e
                    }
                    finally {
                        steps.sh "cf logout"
                    }
                }
            }
        }
    }

    /**
     * Create a new service instance for the given service name in PCF and set a custom name to it by suffixing host name of main app to the service name
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param pcfCredentials name of the credentialsId you want to use to access pcf and git
     * @param mainAppHostName host name of the main app which triggered the build as that will be suffixed to the service name
     */
    public void createConfigServerInstance(script, String pcfCredentials, String mainAppHostName, Boolean intTest = false) {
        def pcfFoundation = getPcfFoundation(script)
        def pcfOrg = getPcfOrg(script)
        def pcfSpace = intTest == false ? getE2ESpaceName(script) : getIntSpaceName(script)
        def pcfConfigServerName = "config-server-${mainAppHostName}"
        def pcfGitEAServerName = "${pcfSpace}-gitea-${mainAppHostName}"
        def appDomain = script.globalVars.stageDomain
        
        steps.echo "Creating Config Server Service Instance required in PCF ${pcfFoundation} -> ${pcfOrg} -> ${pcfSpace}"
        steps.node('DTL-CF-CLI') {
            steps.withEnv(["CF_HOME=."]) {
                try {
                    steps.echo "Deploying gitEA Server as an app in PCF ${pcfFoundation} -> ${pcfOrg} -> ${pcfSpace}"
                    steps.echo "Name of gitEA Server to be Deploed: ${pcfGitEAServerName}"

                    createGitEAServerInstance(script, pcfCredentials, pcfSpace, mainAppHostName, pcfGitEAServerName, intTest)

                    if (!intTest) {
                        script.env.LIST_OF_SERVICES_DEPLOYED_E2E = "${script.env.LIST_OF_SERVICES_DEPLOYED_E2E},${pcfConfigServerName}"
                        steps.echo "list of Services deployed until now are: ${script.env.LIST_OF_SERVICES_DEPLOYED_E2E}"
                    }
                    else {
                        script.env.LIST_OF_SERVICES_DEPLOYED_INT = "${script.env.LIST_OF_SERVICES_DEPLOYED_INT},${pcfConfigServerName}"
                        steps.echo "list of Services deployed until now are: ${script.env.LIST_OF_SERVICES_DEPLOYED_INT}"
                    }

                    pcfAuthenticate(script, pcfCredentials, intTest)
                    steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'gitEA_repo_creds', usernameVariable: 'gitEA_USERNAME', passwordVariable: 'gitEA_PASSWORD']]) {
                        steps.sh "cf create-service p-config-server standard ${pcfConfigServerName} -c '{\"git\": { \"uri\": \"https://${pcfGitEAServerName}.${appDomain}/${steps.gitEA_USERNAME}/config-repo.git\", \"username\": \"${steps.gitEA_USERNAME}\", \"password\": \"${steps.gitEA_PASSWORD}\", \"cloneOnStart\": true} }' "

                    }


                    checkServiceStatus(script, pcfConfigServerName)
                }
                catch (e) {
                    throw e
                }
                finally {
                    steps.sh "cf logout"
                }
            }
        }
    }

    /**
     * Create a new gitEA server instance in PCF and set a custom name to it by suffixing host name of main app to the instance name
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param pcfCredentials name of the credentialsId you want to use to access pcf and git
     * @param mainAppHostName host name of the main app which triggered the build as that will be suffixed to the service name
     */
    public void createGitEAServerInstance(script, String pcfCredentials, String pcfSpace, String mainAppHostName, String pcfGitEAServerName, Boolean intTest = false) {
        def configRepoSCM = script.globalVars.configRepoSCM
        def branchConfigRepoSCM = script.globalVars.branchConfigRepoSCM
        def gitEAServiceRepoSCM = script.globalVars.gitEAServiceRepoSCM
        def branchGitEAServiceRepoSCM = script.globalVars.branchGitEAServiceRepoSCM
        def configRepoDir = "config-repo"
        def gitEAServerRepoDir = "gitea-service-repo"
        def configServerWorkspace = "${pcfSpace}-config-server-workspace"
        def configurationEnvironment = ""

        if ( script.env.CHANGE_ID ) {
            configurationEnvironment = script.globalVars.prConfigurationEnvironment
        }
        else {
            configurationEnvironment = script.globalVars.stageConfigurationEnvironment
        }
        steps.node('DTL-CF-CLI') {

        try {
            steps.echo "Creating GITEA Server Service"
            if(!steps.fileExists("${configServerWorkspace}")) {
                steps.sh "mkdir -p ${configServerWorkspace}"
            }
            steps.sh "ls -lrta ${configServerWorkspace}/"
            steps.sh "rm -rf ${configServerWorkspace}/*"
            steps.sh "ls -lrta ${configServerWorkspace}/"
            steps.dir("${configServerWorkspace}") {
                steps.echo "Checking Out PCF-GIT-SERVICE Repository"
                steps.git branch: "${branchConfigRepoSCM}", url: "${configRepoSCM}", credentialsId: "${pcfCredentials}"

                if(!steps.fileExists("${gitEAServerRepoDir}")) {
                    steps.sh "mkdir ${gitEAServerRepoDir}"
                }

                steps.dir("${gitEAServerRepoDir}") {
                    steps.git branch: "${branchGitEAServiceRepoSCM}", url: "${gitEAServiceRepoSCM}", credentialsId: "${pcfCredentials}"
                    steps.sh "rm -rf ${configRepoDir}"
                    if(!steps.fileExists("${configRepoDir}")) {
                        steps.sh "mkdir ${configRepoDir}"
                    }
                }

                steps.sh "rm -rf ${configServerWorkspace}/${gitEAServerRepoDir}/${configRepoDir}/*"
                steps.sh "cp -a ${configurationEnvironment}/. ${gitEAServerRepoDir}/${configRepoDir}/"

                steps.withEnv(["CF_HOME=."]) {
                    steps.dir("${gitEAServerRepoDir}") {
                        steps.dir("${configRepoDir}") {

                           // setConfigServerRedisReference(script, mainAppHostName)

                            if (!intTest) {
                               setConfigServerbackendAppReference(script, mainAppHostName)
                            }
                            steps.sh "git init"
                            steps.sh "git add ."
                            steps.sh "git commit -m 'Loaded Config Repo Files from ${pcfSpace} Environment to gitEA Server'"
                        }
                        steps.sh "ls -lrta scripts/"
                        steps.sh "ls -lrta ${configRepoDir}/"

                        steps.sh "ls -lrta examples/"
                        steps.sh "echo ${mainAppHostName} >> examples/sample.txt"
                        steps.sh "cat examples/sample.txt"

                        pcfAuthenticate(script, pcfCredentials, intTest)

                        steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'gitEA_repo_creds', usernameVariable: 'gitEA_USERNAME', passwordVariable: 'gitEA_PASSWORD']]) {
                            steps.sh "scripts/gitSvcCtl.sh ${configRepoDir} ${steps.gitEA_PASSWORD} -s"

                        }

                    }
                }
                if (!intTest) {
                    script.env.LIST_OF_APPS_DEPLOYED_E2E = "${script.env.LIST_OF_APPS_DEPLOYED_E2E},${pcfGitEAServerName}"
                    steps.echo "list of Apps deployed until now are: ${script.env.LIST_OF_APPS_DEPLOYED_E2E}"
                }
                else {
                    script.env.LIST_OF_APPS_DEPLOYED_INT = "${script.env.LIST_OF_APPS_DEPLOYED_INT},${pcfGitEAServerName}"
                    steps.echo "list of Apps deployed until now are: ${script.env.LIST_OF_APPS_DEPLOYED_INT}"
                }
            }
        }
        catch (e) {
            throw e
        }
        finally {
            steps.sh "cf logout"
        }
      }
    }

    /**
     * Delete instance of services created during this build from the servicesList in PCF
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param pcfCredentials name of the credentialsId you want to use to access pcf and git
     */
    public void deletePcfServiceInstance(script, String pcfCredentials, Boolean intTest = false) {
        def pcfFoundation = getPcfFoundation(script)
        def pcfOrg = getPcfOrg(script)
        def pcfSpace = intTest == false ? getE2ESpaceName(script) : getIntSpaceName(script)

        def listOfServicesDeployed = ""
        
        if ( intTest ) {
            listOfServicesDeployed = script.env.LIST_OF_SERVICES_DEPLOYED_INT
        } else {
            listOfServicesDeployed = script.env.LIST_OF_SERVICES_DEPLOYED_E2E
        }

        if ( ! listOfServicesDeployed ) {
            return
        }
        
        def serviceList = listOfServicesDeployed.tokenize(',')

        steps.echo "Deleting all the Services deployed during this pipeline to ${pcfFoundation} -> ${pcfOrg} -> ${pcfSpace}"
        steps.node('DTL-CF-CLI') {
            steps.withEnv(["CF_HOME=."]) {
                try {
                    pcfAuthenticate(script, pcfCredentials, intTest)
                    for (item in serviceList) {
                        try {
                            steps.sh "cf delete-service -f ${item}"
                        } catch (Exception ex) {
                            steps.echo "${ex}"
                            steps.echo "Error trying to delete Service ${item} from PCF in ${pcfFoundation} -> ${pcfOrg} -> ${pcfSpace}"
                        }
                    }
                } finally {
                    steps.sh "cf logout"
                }
            }
        }
    }

    /**
     * Check the status of service instances created during this build from the servicesList in PCF
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param serviceName name of the pcf marketplace service created from list of service dependencies in manifest.yml file
     */
    public void checkServiceStatus(script, String serviceName) {
        def getStatus = ""
        def serviceStatus = ""

        for (def waitTime=30; waitTime>0; waitTime--) {

            getStatus = steps.sh(returnStdout: true, script: "cf service ${serviceName}").trim()

            if (getStatus.contains('create in progress')) {
                serviceStatus = "PROGRESS"
            } else if (getStatus.contains('create succeeded')) {
                serviceStatus = "SUCCESS"
            } else if (getStatus.contains('create failed')) {
                serviceStatus = "FAILURE"
            }

            switch (serviceStatus) {
                case 'PROGRESS': steps.echo "Service: '${serviceName}' creation is still in 'PROGRESS'..."; steps.sh "sleep ${waitTime}"; break;
                case 'SUCCESS': steps.echo "Service: '${serviceName}' Successfully Created."; waitTime=0; break;
                case 'FAILURE': steps.echo "Service: '${serviceName}' creation 'FAILED'..."; waitTime=0; break;
            }
        }
    }

    /**
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param mainAppHostName host name of the main app which triggered the build as that will be suffixed to the name of the redis service
     */
    public void setConfigServerbackendAppReference(script, String mainAppHostName) {
        def applicationPcfData = ""
        // Todo: Update this code to perform search and replace in an optimized way over replacing static value
        if (steps.fileExists("srci-merchantdata-services.yml")) {
            applicationPcfData = steps.readYaml(file: "srci-merchantdata-services.yml")
            if (applicationPcfData['merchantstore']['callbackurl']){
                applicationPcfData['merchantstore']['callbackurl'] = "https://mrt-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/#/callback"
            }
            steps.writeYaml file: 'tmpsrci-merchantdata-services.yml', data: applicationPcfData
            steps.sh "mv tmpsrci-merchantdata-services.yml srci-merchantdata-services.yml"
        }

        if ( mainAppHostName.matches(/.*durable-data-service.*/) || mainAppHostName.matches(/.*mdes-facade.*/) || mainAppHostName.matches(/.*remote-logging-service.*/) || mainAppHostName.matches(/.*srci-middleware.*/) || mainAppHostName.matches(/.*srci-merchantdata.*/) || mainAppHostName.matches(/.*checkout-service.*/) || mainAppHostName.matches(/.*precheckout-service.*/) || mainAppHostName.matches(/.*consumer-service.*/) ||  mainAppHostName.matches(/.*utility-service.*/) || mainAppHostName.matches(/.*app-instance-service.*/) ) {
            if (steps.fileExists("utility-service.yml")) {

            applicationPcfData = steps.readYaml(file: "utility-service.yml")
            if (applicationPcfData['dcf']['client']['origin']){
                applicationPcfData['dcf']['client']['origin'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            if (applicationPcfData['srci']['client']['origin']){
                applicationPcfData['srci']['client']['origin'] = "https://cersei-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpUtility-service.yml', data: applicationPcfData
            steps.sh "mv tmpUtility-service.yml utility-service.yml"
            steps.sh "cat utility-service.yml"
            }
        }
        
        if ( mainAppHostName.matches(/.*cersei.*/)) {
            setConfigServerbackendAppReferenceCersei(mainAppHostName)
        }
        if ( mainAppHostName.matches(/.*varys.*/)) {
            setConfigServerbackendAppReferenceVarys(mainAppHostName)
        }
        if ( mainAppHostName.matches(/.*mdes-facade.*/)) {
            setConfigServerbackendAppReferenceMdesFacade(mainAppHostName)
        }
        if (mainAppHostName.matches(/.*srci-merchantdata.*/)) {
            setConfigServerbackendAppReferenceMerchant(mainAppHostName)
        }
        if(mainAppHostName.matches(/.*checkout-service.*/)){
             setConfigServerbackendAppReferenceCheckout(mainAppHostName)
        }
        if(mainAppHostName.matches(/.*consumer-service.*/)){
            setConfigServerbackendAppReferenceConsumer(mainAppHostName)
        }
        if(mainAppHostName.matches(/.*utility-service.*/) ){
            setConfigServerbackendAppReferenceUtility(mainAppHostName)
        }
        if ( mainAppHostName.matches(/.*durable-data-service.*/)  || mainAppHostName.matches(/.*srci-middleware.*/) || mainAppHostName.matches(/.*remote-logging-service.*/) || mainAppHostName.matches(/.*precheckout-service.*/) || mainAppHostName.matches(/.*app-instance-service.*/) ) {
            setConfigServerbackendAppReferenceGeneral(mainAppHostName)
        }

    }
    
    public void setConfigServerbackendAppReferenceCersei(String mainAppHostName){
        def applicationPcfData =''
        if (steps.fileExists("durabledataservices.yml")) {
            applicationPcfData = steps.readFile("durabledataservices.yml")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys/,"varys-${mainAppHostName}")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-cersei/,"${mainAppHostName}")
            steps.writeFile(file: "durabledataservices.yml", text: applicationPcfData)

            applicationPcfData = steps.readYaml(file: "durabledataservices.yml")
            applicationPcfData['card']['facade']['base']['url'] = "https://mf-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/v1/api"
            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpDurabledataservices.yml', data: applicationPcfData
            steps.sh "mv tmpDurabledataservices.yml durabledataservices.yml"
        }
        if (steps.fileExists("srci-middleware.yml")) {
            applicationPcfData = steps.readFile("durabledataservices.yml")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys/,"varys-${mainAppHostName}")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-cersei/,"${mainAppHostName}")
            steps.writeFile(file: "durabledataservices.yml", text: applicationPcfData)

            applicationPcfData = steps.readYaml(file: "srci-middleware.yml")

            applicationPcfData['merchant']['dataservice']['url'] = "https://smds-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/merchantdata/"
            applicationPcfData['merchant']['dataservice']['actuator']['health'] = "https://smds-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/actuator/health"
            applicationPcfData['checkout']['service']['base']['url'] = "https://cs-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/checkout"
            applicationPcfData['checkout']['service']['actuator']['health'] = "https://cs-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/actuator/health"

            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpsrci-middleware.yml', data: applicationPcfData
            steps.sh "mv tmpsrci-middleware.yml srci-middleware.yml"
        }
        if (steps.fileExists("precheckout-service.yml")) {
            applicationPcfData = steps.readFile("precheckout-service.yml")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys/,"varys-${mainAppHostName}")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-cersei/,"${mainAppHostName}")
            steps.writeFile(file: "precheckout-service.yml", text: applicationPcfData)

            applicationPcfData = steps.readYaml(file: "precheckout-service.yml")
            applicationPcfData['card']['facade']['base']['url'] = "https://mf-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/v1/api"
            applicationPcfData['utilityService']['base']['url'] = "https://us-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            applicationPcfData['utilityService']['actuator']['health'] = "https://us-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/actuator/health"
            applicationPcfData['consumer']['service']['base']['url'] = "https://con-svc-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpPrecheckout-service.yml', data: applicationPcfData
            steps.sh "mv tmpPrecheckout-service.yml precheckout-service.yml"
        }
        if (steps.fileExists("checkout-service.yml")) {
            applicationPcfData = steps.readYaml(file: "checkout-service.yml")
            applicationPcfData['card']['facade']['base']['url'] = "https://mf-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/v1/api"
            applicationPcfData['utilityService']['base']['url'] = "https://us-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            applicationPcfData['consumerService']['base']['url'] = "https://con-svc-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpPrecheckout-service.yml', data: applicationPcfData
            steps.sh "mv tmpPrecheckout-service.yml checkout-service.yml"
        }
        if (steps.fileExists("utility-service.yml")) {

            applicationPcfData = steps.readYaml(file: "utility-service.yml")
            if (applicationPcfData['dcf']['client']['origin']){
                applicationPcfData['dcf']['client']['origin'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            if (applicationPcfData['srci']['client']['origin']){
                applicationPcfData['srci']['client']['origin'] = "https://${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpUtility-service.yml', data: applicationPcfData
            steps.sh "mv tmpUtility-service.yml utility-service.yml"
            steps.sh "cat utility-service.yml"
        }
    }

    public void setConfigServerbackendAppReferenceVarys(String mainAppHostName){
        def applicationPcfData =''
        if (steps.fileExists("durabledataservices.yml")) {
            applicationPcfData = steps.readFile("durabledataservices.yml")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys/,"${mainAppHostName}")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-cersei/,"cersei-${mainAppHostName}")
            steps.writeFile(file: "durabledataservices.yml", text: applicationPcfData)

            applicationPcfData = steps.readYaml(file: "durabledataservices.yml")
            applicationPcfData['card']['facade']['base']['url'] = "https://mf-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/v1/api"
            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpDurabledataservices.yml', data: applicationPcfData
            steps.sh "mv tmpDurabledataservices.yml durabledataservices.yml"
        }
        if (steps.fileExists("srci-middleware.yml")) {
            applicationPcfData = steps.readFile("durabledataservices.yml")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys/,"${mainAppHostName}")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-cersei/,"cersei-${mainAppHostName}")
            steps.writeFile(file: "durabledataservices.yml", text: applicationPcfData)

            applicationPcfData = steps.readYaml(file: "srci-middleware.yml")

            applicationPcfData['merchant']['dataservice']['url'] = "https://smds-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/merchantdata/"
            applicationPcfData['merchant']['dataservice']['actuator']['health'] = "https://smds-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/actuator/health"
            applicationPcfData['checkout']['service']['base']['url'] = "https://cs-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/checkout"
            applicationPcfData['checkout']['service']['actuator']['health'] = "https://cs-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/actuator/health"

            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpsrci-middleware.yml', data: applicationPcfData
            steps.sh "mv tmpsrci-middleware.yml srci-middleware.yml"
        }
        if (steps.fileExists("precheckout-service.yml")) {
            applicationPcfData = steps.readFile("precheckout-service.yml")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys/,"${mainAppHostName}")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-cersei/,"cersei-${mainAppHostName}")
            steps.writeFile(file: "precheckout-service.yml", text: applicationPcfData)

            applicationPcfData = steps.readYaml(file: "precheckout-service.yml")
            applicationPcfData['card']['facade']['base']['url'] = "https://mf-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/v1/api"
            applicationPcfData['utilityService']['base']['url'] = "https://us-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            applicationPcfData['utilityService']['actuator']['health'] = "https://us-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/actuator/health"
            applicationPcfData['consumer']['service']['base']['url'] = "https://con-svc-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpPrecheckout-service.yml', data: applicationPcfData
            steps.sh "mv tmpPrecheckout-service.yml precheckout-service.yml"
        }
        if (steps.fileExists("checkout-service.yml")) {
            applicationPcfData = steps.readYaml(file: "checkout-service.yml")
            applicationPcfData['card']['facade']['base']['url'] = "https://mf-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/v1/api"
            applicationPcfData['utilityService']['base']['url'] = "https://us-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            applicationPcfData['consumerService']['base']['url'] = "https://con-svc-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpPrecheckout-service.yml', data: applicationPcfData
            steps.sh "mv tmpPrecheckout-service.yml checkout-service.yml"
        }
        if (steps.fileExists("utility-service.yml")) {

            applicationPcfData = steps.readYaml(file: "utility-service.yml")
            if (applicationPcfData['dcf']['client']['origin']){
                applicationPcfData['dcf']['client']['origin'] = "https://${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            if (applicationPcfData['srci']['client']['origin']){
                applicationPcfData['srci']['client']['origin'] = "https://cersei-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpUtility-service.yml', data: applicationPcfData
            steps.sh "mv tmpUtility-service.yml utility-service.yml"
            steps.sh "cat utility-service.yml"
        }
    }

    public void setConfigServerbackendAppReferenceMdesFacade(String mainAppHostName){
        def applicationPcfData =''
        if (steps.fileExists("durabledataservices.yml")) {
            applicationPcfData = steps.readFile("durabledataservices.yml")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys/,"varys-${mainAppHostName}")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-cersei/,"cersei-${mainAppHostName}")
            steps.writeFile(file: "durabledataservices.yml", text: applicationPcfData)

            applicationPcfData = steps.readYaml(file: "durabledataservices.yml")
            applicationPcfData['card']['facade']['base']['url'] = "https://${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/v1/api"
            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpDurabledataservices.yml', data: applicationPcfData
            steps.sh "mv tmpDurabledataservices.yml durabledataservices.yml"
        }
        if (steps.fileExists("srci-middleware.yml")) {
            applicationPcfData = steps.readFile("durabledataservices.yml")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys/,"varys-${mainAppHostName}")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-cersei/,"cersei-${mainAppHostName}")
            steps.writeFile(file: "durabledataservices.yml", text: applicationPcfData)

            applicationPcfData = steps.readYaml(file: "srci-middleware.yml")

            applicationPcfData['merchant']['dataservice']['url'] = "https://smds-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/merchantdata/"
            applicationPcfData['merchant']['dataservice']['actuator']['health'] = "https://smds-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/actuator/health"
            applicationPcfData['checkout']['service']['base']['url'] = "https://cs-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/checkout"
            applicationPcfData['checkout']['service']['actuator']['health'] = "https://cs-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/actuator/health"

            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpsrci-middleware.yml', data: applicationPcfData
            steps.sh "mv tmpsrci-middleware.yml srci-middleware.yml"
        }
        if (steps.fileExists("precheckout-service.yml")) {
            applicationPcfData = steps.readFile("precheckout-service.yml")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys/,"varys-${mainAppHostName}")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-cersei/,"cersei-${mainAppHostName}")
            steps.writeFile(file: "precheckout-service.yml", text: applicationPcfData)

            applicationPcfData = steps.readYaml(file: "precheckout-service.yml")
            applicationPcfData['card']['facade']['base']['url'] = "https://${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/v1/api"
            applicationPcfData['utilityService']['base']['url'] = "https://us-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            applicationPcfData['utilityService']['actuator']['health'] = "https://us-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/actuator/health"
            applicationPcfData['consumer']['service']['base']['url'] = "https://con-svc-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpPrecheckout-service.yml', data: applicationPcfData
            steps.sh "mv tmpPrecheckout-service.yml precheckout-service.yml"
        }
        if (steps.fileExists("checkout-service.yml")) {
            applicationPcfData = steps.readYaml(file: "checkout-service.yml")
            applicationPcfData['card']['facade']['base']['url'] = "https://${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/v1/api"
            applicationPcfData['utilityService']['base']['url'] = "https://us-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            applicationPcfData['consumerService']['base']['url'] = "https://con-svc-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpPrecheckout-service.yml', data: applicationPcfData
            steps.sh "mv tmpPrecheckout-service.yml checkout-service.yml"
        }
    }

    public void setConfigServerbackendAppReferenceMerchant(String mainAppHostName){
        def applicationPcfData = ''
        if (steps.fileExists("durabledataservices.yml")) {
            applicationPcfData = steps.readFile("durabledataservices.yml")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys/,"varys-${mainAppHostName}")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-cersei/,"cersei-${mainAppHostName}")
            steps.writeFile(file: "durabledataservices.yml", text: applicationPcfData)

            applicationPcfData = steps.readYaml(file: "durabledataservices.yml")
            applicationPcfData['card']['facade']['base']['url'] = "https://mf-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/v1/api"
            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpDurabledataservices.yml', data: applicationPcfData
            steps.sh "mv tmpDurabledataservices.yml durabledataservices.yml"

        }
        if (steps.fileExists("srci-middleware.yml")) {
            applicationPcfData = steps.readYaml(file: "srci-middleware.yml")

            applicationPcfData['merchant']['dataservice']['url'] = "https://${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/merchantdata/"
            applicationPcfData['merchant']['dataservice']['actuator']['health'] = "https://${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/actuator/health"
            applicationPcfData['checkout']['service']['base']['url'] = "https://cs-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/checkout"
            applicationPcfData['checkout']['service']['actuator']['health'] = "https://cs-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/actuator/health"

            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpsrci-middleware.yml', data: applicationPcfData
            steps.sh "mv tmpsrci-middleware.yml srci-middleware.yml"
        }
        if (steps.fileExists("precheckout-service.yml")) {
            applicationPcfData = steps.readFile("precheckout-service.yml")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys/,"varys-${mainAppHostName}")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-cersei/,"cersei-${mainAppHostName}")
            steps.writeFile(file: "precheckout-service.yml", text: applicationPcfData)

            applicationPcfData = steps.readYaml(file: "precheckout-service.yml")
            applicationPcfData['card']['facade']['base']['url'] = "https://mf-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/v1/api"
            applicationPcfData['utilityService']['base']['url'] = "https://us-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            applicationPcfData['utilityService']['actuator']['health'] = "https://us-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/actuator/health"
            applicationPcfData['consumer']['service']['base']['url'] = "https://con-svc-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpPrecheckout-service.yml', data: applicationPcfData
            steps.sh "mv tmpPrecheckout-service.yml precheckout-service.yml"
        }
        if (steps.fileExists("checkout-service.yml")) {
            applicationPcfData = steps.readYaml(file: "checkout-service.yml")
            applicationPcfData['card']['facade']['base']['url'] = "https://mf-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/v1/api"
            applicationPcfData['utilityService']['base']['url'] = "https://us-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            applicationPcfData['consumerService']['base']['url'] = "https://con-svc-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpcheckout-service.yml', data: applicationPcfData
            steps.sh "mv tmpcheckout-service.yml checkout-service.yml"
        }
    }
    
    public void setConfigServerbackendAppReferenceCheckout(String mainAppHostName){
        def applicationPcfData =''
        if (steps.fileExists("durabledataservices.yml")) {
            applicationPcfData = steps.readFile("durabledataservices.yml")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys/,"varys-${mainAppHostName}")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-cersei/,"cersei-${mainAppHostName}")
            steps.writeFile(file: "durabledataservices.yml", text: applicationPcfData)

            applicationPcfData = steps.readYaml(file: "durabledataservices.yml")
            applicationPcfData['card']['facade']['base']['url'] = "https://mf-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/v1/api"
            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpDurabledataservices.yml', data: applicationPcfData
            steps.sh "mv tmpDurabledataservices.yml durabledataservices.yml"
        }
        if (steps.fileExists("srci-middleware.yml")) {
            applicationPcfData = steps.readFile("durabledataservices.yml")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys/,"varys-${mainAppHostName}")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-cersei/,"cersei-${mainAppHostName}")
            steps.writeFile(file: "durabledataservices.yml", text: applicationPcfData)

            applicationPcfData = steps.readYaml(file: "srci-middleware.yml")

            applicationPcfData['merchant']['dataservice']['url'] = "https://smds-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/merchantdata/"
            applicationPcfData['merchant']['dataservice']['actuator']['health'] = "https://smds-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/actuator/health"
            applicationPcfData['checkout']['service']['base']['url'] = "https://${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/checkout"
            applicationPcfData['checkout']['service']['actuator']['health'] = "https://${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/actuator/health"

            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpsrci-middleware.yml', data: applicationPcfData
            steps.sh "mv tmpsrci-middleware.yml srci-middleware.yml"
        }
        if (steps.fileExists("precheckout-service.yml")) {
            applicationPcfData = steps.readFile("precheckout-service.yml")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys/,"varys-${mainAppHostName}")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-cersei/,"cersei-${mainAppHostName}")
            steps.writeFile(file: "precheckout-service.yml", text: applicationPcfData)

            applicationPcfData = steps.readYaml(file: "precheckout-service.yml")
            applicationPcfData['card']['facade']['base']['url'] = "https://mf-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/v1/api"
            applicationPcfData['utilityService']['base']['url'] = "https://us-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            applicationPcfData['utilityService']['actuator']['health'] = "https://us-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/actuator/health"
            applicationPcfData['consumer']['service']['base']['url'] = "https://con-svc-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpPrecheckout-service.yml', data: applicationPcfData
            steps.sh "mv tmpPrecheckout-service.yml precheckout-service.yml"
        }
        if (steps.fileExists("checkout-service.yml")) {
            applicationPcfData = steps.readYaml(file: "checkout-service.yml")
            applicationPcfData['card']['facade']['base']['url'] = "https://mf-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/v1/api"
            applicationPcfData['utilityService']['base']['url'] = "https://us-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            applicationPcfData['consumerService']['base']['url'] = "https://con-svc-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpPrecheckout-service.yml', data: applicationPcfData
            steps.sh "mv tmpPrecheckout-service.yml checkout-service.yml"
        }
    }
    
    public void setConfigServerbackendAppReferenceConsumer(String mainAppHostName){
        def applicationPcfData =''
        if (steps.fileExists("durabledataservices.yml")) {
            applicationPcfData = steps.readFile("durabledataservices.yml")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys/,"varys-${mainAppHostName}")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-cersei/,"cersei-${mainAppHostName}")
            steps.writeFile(file: "durabledataservices.yml", text: applicationPcfData)

            applicationPcfData = steps.readYaml(file: "durabledataservices.yml")
            applicationPcfData['card']['facade']['base']['url'] = "https://mf-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/v1/api"
            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpDurabledataservices.yml', data: applicationPcfData
            steps.sh "mv tmpDurabledataservices.yml durabledataservices.yml"
        }
        if (steps.fileExists("srci-middleware.yml")) {
            applicationPcfData = steps.readFile("durabledataservices.yml")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys/,"varys-${mainAppHostName}")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-cersei/,"cersei-${mainAppHostName}")
            steps.writeFile(file: "durabledataservices.yml", text: applicationPcfData)

            applicationPcfData = steps.readYaml(file: "srci-middleware.yml")

            applicationPcfData['merchant']['dataservice']['url'] = "https://smds-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/merchantdata/"
            applicationPcfData['merchant']['dataservice']['actuator']['health'] = "https://smds-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/actuator/health"
            applicationPcfData['checkout']['service']['base']['url'] = "https://${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/checkout"
            applicationPcfData['checkout']['service']['actuator']['health'] = "https://${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/actuator/health"

            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpsrci-middleware.yml', data: applicationPcfData
            steps.sh "mv tmpsrci-middleware.yml srci-middleware.yml"
        }
        if (steps.fileExists("precheckout-service.yml")) {
            applicationPcfData = steps.readFile("precheckout-service.yml")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys/,"varys-${mainAppHostName}")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-cersei/,"cersei-${mainAppHostName}")
            steps.writeFile(file: "precheckout-service.yml", text: applicationPcfData)

            applicationPcfData = steps.readYaml(file: "precheckout-service.yml")
            applicationPcfData['card']['facade']['base']['url'] = "https://mf-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/v1/api"
            applicationPcfData['utilityService']['base']['url'] = "https://us-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            applicationPcfData['utilityService']['actuator']['health'] = "https://us-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/actuator/health"
            applicationPcfData['consumer']['service']['base']['url'] = "https://${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpPrecheckout-service.yml', data: applicationPcfData
            steps.sh "mv tmpPrecheckout-service.yml precheckout-service.yml"
        }
        if (steps.fileExists("checkout-service.yml")) {
            applicationPcfData = steps.readYaml(file: "checkout-service.yml")
            applicationPcfData['card']['facade']['base']['url'] = "https://mf-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/v1/api"
            applicationPcfData['utilityService']['base']['url'] = "https://us-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            applicationPcfData['consumerService']['base']['url'] = "https://${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpPrecheckout-service.yml', data: applicationPcfData
            steps.sh "mv tmpPrecheckout-service.yml checkout-service.yml"
        }
    }

    public void setConfigServerbackendAppReferenceUtility(String mainAppHostName){
        def applicationPcfData =''
        if (steps.fileExists("durabledataservices.yml")) {
            applicationPcfData = steps.readFile("durabledataservices.yml")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys/,"varys-${mainAppHostName}")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-cersei/,"cersei-${mainAppHostName}")
            steps.writeFile(file: "durabledataservices.yml", text: applicationPcfData)

            applicationPcfData = steps.readYaml(file: "durabledataservices.yml")
            applicationPcfData['card']['facade']['base']['url'] = "https://mf-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/v1/api"
            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpDurabledataservices.yml', data: applicationPcfData
            steps.sh "mv tmpDurabledataservices.yml durabledataservices.yml"
        }
        if (steps.fileExists("srci-middleware.yml")) {
            applicationPcfData = steps.readFile("durabledataservices.yml")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys/,"varys-${mainAppHostName}")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-cersei/,"cersei-${mainAppHostName}")
            steps.writeFile(file: "durabledataservices.yml", text: applicationPcfData)

            applicationPcfData = steps.readYaml(file: "srci-middleware.yml")

            applicationPcfData['merchant']['dataservice']['url'] = "https://smds-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/merchantdata/"
            applicationPcfData['merchant']['dataservice']['actuator']['health'] = "https://smds-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/actuator/health"
            applicationPcfData['checkout']['service']['base']['url'] = "https://${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/checkout"
            applicationPcfData['checkout']['service']['actuator']['health'] = "https://${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/actuator/health"

            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpsrci-middleware.yml', data: applicationPcfData
            steps.sh "mv tmpsrci-middleware.yml srci-middleware.yml"
        }
        if (steps.fileExists("precheckout-service.yml")) {
            applicationPcfData = steps.readFile("precheckout-service.yml")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys/,"varys-${mainAppHostName}")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-cersei/,"cersei-${mainAppHostName}")
            steps.writeFile(file: "precheckout-service.yml", text: applicationPcfData)

            applicationPcfData = steps.readYaml(file: "precheckout-service.yml")
            applicationPcfData['card']['facade']['base']['url'] = "https://mf-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/v1/api"
            applicationPcfData['utilityService']['base']['url'] = "https://${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            applicationPcfData['utilityService']['actuator']['health'] = "https://${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/actuator/health"
            applicationPcfData['consumer']['service']['base']['url'] = "https://con-svc-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpPrecheckout-service.yml', data: applicationPcfData
            steps.sh "mv tmpPrecheckout-service.yml precheckout-service.yml"
        }
        if (steps.fileExists("checkout-service.yml")) {
            applicationPcfData = steps.readYaml(file: "checkout-service.yml")
            applicationPcfData['card']['facade']['base']['url'] = "https://mf-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/v1/api"
            applicationPcfData['utilityService']['base']['url'] = "https://${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            applicationPcfData['consumerService']['base']['url'] = "https://con-svc-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpPrecheckout-service.yml', data: applicationPcfData
            steps.sh "mv tmpPrecheckout-service.yml checkout-service.yml"
        }
    }

    public void setConfigServerbackendAppReferenceGeneral(String mainAppHostName){
        def applicationPcfData =''
        if (steps.fileExists("durabledataservices.yml")) {
            applicationPcfData = steps.readFile("durabledataservices.yml")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys/,"varys-${mainAppHostName}")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-cersei/,"cersei-${mainAppHostName}")
            steps.writeFile(file: "durabledataservices.yml", text: applicationPcfData)

            applicationPcfData = steps.readYaml(file: "durabledataservices.yml")
            applicationPcfData['card']['facade']['base']['url'] = "https://mf-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/v1/api"
            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpDurabledataservices.yml', data: applicationPcfData
            steps.sh "mv tmpDurabledataservices.yml durabledataservices.yml"
        }
        if (steps.fileExists("srci-middleware.yml")) {
            applicationPcfData = steps.readFile("durabledataservices.yml")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys/,"varys-${mainAppHostName}")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-cersei/,"cersei-${mainAppHostName}")
            steps.writeFile(file: "durabledataservices.yml", text: applicationPcfData)

            applicationPcfData = steps.readYaml(file: "srci-middleware.yml")

            applicationPcfData['merchant']['dataservice']['url'] = "https://smds-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/merchantdata/"
            applicationPcfData['merchant']['dataservice']['actuator']['health'] = "https://smds-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/actuator/health"
            applicationPcfData['checkout']['service']['base']['url'] = "https://cs-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/checkout"
            applicationPcfData['checkout']['service']['actuator']['health'] = "https://cs-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/actuator/health"

            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpsrci-middleware.yml', data: applicationPcfData
            steps.sh "mv tmpsrci-middleware.yml srci-middleware.yml"
        }
        if (steps.fileExists("precheckout-service.yml")) {
            applicationPcfData = steps.readFile("precheckout-service.yml")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys/,"varys-${mainAppHostName}")
            applicationPcfData = applicationPcfData.replaceAll(/src-stage-cersei/,"cersei-${mainAppHostName}")
            steps.writeFile(file: "precheckout-service.yml", text: applicationPcfData)

            applicationPcfData = steps.readYaml(file: "precheckout-service.yml")
            applicationPcfData['card']['facade']['base']['url'] = "https://mf-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/v1/api"
            applicationPcfData['utilityService']['base']['url'] = "https://us-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            applicationPcfData['utilityService']['actuator']['health'] = "https://us-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api/actuator/health"
            applicationPcfData['consumer']['service']['base']['url'] = "https://con-svc-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpPrecheckout-service.yml', data: applicationPcfData
            steps.sh "mv tmpPrecheckout-service.yml precheckout-service.yml"
        }
        if (steps.fileExists("checkout-service.yml")) {
            applicationPcfData = steps.readYaml(file: "checkout-service.yml")
            applicationPcfData['card']['facade']['base']['url'] = "https://mf-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/v1/api"
            applicationPcfData['utilityService']['base']['url'] = "https://us-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            applicationPcfData['consumerService']['base']['url'] = "https://con-svc-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int/api"
            if (applicationPcfData['dcfUrl']){
                applicationPcfData['dcfUrl'] = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
            }
            steps.writeYaml file: 'tmpPrecheckout-service.yml', data: applicationPcfData
            steps.sh "mv tmpPrecheckout-service.yml checkout-service.yml"
        }
    }

    /**
     * Check the status of service instances created during this build from the servicesList in PCF
     *
     * @param serviceName name of the pcf marketplace service created from list of service dependencies in manifest.yml file
     */
    public Boolean isServiceCreated(String serviceName) {
        def serviceInfo = null

        for (def waitTime=30; waitTime>0; waitTime--) {

            serviceInfo = steps.sh(returnStdout: true, script: "cf service ${serviceName}").trim()

            if (serviceInfo.contains('create in progress')) {
                steps.echo "Service: '${serviceName}' creation is still in 'PROGRESS'..."
                steps.sh "sleep ${waitTime}"
            } else if (serviceInfo.contains('create succeeded')) {
                steps.echo "Service: '${serviceName}' Successfully Created."
                return true
            } else if (serviceInfo.contains('create failed')) {
                steps.echo "Service: '${serviceName}' creation 'FAILED'..."
                return false
            }
        }

        return false
    }

    /**
     * This function is used to validate a list of apps provided by the user. A valid list is a list that contains all apps that exist
     * in the requested space. If at least one app doesn't exist, the function will exit the program.
     *
     * @param appNameList a list of app names the user has provided
     */
    public void validateAppNameList(List appNameList){
        def allAppsList = steps.sh(returnStdout: true, script: "cf apps")
        
        appNameList.each { appName ->
            if(!allAppsList.contains(appName)) {
                steps.echo("ERROR: The app name provided as ${appName} does not exist.")
                steps.echo("MESSAGE: Make sure the app name given is written correctly and input format using commas is correct.")
                steps.echo("Aborting pipeline now.")
                steps.sh("exit 1")
            }
        }
        steps.echo("All application names have been found.")
    }

    /**
     * This function is used to validate the app names provided by the user. A valid list is one where all apps are currently running.
     * If at least one app isn't running, the function will exit the program.
     *
     * @param appNameList a list of app names the user has provided
     */
    public void validateAppsAreRunning(List appNameList){
        appNameList.each { appName ->
            def appStatus = steps.sh(returnStdout: true, script: "cf app ${appName}")
            
            // this seems like it could have a lot of issues. Like what if the app name has the word started then it will return true
            if(!appStatus.contains("started")) {
                steps.echo("ERROR: The app ${appName} is not running. It needs to be running for this pipeline.")
                steps.echo("MESSAGE: Run the command 'cf start <app-name>'.")
                steps.echo("Aborting pipeline now.")
                steps.sh("exit 1")
            }
        }   
        steps.echo("All applications are running.")
    }

    /**
     * This function is used to set the necessary environment variables to an app in order to bind a service
     *
     * @param envVars a list of dictionaries that hold the environment name and the environment value
     * @param appName the name of the app to enable to service to
     * @param serviceName the name of the service to bind the app to
     */
    public void enableService(Map[] envVars, String appName, String serviceName) {
        envVars.each{ envVar -> 
            steps.sh "cf set-env ${appName} ${envVar.name} ${envVar.value}"
        }

        steps.sh "cf bind-service ${appName} ${serviceName}"
    }

    /**
     * This function is used to unset the necessary environment variables to an app in order to bind a service
     *
     * @param envVars a list of dictionaries that hold the environment name and the environment value
     * @param appName the name of the app to disable to service to
     * @param serviceName the name of the service to unbind the app to
     */
    public void disableService(Map[] envVars, String appName, String serviceName) {
        envVars.each{envVar -> 
            steps.sh "cf unset-env ${appName} ${envVar.name}"
        }

        steps.sh "cf unbind-service ${appName} ${serviceName}"
    }

    /**
     * This function is used to check if an app already uses a service or not
     *
     * @param appName the name of the app that does or does not have the service
     * @param serviceName the name of the service to check against the app's services
     */
    public Boolean isServiceBoundToApp(String serviceName, String appName) {
        def serviceInfo = steps.sh(returnStdout: true, script: "cf service ${serviceName}")
        if(serviceInfo.contains("${appName}")){
            return true
        }

        else false
    }
    
}

