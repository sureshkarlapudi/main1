package org.mastercard.alberta

/**
 * Utility to install dependencies with Yarn
 * Re-Writes the lock file url's to work with artifacory
 */
class YarnUtil implements Serializable {
    def steps

    /**
    * Constructor
    *
    * @param steps A reference to the steps in a pipeline to give access to them in the shared library.
    */
    public YarnUtil(steps) { this.steps = steps }

    /**
    * method to install npm dependencies with yarn
    *
    * @param nodeSassUrl optional reference to the nodeSass Location in artifactory
    * @param skipCypress optional defaults to 1 which means skip
    * TODO: add url for cypress when available or refactor this stuff out entirely
    * Reference Docs: https://docs.cypress.io/guides/getting-started/installing-cypress.html#Advanced
    */
    public void install(
        script,
        String nodeSassUrl = "${steps.env.ALBERTA_ARTIFACTORY_URL}/archive-external-release/node-sass/",
        String installCypress = '0' // TODO: Make boolean so its less confusing
        ) {
        // FIXME: Its probably better to make this entire module only re-write the lock.file
        // -> Then we can just pass in an arbitrary string and use it as a command prefix
        // -> Then you can modify the install command however you'd like for your app
        // -> However, for now these are pretty alberta specific

        def sassCommandPrefix = 'SASS_BINARY_SITE='
        def CypressCommandPrefix = 'CYPRESS_INSTALL_BINARY='

        def sassCommand = "${sassCommandPrefix}" + nodeSassUrl

        def skipCypressCommand = "${CypressCommandPrefix}" + installCypress	// Use CYPRESS_INSTALL_BINARY=0 to skip Cypress install for Cypress Version >= 3.0.0, and CYPRESS_SKIP_BINARY_INSTALL=1 for lesser versions

        def message = """
        Setting following build CL args:
    
        ${sassCommand}
        ${skipCypressCommand}
        """

        steps.echo "${message}"

        if (script.fileExists('yarn.lock')) {

            if ( script.env.YARN_LABEL != "DEVCLD-YARN" ) {
                steps.echo "*** Replacing Registry URLs in yarn.lock file, since ${script.env.YARN_LABEL} Jenkins Agent is used ***"

                steps.sh "sed -i 's,https://registry.yarnpkg.com,${steps.env.ALBERTA_ARTIFACTORY_URL}/api/npm/npm-all,g' yarn.lock"
                steps.sh "sed -i 's,https://registry.npmjs.org,${steps.env.ALBERTA_ARTIFACTORY_URL}/api/npm/npm-all,g' yarn.lock"
                steps.sh "sed -i 's,http://registry.npmjs.org,${steps.env.ALBERTA_ARTIFACTORY_URL}/api/npm/npm-all,g' yarn.lock"
            }
            else {
                steps.echo "*** Node Packages can be downloaded from outside of 'globalrepository.mclocal.int', since ${script.env.YARN_LABEL} Jenkins Agent is used ***"
            }

            // Execute Yarn install command
            steps.sh "${sassCommand} ${skipCypressCommand} yarn"

        }
        else {
            steps.echo " *** ERROR: NO YARN.LOCK FILE FOUND ***"
            steps.sh "exit 1"
        }
    }
}
