// TODO: Fill this out to match new Westeros Monorepo
// TODO: Expand this when Varys is moved and we have more than one Cersei Deployable
// Other pipelines can use these generic steps

// notes:
// Monorepo wide helper method that will build and deploy apps for other teams
