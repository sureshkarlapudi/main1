
/**
 * org.mastercard.alberta is a collection of alberta utility tasks for jenkins DSL to perform pipeline related tasks.
 **/

package org.mastercard.alberta
import java.text.SimpleDateFormat

/**
 * Frontend Utility functions used to extend functionality of pipeline
 *
 * @Author Veera.Mallipudi@mastercard.com
 **/
class FrontendUtil implements Serializable {

    /**
     * a reference to the pipeline that allows us to run pipeline steps in our shared library
     **/
    def steps
    def fileUtil
    def setEnvironmentVars
    def dotEnvUtil
    def yarnUtil
    def commonUtil
    def dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm")
    def date = new Date()
    def currentYear = dateFormat.format(date)
    def pcfUtil

    /**
     * Constructor
     *
     * @param steps a reference to the pipeline that allows us to run pipeline steps in our shared library
     **/
    public FrontendUtil(steps) {
        this.steps = steps
        this.commonUtil = new CommonUtil(steps)
        this.setEnvironmentVars = new SetEnvironmentVarsUtil(steps)
        this.dotEnvUtil = new DotEnvUtil(steps)
        this.yarnUtil = new YarnUtil(steps)
        this.fileUtil = new org.mastercard.pipeline.utility.FileUtil(steps)
        this.pcfUtil = new org.mastercard.pipeline.utility.PCFUtil(steps)
    }

    /**
     * Perform a normal Checkout if pipeline is running for Stage
     *
     */
    public void stageCheckout( script ) {

        commonUtil.echoSteps("Checking Out SCM Repository")
        steps.checkout steps.scm
        script.env.COMMIT = steps.sh(returnStdout: true, script: "git log -n 1 --pretty=format:'%h'").trim()
        script.env.CURRENT_GIT_BRANCH = script.env.BRANCH_NAME

    }

    /**
     * Setup Environment Variables for Stage
     *
     */
    public void initializeEnvironment( script, String mtfEnv = null, String perfEnv = null, String preProdSTLEnv = null, String preProdKSCEnv = null, String prodSTLEnv = null, String prodKSCEnv = null, String srcIntEnv = null, String srcPrereleaseEnv = null, String srcProdSTLEnv = null ) {
   
        commonUtil.echoSteps("Reading pipelinecofig.yml file")
        def pipelineConfigData = fileUtil.readPipelineConfig()

        commonUtil.echoSteps("Reading environmentconfig.yml")
        def envConfiguration = fileUtil.readEnvironmentsConfig()

        commonUtil.echoSteps("Pipeline Config file: ${pipelineConfigData}")
        commonUtil.echoSteps("Environment Config file: ${envConfiguration}")
        commonUtil.echoSteps("Current git branch: - ${script.env.CURRENT_GIT_BRANCH}")

        setEnvironmentVars.setDefaultVars()

        // For Release Pipeline
        if( script.params.ENVIRONMENT) {
            //TODO: Revert this change when ARTIFACT_URL is reverted back to ARTIFACT_ID in UI Release Pipelines
            script.env.ARTIFACT_ID = steps.sh(returnStdout: true, script: "basename ${script.params.ARTIFACT_URL}").trim()

            if (script.params.ENVIRONMENT == preProdSTLEnv || script.params.ENVIRONMENT == preProdKSCEnv) {
                setEnvironmentVars.setPreProdVars()
            } else if (script.params.ENVIRONMENT == prodSTLEnv || script.params.ENVIRONMENT == prodKSCEnv) {
                setEnvironmentVars.setProdVars()
            } else if (script.params.ENVIRONMENT == perfEnv) {
                setEnvironmentVars.setPerfVars()
            }else if (script.params.ENVIRONMENT == srcIntEnv) {
                setEnvironmentVars.setSrcIntVars()
            }else if (script.params.ENVIRONMENT == srcPrereleaseEnv) {
                setEnvironmentVars.setSrcPreReleaseVars()
            }else if (script.params.ENVIRONMENT == mtfEnv) {
                setEnvironmentVars.setMtfVars()
            }else if (script.params.ENVIRONMENT == srcProdSTLEnv) {
                setEnvironmentVars.setSrcProdVars()
            }
        }

        // For Stage and PR Pipelines
        else {
            if (script.env.CURRENT_GIT_BRANCH == script.env.INTEGRATION_BRANCH) {
                setEnvironmentVars.setStageVars()
                script.env.PACT_BROKER_URL = steps.globalVars.stage_pactBrokerURL
            } else if (script.env.CURRENT_GIT_BRANCH != script.env.INTEGRATION_BRANCH) {
                setEnvironmentVars.setPrVars()
            }
        }

        // For KSC Specific Release Environment Variables
        if ( script.params.ENVIRONMENT ) {
            if (script.params.ENVIRONMENT.contains("ksc")) {
                script.env.PCF_FOUNDATION = "ksc-prod"
                script.env.ORG_GRADLE_PROJECT_PROVIDER_HOST = script.globalVars.preprodAndProdKSCproviderHost
                script.env.PCF_CREDENTIALS = "alberta-pcf-creds-ksc-prod"

                if (script.params.ENVIRONMENT.contains("pre-prod")) {
                    script.env.ENTRY_URL = "pre-prod-cersei.apps.ksc.pcfprod00.mastercard.int"
                    script.env.ORG_GRADLE_PROJECT_PACT_BROKER_URL = script.globalVars.preprodKSC_pactBrokerURL
                    script.env.PACT_BROKER_HOST = script.globalVars.preprodKSC_pactBrokerHost
                } else {
                    script.env.ENTRY_URL = "prod-cersei.apps.ksc.pcfprod00.mastercard.int"
                    script.env.ORG_GRADLE_PROJECT_PACT_BROKER_URL = script.globalVars.prodKSC_pactBrokerURL
                    script.env.PACT_BROKER_HOST = script.globalVars.prodKSC_pactBrokerHost
                }
            }
        }

        script.env.REPO_NAME = pipelineConfigData.pipeline.hostname
        script.env.APP_HOST_NAME = script.env.PCF_DEV_SPACE + '-' + script.env.REPO_NAME

        if ( script.env.APP_HOST_NAME.contains("cersei") ) {
            script.env.CERSEI_JOB = true
            script.env.UI_LIGHTHOUSE_URL = script.globalVars.cersei_stage_lightHouseURL
        }
        else {
            script.env.VARYS_JOB = true
            script.env.UI_LIGHTHOUSE_URL = script.globalVars.varys_stage_lightHouseURL
        }

        // This will be used for Cypress Testing
        script.env.LOCAL_HOST_SERVER = script.env.CERSEI_JOB ? "http://cersei.com:8080" : "http://varys.com:3000"

        // For Artifactory Upload
        def dateFormat = new SimpleDateFormat("yyyyMMddHHmm")
        def date = new Date()
        script.env.CURRENT_YEAR = dateFormat.format(date)
        script.env.VERSION = "${script.env.CURRENT_YEAR}-${script.env.commit}"

        if ( script.params.ENVIRONMENT || script.params.REDEPLOY_ARTIFACT ) {
            if ( script.env.ARTIFACT_ID.contains("cersei") || script.env.ARTIFACT_ID.contains("varys") ) {
                script.env.ARTIFACT_NAME = "${script.env.ARTIFACT_ID}"
            }
            else {
                script.currentBuild.result = 'ABORTED'
                script.error('Provide a Valid Artifact Id. Eg: <AppName>-dist-<TimeStamp>-<CommitHash>.zip')
            }
        }
        else {
            script.env.ARTIFACT_NAME = "${script.env.REPO_NAME}-dist-${script.env.VERSION}.zip"
        }

        script.env.ARTIFACT_REPO = "snapshots/com/mastercard/alberta/${script.env.REPO_NAME}"
        script.env.ARTIFACTORY_PATH = "${script.env.ALBERTA_ARTIFACTORY_URL}/${script.env.ARTIFACT_REPO}"
        // set PAAS_URL as env var
        pcfUtil.getPaasURL(script)
        // For Release Pipeline
        if ( script.params.ENVIRONMENT ) {
            //TODO: Revert this change when ARTIFACT_URL is reverted back to ARTIFACT_ID in UI Release Pipelines
            // script.env.ARTIFACT_URL = "${script.env.ARTIFACT_REPO}/${script.params.ENVIRONMENT}/${script.env.ARTIFACT_NAME}"
            script.echo "Artifact URL Supplied for this Release: ${script.env.ARTIFACT_URL}"
            commonUtil.echoSteps("\nGlobal Envionment Variables: \n\nPCF Foundation: ${script.env.PCF_FOUNDATION} \n PAAS_URL: ${script.env.PAAS_URL} \nPCF ORG: ${script.env.PCF_ORG} \nPCF Dev space: ${script.env.PCF_DEV_SPACE} \nPCF Credential ID: ${script.env.PCF_CREDENTIALS} \nStash Credential ID: ${script.env.STASH_CREDENTIALS} \nArtifactory Credential ID: ${script.env.ARTIFACTORY_CREDENTIALS} \nStage Branch Name: ${script.env.INTEGRATION_BRANCH} \nSynapse Client Name: ${script.env.SYNAPSE_CLIENT_NAME} \nEntry URL: ${script.env.ENTRY_URL} \nApp Host Name: ${script.env.APP_HOST_NAME} \nBuild and Test execution: ${script.env.BUILD_TEST_EXECUTION} \nSERVICE_TYPE: ${script.env.SERVICE_TYPE} \nPact Broker URL: ${script.env.ORG_GRADLE_PROJECT_PACT_BROKER_URL} \nArtifact URL: ${script.env.ARTIFACT_URL}  \nCERSEI_JOB: ${script.env.CERSEI_JOB} \nVARYS_JOB: ${script.env.VARYS_JOB}")
        }
        // For Stage Pipeline PCF Environment Variable
        else {
            script.env.ARTIFACT_URL = "${script.env.ARTIFACT_REPO}/stage/${script.env.ARTIFACT_NAME}"
            commonUtil.echoSteps("\nGlobal Envionment Variables: \n\nPCF Foundation: ${script.env.PCF_FOUNDATION} \n PAAS_URL: ${script.env.PAAS_URL} \nPCF ORG: ${script.env.PCF_ORG} \nPCF Dev space: ${script.env.PCF_DEV_SPACE} \nPCF Credential ID: ${script.env.PCF_CREDENTIALS} \nStash Credential ID: ${script.env.STASH_CREDENTIALS} \nArtifactory Credential ID: ${script.env.ARTIFACTORY_CREDENTIALS} \nStage Branch Name: ${script.env.INTEGRATION_BRANCH} \nSynapse Client Name: ${script.env.SYNAPSE_CLIENT_NAME} \nEntry URL: ${script.env.ENTRY_URL} \nApp Host Name: ${script.env.APP_HOST_NAME} \nBuild and Test execution: ${script.env.BUILD_TEST_EXECUTION} \nSERVICE_TYPE: ${script.env.SERVICE_TYPE} \nPact Broker URL: ${script.env.ORG_GRADLE_PROJECT_PACT_BROKER_URL} \nArtifact Name: ${script.env.ARTIFACT_NAME} \nArtifactory Repository: ${script.env.ARTIFACT_REPO} \nCERSEI_JOB: ${script.env.CERSEI_JOB} \nVARYS_JOB: ${script.env.VARYS_JOB}")
        }

    }

    /**
     * Builds Code Repository depending on the Frontend Component
     *
     */
    public void buildUI( script ) {

        commonUtil.echoSteps("Building the Repository")

        if ( script.env.CERSEI_JOB ) {
            def cerseiHost = 'https://src-stage-cersei.apps.stl.pcfstage00.mastercard.int'
            def varysHost = 'https://src-stage-varys.apps.stl.pcfstage00.mastercard.int'
            dotEnvUtil.create(cerseiHost, varysHost)

            steps.sh "yarn build"
        }
        else {
            steps.sh "yarn build:stage"
        }

    }

    /**
     * Uploads available Artifact to the Artfactory
     *
     */
    public void artifactoryUpload( script, String artifactEnv=null ) {

        steps.zip zipFile: "${script.env.ARTIFACT_NAME}", archive: false, dir: 'dist'

        script.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: script.env.ARTIFACTORY_CREDENTIALS, usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
            script.sh "curl -X PUT -u ${script.USERNAME}:${script.PASSWORD} -T ${script.env.ARTIFACT_NAME} ${script.env.ARTIFACTORY_PATH}/${artifactEnv}/${script.env.ARTIFACT_NAME}";
        }

    }

    /**
     * Builds according to the environment and Uploads available Artifact to the Artfactory
     *
     */
    public void artifactoryUploadEnv( script, String artifactEnv=null, String pcfEnv=null, String buildForEnv=null ) {

        if ( script.env.CERSEI_JOB ) {
            steps.sh "ls -lrat"
            steps.deleteDir()
            //steps.unstash 'workspace'
            steps.git branch: 'dev', url: 'https://globalrepository.mclocal.int/stash/scm/alberta/cersei.git', credentialsId: "${script.env.STASH_CREDENTIALS}"
            steps.sh "ls -lrat"
            yarnUtil.install(script)
            steps.sh "ls -lrat"

            def cerseiHost = ""
            def varysHost = ""

            if ( pcfEnv.contains("prod") ) {
                if ( artifactEnv.contains("ksc") ) {
                    cerseiHost = "https://${pcfEnv}-cersei.apps.ksc.pcfprod00.mastercard.int"
                    varysHost = "https://${pcfEnv}-varys.apps.ksc.pcfprod00.mastercard.int"
                }
                else {
                    cerseiHost = "https://${pcfEnv}-cersei.apps.stl.pcfprod00.mastercard.int"
                    varysHost = "https://${pcfEnv}-varys.apps.stl.pcfprod00.mastercard.int"
                }
            }
            else {
                cerseiHost = "https://${pcfEnv}-cersei.apps.stl.pcfstage00.mastercard.int"
                varysHost = "https://${pcfEnv}-varys.apps.stl.pcfstage00.mastercard.int"
            }
            dotEnvUtil.create(cerseiHost, varysHost)

            steps.sh "yarn build"
        }
        else {
            steps.sh "ls -lrat"
            steps.deleteDir()
            //steps.unstash 'workspace'
            steps.git branch: 'dev', url: 'https://globalrepository.mclocal.int/stash/scm/alberta/varys.git', credentialsId: "${script.env.STASH_CREDENTIALS}"
            steps.sh "ls -lrat"
            yarnUtil.install(script)
            steps.sh "ls -lrat"

            if (steps.fileExists("config/environment.js")) {
                steps.sh "cat config/environment.js"

                def applicationPcfData = steps.readFile("config/environment.js")

                if ( pcfEnv.contains("prod") ) {
                    if ( artifactEnv.contains("ksc") ) {
                        applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys.apps.stl.pcfstage00.mastercard.int/, "${pcfEnv}-varys.apps.ksc.pcfprod00.mastercard.int")
                    }
                    else {
                        applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys.apps.stl.pcfstage00.mastercard.int/, "${pcfEnv}-varys.apps.stl.pcfprod00.mastercard.int")
                    }
                }
                else {
                    applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys.apps.stl.pcfstage00.mastercard.int/, "${pcfEnv}-varys.apps.stl.pcfstage00.mastercard.int")
                }

                steps.writeFile(file: "config/environment.js", text: applicationPcfData)
                steps.sh "cat config/environment.js"
            }

            steps.sh "yarn build:${buildForEnv}"
        }

        artifactoryUpload( script, artifactEnv )

    }

    /**
     * Performs Lint Testing for Frontend
     *
     */
    public void lintUI( script ) {

        commonUtil.echoSteps("Executing Lint Tests")
        steps.sh "yarn lint"

    }

    /**
     * Perform Unit Testing for Frontend
     *
     */
    public void unitUI( script ) {

        commonUtil.echoSteps("Executing Unit Tests")
        steps.sh "yarn unit:ci"

    }

    /**
     * Perform Pact Publish
     *
     */
    public void publishPacts( script ) {

        commonUtil.echoSteps("Publishing Pacts")
        if ( script.env.CERSEI_JOB ) {
            steps.sh """
                cd packages/cersei
                yarn contract:ci
                yarn contract:publish
            """
        }
        else {
            steps.sh """
                yarn contract:ci
                yarn contract:publish
            """
        }

    }

    /**
     * Performs Cypress Testing of Frontend Component inside a Docker Container on Jenkins
     *
     */
    public void dockerCypressIntegrationUI( script ) {

        steps.docker.withRegistry("${script.env.DOCKER_REGISTRY}", "${script.env.DOCKER_CREDENTIALS}") {
            steps.docker.image("${script.env.DOCKER_IMAGE}:${script.env.DOCKER_IMAGE_VERSION}").inside("-u ${script.env.DOCKER_CONTAINER_USER}:${script.env.DOCKER_CONTAINER_USER}") {
                commonUtil.echoSteps("We are Inside the Container")
                commonUtil.echoSteps("Starting Integration Tests")
                steps.sh "ls -lrta"

                steps.sh """
                    echo "127.0.0.1 cersei.com" >> /etc/hosts
                    echo "127.0.0.1 varys.com" >> /etc/hosts
                    echo "127.0.0.1 somemerchant.com" >> /etc/hosts
                """

                steps.sh "yarn config set strict-ssl false"

                if ( script.env.CERSEI_JOB ) {
                    def cerseiHost = 'http://localhost'
                    def varysHost = 'http://localhost'
                    dotEnvUtil.create(cerseiHost, varysHost)

                    steps.sh "yarn build"
                }
                else {
                    steps.sh "yarn build:stage"
                }

                steps.sh "ls -lrta"

                steps.sh "nohup yarn start &"

                def serverStatus = false
                while (!serverStatus) {
                    def serverResponse = steps.sh(script: "curl -s -o /dev/null -w %{http_code} ${script.env.LOCAL_HOST_SERVER} || true", returnStdout: true).trim()

                    if(null == serverResponse) {
                        commonUtil.echoSteps("WARNING: No server response found. Replacing response to zero.")
                        serverResponse = 0
                    } else {
                        steps.echo "serverResponse: ${serverResponse}"
                    }
                    
                    serverStatus = (serverResponse.toInteger() >= 200 && serverResponse.toInteger() <300) ? true : false
                    if (serverStatus) {
                        steps.echo "Local Server is Up and Running at ${script.env.LOCAL_HOST_SERVER}"
                    }
                    else {
                        steps.echo "Waiting for Local Server to be Up and Running..."
                    }
                }

                if (serverStatus) {
                    if ( script.env.CERSEI_JOB ) {
                        steps.sh """
                            cd packages/cersei
                            ls -lrta
                            npm install cypress --save-dev
                            ls -lrta
                            yarn integration:ci
                        """
                    }
                    else {
                        steps.sh """
                            ls -lrta
                            npm install cypress --save-dev
                            ls -lrta
                            yarn integration:ci
                        """
                    }
                }
                else {
                    steps.sh "Local Server Not Available to Run Cypress Tests..."
                    steps.sh "exit 1"
                }

                commonUtil.echoSteps("Integration Tests Completed Successfully")
            }
        }

    }

    /**
     * Performance Metrics of Frontend Component using lighthouse inside a Docker Container on Jenkins
     *
     */

    public void dockerLighthouseUI() {
        commonUtil.echoSteps("We are outside the Container")
        commonUtil.echoSteps("Starting Lighthouse Container")
        steps.docker.withRegistry("${steps.env.DOCKER_REGISTRY}", "${steps.env.DOCKER_CREDENTIALS}") {
            steps.docker.image("artifactory.dev.mastercard.int:6555/mc-alberta/alberta-lighthouse:1.0").inside("-u ${steps.env.DOCKER_CONTAINER_USER}:${steps.env.DOCKER_CONTAINER_USER} -v ${steps.WORKSPACE}:/root --cap-add=SYS_ADMIN") { c ->
                commonUtil.echoSteps("We are Inside the Container")
                steps.dir(currentYear) {
                    steps.sh """
                        lighthouse --chrome-flags="--headless --disable-gpu --no-sandbox" "${
                        steps.env.UI_LIGHTHOUSE_URL
                    }" --output json --output html --output-path "${currentYear}"/lighthouse-results.html
                     """
                }
                steps.publishHTML(target: [
                        allowMissing: false,
                        alwaysLinkToLastBuild: false,
                        keepAll: true,
                        reportDir: '.',
                        reportFiles: "${currentYear}/lighthouse-results.report.html",
                        reportName: "Lighthouse"
                ])
                steps.stash includes: "${currentYear}/lighthouse-results.report.*", name: 'lighthouse-reports'
            }
        }
        commonUtil.echoSteps("Commit and Push Reports to Stash")
        commitAndPush()

        commonUtil.echoSteps("Deploy Reports to PCF")
        pcfUtil.deployStaticReports(steps)
    }

    /**
     * Commit And Push Lighthouse reports to Stash
     *
     */
    public String commitAndPush() {
        steps.figlet 'Push Repo'
        def htmlReportURL
        def reportGitRepo = "https://globalrepository.mclocal.int/stash/scm/alberta/lighthouse-reports.git"
        def reportGitBranch = "master"
        steps.node('DTL-CF-CLI') {
            steps.deleteDir()
            steps.git url: reportGitRepo , branch: reportGitBranch

            def gitArr = getUrlStrip()

            steps.dir("${steps.env.PCF_DEV_SPACE}/${steps.env.REPO_NAME}") {
                steps.unstash "lighthouse-reports"
                steps.sh "echo https://lighthouse-reports.apps.stl.pcfstage00.mastercard.int/${steps.env.PCF_DEV_SPACE}/${steps.env.REPO_NAME}/${currentYear}/lighthouse-results.report.html > ${currentYear}/pcf-report.txt "
                steps.sh "cat ${currentYear}/lighthouse-results.report.html > latest-report.html"
            }
            steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${steps.env.STASH_CREDENTIALS}", usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']]) {
                steps.sh("git add . ")
                def email = "${steps.env.GIT_USERNAME}@mastercard.com"
                def message = "AUTOMATED_CI_COMMIT: Adding Lighthouse Reports "
                steps.sh("GIT_COMMITTER_NAME='${steps.env.GIT_USERNAME}' GIT_COMMITTER_EMAIL='${email}' git commit -m '${message}' --author='${steps.env.GIT_USERNAME} <${email}>'")
                steps.sh('git push https://${GIT_USERNAME}:${GIT_PASSWORD}@' + "${gitArr[1]}")
            }
            steps.echo "Updated and Committed Lighthouse Reports"
        }
    }

    public  getUrlStrip() {
        def url = steps.sh returnStdout: true, script: 'git config --get remote.origin.url'
        def branch = steps.sh returnStdout: true, script: 'git rev-parse --abbrev-ref HEAD'
        def gitArr = []
        gitArr << branch
        gitArr << url.replaceFirst("^(http(?>s)://www\\.|http(?>s)://|www\\.)", "")
        return gitArr
    }

    /**
     * Gets absolute Path of the last available Zip Artifact on an Artifactory Repository
     *
     */

    public String readLastZipFromArtifactory( script, String artifactoryRepo ){

        def stableArtifactRepo = "${script.env.ARTIFACTORY_PATH}/${artifactoryRepo}"
        def output = steps.sh returnStdout: true, script: "curl ${stableArtifactRepo}/"
        //workaround to obtain the last element of the matching output
        //i do it this way because everything else (e.g. findall) is blocked within jenkins sandbox
        def i  = 0
        def zips = ((output =~ /<a.*>(.+.zip)<\/a>/))
        def lastArtifact = ""
        def stableArtifactPath = ""

        try{
            def count = 0
            //either terminate when we get the exception or when count is == 100
            //max number of artifacts we can have
            while(true || count != 100){
                def zip = zips[i][1]
                lastArtifact = zip
                i++
                count++
            }
        }
        catch(Exception e){
            steps.echo("Last Artifact Obtained: ${lastArtifact}")
            stableArtifactPath = "${script.env.ARTIFACT_REPO}/${artifactoryRepo}/${lastArtifact}"
            return stableArtifactPath
        }

        return ""
    }

    /**
     * Perform a parameterized Checkout if pipeline is running for a release
     *
     */
    public void releaseCheckout( script ) {

        def commiId = ""
        def manifestArtifactName = ""
        def manifestBitbucketURL = ""

        commonUtil.echoSteps("This is the Release for Change Request: ${script.params.CHG_REQUEST_ID}")
        script.env.ARTIFACT_ID = steps.sh(returnStdout: true, script: "basename ${script.params.ARTIFACT_URL}").trim()
        commiId = script.sh(returnStdout: true, script: "echo ${script.env.ARTIFACT_ID} | cut -d'-' -f4 | cut -d'.' -f1").trim()
        //TODO: Revert this change when ARTIFACT_URL is reverted back to ARTIFACT_ID in UI Release Pipelines
        //script.env.manifestArtifactName = commonUtil.getManifestArtifactName( script, script.params.ARTIFACT_ID )
        script.env.manifestArtifactName = commonUtil.getRepoName("${script.params.ARTIFACT_URL}")
        manifestBitbucketURL = "https://globalrepository.mclocal.int/stash/scm/alberta/${script.env.manifestArtifactName}.git"

        steps.checkout([
                $class: 'GitSCM',
                credentialsId: "${script.env.STASH_CREDENTIALS}",
                branches: [[
                                   name: "${commiId}"
                           ]],
                userRemoteConfigs: [[
                                            url: "${manifestBitbucketURL}"
                                    ]]
        ])
        script.env.CURRENT_GIT_BRANCH = commiId
    }

    /**
     * Perform UI Artifact Download, if pipeline is running for a release
     *
     */
    public void artifactoryDownload( script ) {
        //TODO: Revert this change when ARTIFACT_URL is reverted back to ARTIFACT_ID in UI Release Pipelines
        //def artifacturl = "${script.env.ALBERTA_ARTIFACTORY_URL}/${script.env.ARTIFACT_URL}"
        def artifacturl = "${script.params.ARTIFACT_URL}"
        try {
            commonUtil.echoSteps("Downloading Artifact from Artifactory")
            script.sh "curl -O --fail ${artifacturl}"
        }
        catch(Exception e){
            steps.echo("Error Downloading Artifact: ${script.env.ARTIFACT_ID}")
            throw e
        }

        //check if file was downloaded or exists, else we dont do anything
        if(steps.fileExists("./${script.env.ARTIFACT_ID}")) {
            commonUtil.echoSteps("Successfully Downloaded Artifact from Artifactory")
        }
        else {
            steps.echo "ERROR: Unable to download Artifact: ${script.env.ARTIFACT_ID}"
            steps.sh "exit 1"
        }

        try {
            if( script.env.VARYS_JOB ){
                script.sh "unzip -o ${script.env.ARTIFACT_ID} -d dist"
                script.sh "ls -latr dist"
            }
            else {
                script.sh "unzip -o ${script.env.ARTIFACT_ID} -d dist"
                script.sh "ls -latr dist/cersei"
            }
        }
        catch (Exception e) {
            script.echo("The app does not have the files required for pipeline configuration")
            throw e
        }

    }


}