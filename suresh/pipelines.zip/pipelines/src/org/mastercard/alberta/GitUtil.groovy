/*
 * org.mastercard.alberta is a collection of alberta utility tasks for jenkins dsl to perform pipeline related tasks.
*/

package org.mastercard.alberta

/*
 * Git Utility functions used to extend functionality of pipeline
 *
 * @Author tim.mahoney@mastercard.com
*/
class GitUtil implements Serializable {

    /*
     * a reference to the pipeline that allows us to run pipeline steps in our shared libary
    */
    def steps
    def commonUtil
    def contractTestingUtil
    String versionPrefix = "v"
    def vPattern = /^${versionPrefix}\d+(\.\d+)+/


    /*
     * Constructor
     *
     * @param steps a reference to the pipeline that allows us to run pipeline steps in our shared libary
    */
    public GitUtil(steps) {
        this.steps = steps
        this.commonUtil = new CommonUtil(steps)
        this.contractTestingUtil = new ContractTestingUtil(steps)
    }

    /**
     * Determine the method of checkout and call the method.
     *
     * @param selectedEnvironment
     * @param changeRequestID
     * @param credentialsId
     * 
     */
    public void customCheckout( script, Boolean releasePipeline=false, String selectedEnvironment=null, String changeRequestID=null, String credentialsId="alberta-stash-credentials" ) {

        if( releasePipeline ) {
            releaseCheckout( script, selectedEnvironment, changeRequestID, credentialsId )
        }
        else {
            prCheckout()
        }
    }

    public String latestTaggedVersionInAncestry() {        
        return latestTaggedVersionInAncestry(vPattern)
    }

    public void fetchTags() {
        remoteGitCmd("fetch --tags")
    }

    public String latestTaggedVersionInAncestry(customPattern) {
        def proc = steps.sh(returnStdout: true, script: "git tag --merged").trim()
        //def proc = ['sh', '-c', 'git tag --merged'].execute()

        return lastVersion(proc, customPattern)
    }

    public String latestTaggedVersionInCommit() {        
        return latestTaggedVersionInCommit(vPattern)
    }

    public String latestTaggedVersionInCommit(customPattern) {
        def proc = steps.sh(returnStdout: true, script: "git tag --points-at HEAD").trim()

        return lastVersion(proc, customPattern)
    }

    public void checkoutCommit(String commitOrTag) {
        def proc = steps.sh(returnStdout: true, script: "git checkout " + commitOrTag).trim()
    }

    public boolean anyDiffSinceCommit(String commitOrTag) {
        def proc = steps.sh(returnStdout: true, script: "git diff HEAD " + commitOrTag).trim()
        if(proc.length() == 0 || proc == '\n') {
            return false;
        }
        return true;
    }

    private String stripVersionPrefix(String v) {
        return v.substring(versionPrefix.length(), v.length())
    }

    private String[] grepVersions(String output, customPattern) {
        def lines = output.split('\n')
        return lines.findAll { it =~ /$customPattern/ }
    }

    private String lastVersion(String output, customPattern) {
        def versions = grepVersions(output, customPattern)
        if(versions.size() > 0) {
            String answer = versions.get(versions.size() - 1);
            answer = stripVersionPrefix(answer);
            return answer;
        }
        return null;
    }

    public String asVersionTag(String version) {
        return versionPrefix + version
    }

    public boolean tagVersion(String tagName) {
        return tagVersion(tagName, true)
    }

    public boolean tagVersion(String tagName, boolean enforceStandardFormat) {
        if(tagName == null) return false;
        else tagName = tagName.trim();

        if(enforceStandardFormat && ! (tagName =~ /$vPattern/)) {
            tagName = asVersionTag(tagName)
            if(! (tagName =~ /$vPattern/)) {
                return false
            }
        }

        def tag = steps.sh(returnStdout: true, script: "git tag -f " + tagName).trim()
        remoteGitCmd("push --tags")
        return true;
    }

    public void remoteGitCmd(String cmd) {
        def url = ''
        def urlMinusProtocol = ''

        steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'alberta-stash-credentials', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USERNAME']]) {

            //script.env.manifestArtifactName = commonUtil.getManifestArtifactName(script, script.env.artifactID)
            //script.env.manifestBitbucketURL = "https://globalrepository.mclocal.int/stash/scm/alberta/${script.env.manifestArtifactName}.git"

            url = steps.sh(returnStdout: true, script: 'git config remote.origin.url').trim()
            urlMinusProtocol = url.substring(url.indexOf('://')+3)
            steps.sh "git ${cmd} https://${steps.GIT_USERNAME}:${steps.GIT_PASSWORD}\\@${urlMinusProtocol}"
        }
        return;
    }   


    /**
     * Perform a normal Checkout if pipeline is running for PR or Stage
     * 
     */
    private void prCheckout() {
        
        commonUtil.echoSteps("Checking Out SCM Repository")
        steps.checkout steps.scm
        steps.env.currentGitBranch = steps.env.BRANCH_NAME
        steps.env.artifactID = contractTestingUtil.getApplicationName(false)
        contractTestingUtil.updateGradleProperties()
        steps.stash name: 'workspace'

    }

    /**
     * Perform a parameterized Checkout if pipeline is running for a release
     * 
     */
    private void releaseCheckout( script, String selectedEnvironment=null, String changeRequestID=null, String credentialsId="alberta-stash-credentials" ) {
        
        commonUtil.echoSteps("This is the Release for Change Request: ${changeRequestID}")
        script.env.ArtifactName = steps.sh(returnStdout: true, script: "basename ${script.env.ARTIFACT_URL}").trim()
        script.env.artifactID = "${script.env.ArtifactName}"

        def commitid = steps.sh(returnStdout: true, script: "echo ${script.env.ArtifactName} | awk 'BEGIN { FS=\"-\" } { print \$NF}' | awk 'BEGIN { FS=\".\" } { print \$1}'").trim()

        //script.env.manifestArtifactName = commonUtil.getManifestArtifactName(script, script.env.artifactID)

        script.env.manifestArtifactName = commonUtil.getRepoName("${script.env.ARTIFACT_URL}")

        script.env.manifestBitbucketURL = "https://globalrepository.mclocal.int/stash/scm/alberta/${script.env.manifestArtifactName}.git"

        steps.checkout([
            $class: 'GitSCM', 
            credentialsId: "${credentialsId}", 
            branches: [[
                //name: "${script.env.EnvBranchName}"
                name: "${commitid}"
            ]], 
            userRemoteConfigs: [[
                url: "${script.env.manifestBitbucketURL}"
            ]]
        ])
        script.env.currentGitBranch = "${commitid}"

    }

}
