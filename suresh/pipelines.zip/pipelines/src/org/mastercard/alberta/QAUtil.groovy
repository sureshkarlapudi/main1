package org.mastercard.alberta


/**
 * QA Utility functions used to extend functionality of pipeline related to Quality Assurance
 *
 * @Author neel.shah@mastercard.com
 */

class QAUtil implements Serializable {

    /**
     * a reference to the pipeline that allows you to run pipeline steps in your shared libary
     */
    def steps

    /**
     * Constructor
     *
     * @param steps a reference to the pipeline that allows you to run pipeline steps in your shared libary
     */
    public QAUtil(steps) { this.steps = steps }

    /**
     *
     * @param mainAppHostName host name of the main app which triggered the build as that will be suffixed to src route name
     * @return srcRoute
     */
    public getSrcRouteName(String mainAppHostName) {
        return "src-${mainAppHostName}"
    }

    /**
     * Function to prepare job for deploying to Integration Environment
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     *
     */
    public void prepareForIntegrationDeploymentBackend(script, String pcfCredentials, Map keyMap) {
        def artifactoryUtil = new ArtifactoryUtil(steps)
        def appHostName = artifactoryUtil.getAppName()
        def albertaPcfUtil = new AlbertaPCFUtil(steps)
        def pcfFoundation = albertaPcfUtil.getPcfFoundation(script)
        def pcfOrg = albertaPcfUtil.getPcfOrg(script)
        def pcfSpace = albertaPcfUtil.getIntSpaceName(script)

        def fileUtil = new org.mastercard.pipeline.utility.FileUtil(steps)
        def pipelineConfigData = fileUtil.readPipelineConfig()
        def intBranch = pipelineConfigData.pipeline.branch.integration

        script.env.LIST_OF_APPS_DEPLOYED_INT = ""

        try {
            // this is a pull request
            if ( script.env.CHANGE_ID ){
                steps.echo "This is a Pull Request, initiating workflow for a Pull Request for preparing Int environment"
                appHostName = "${pcfSpace}-${appHostName}-${script.env.CHANGE_ID}"

                //Create all services from PCF Marketplace if required by all components before deploying them to the given Org and Space in PCF
                albertaPcfUtil.createPcfServiceInstance(script, pcfCredentials, appHostName, "${script.env.redisCustomPlan}", true)

                if ( appHostName.matches(/.*durable-data-service.*/) || appHostName.matches(/.*srci-merchantdata-services.*/) || appHostName.matches(/.*consumer-service.*/) || appHostName.matches(/.*utility-service.*/) || appHostName.matches(/.*identity-service.*/) || appHostName.matches(/.*srci-middleware.*/) || appHostName.matches(/.*mdes-facade.*/) || appHostName.matches(/.*remote-logging-service.*/) || appHostName.matches(/.*checkout-service.*/) || appHostName.matches(/.*precheckout-service.*/) ) {
                     //setDynamicServiceRedisReference(script, appHostName)
                  //  steps.echo "Rebuilding the application (${appHostName}) since have modified the redis service related pcf spring profile file."
                    //steps.sh "${script.env.GRADLE4}/bin/gradle clean build -x test"
                }
            }
            else if( steps.env.BRANCH_NAME == intBranch ){
                steps.echo "This is not a Pull Request and hence deploying to ${pcfFoundation} -> ${pcfOrg} -> ${pcfSpace} space in PCF"
                appHostName = "${pcfSpace}-${appHostName}"
                //Create all services from PCF Marketplace if required by all components before deploying them to the given Org and Space in PCF
                albertaPcfUtil.createPcfServiceInstance(script, pcfCredentials, appHostName, "${script.env.redisCustomPlan}", true)

            }

            deployCurrentComponent(script, pcfCredentials, appHostName, true, keyMap)
        }
        catch (Exception ex) {
            steps.echo "${ex}"
            steps.echo "Error while trying to build and deploy components, hence deleting the one deployed so far"

            albertaPcfUtil.deleteAppsDeployed(script, pcfCredentials, true)
            albertaPcfUtil.deletePcfServiceInstance(script, pcfCredentials, true)

            steps.echo "Error while trying to prepare Int Environment. Please refer to logs for additional details."
            steps.sh "exit 1"
        }
    }

    /**
     * Function to execute Integration Tests
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     *
     */
    public void executeIntegrationTestsBackend(script, String pcfCredentials, Boolean isDeleteApps = true, Map keyMap) {
        // Todo: Inside this shared library function will be a logic to check if this is a Pull Request.
        def artifactoryUtil = new ArtifactoryUtil(steps)
        def appHostName = artifactoryUtil.getAppName()
        def oldAppHostName = artifactoryUtil.getAppName()
        def albertaPcfUtil = new AlbertaPCFUtil(steps)
        def pcfSpace = albertaPcfUtil.getIntSpaceName(script)
        def appUrl = script.globalVars.pcfEnvMap["${script.env.PCF_FOUNDATION}"].appDomain
        def isPR = false
        def fileUtil = new org.mastercard.pipeline.utility.FileUtil(steps)
        def pipelineConfigData = fileUtil.readPipelineConfig()
        def apiKey = ""
        def enableRallyTestUpdate = ""

        if(pipelineConfigData.pipeline.rallyTestCase) {
            if (pipelineConfigData.pipeline.rallyTestCase.apiKey && pipelineConfigData.pipeline.rallyTestCase.enableRallyTestUpdate) {
                 apiKey = pipelineConfigData.pipeline.rallyTestCase.apiKey
                 enableRallyTestUpdate = pipelineConfigData.pipeline.rallyTestCase.enableRallyTestUpdate
            }
        }
        // this is a pull request
        if ( script.env.CHANGE_ID ) {
            prepareForIntegrationDeploymentBackend(script, pcfCredentials, keyMap)
            isPR = true
            appHostName = "${pcfSpace}-${appHostName}-${script.env.CHANGE_ID}"
            steps.echo "Running with app host name: ${appHostName}"
        }
        else {
            steps.echo "This is the apphostname"
            steps.echo "${appHostName}"
            steps.echo "${pcfSpace}"
            appHostName = "${pcfSpace}-${appHostName}"
        }

       // steps.node('DTL-GRADLE') {
            try {
           	// steps.unstash 'workspace'
            steps.echo "Creating service URL for ${appHostName}) in ENV for Integration Tests..."

            if ( artifactoryUtil.getAppName().matches(/.*durable-data-service.*/) ) {
                script.env.DURABLE_DATA_SERVICE_URL = isPR == true ?  "https://${appHostName}.${appUrl}" :  "https://green-${appHostName}.${appUrl}"
                steps.echo "DURABLE_DATA_SERVICE_URL: ${script.env.DURABLE_DATA_SERVICE_URL}"
            } else if ( artifactoryUtil.getAppName().matches(/.*identity-service.*/) ) {
                script.env.IDENTITY_SERVICE_URL = isPR == true ?  "https://${appHostName}.${appUrl}" :  "https://green-${appHostName}.${appUrl}"
                steps.echo "IDENTITY_SERVICE_URL: ${script.env.IDENTITY_SERVICE_URL}"
            } else if( artifactoryUtil.getAppName().matches(/.*remote-logging-service.*/) ) {
                script.env.REMOTE_LOGGING_SERVICE_URL = isPR == true ?  "https://${appHostName}.${appUrl}" :  "https://green-${appHostName}.${appUrl}"
                steps.echo "REMOTE_LOGGING_SERVICE_URL: ${script.env.REMOTE_LOGGING_SERVICE_URL}"
            } else if( artifactoryUtil.getAppName().matches(/.*mdes-facade.*/) ) {
                script.env.MDES_FACADE_SERVICE_URL = isPR == true ?  "https://${appHostName}.${appUrl}" :  "https://green-${appHostName}.${appUrl}"
                steps.echo "MDES_FACADE_SERVICE_URL: ${script.env.MDES_FACADE_SERVICE_URL}"
            } else if( artifactoryUtil.getAppName().matches(/.*srci-merchantdata-services.*/) ) {
                script.env.SRCI_MERCHANTDATA_SERVICES_URL = isPR == true ?  "https://${appHostName}.${appUrl}" :  "https://green-${appHostName}.${appUrl}"
                steps.echo "SRCI_MERCHANTDATA_SERVICES_URL: ${script.env.SRCI_MERCHANTDATA_SERVICES_URL}"
            } else if( artifactoryUtil.getAppName().matches(/.*srci-middleware.*/) ) {
                script.env.SRCI_MIDDLEWARE_URL = isPR == true ?  "https://${appHostName}.${appUrl}" :  "https://green-${appHostName}.${appUrl}"
                steps.echo "SRCI_MIDDLEWARE_URL: ${script.env.SRCI_MIDDLEWARE_URL}"
            } else if ( artifactoryUtil.getAppName().matches(/.*precheckout-service.*/) ) {
                script.env.PRECHECKOUT_SERVICE_URL = isPR == true ?  "https://${appHostName}.${appUrl}" :  "https://green-${appHostName}.${appUrl}"
                steps.echo "PRECHECKOUT_SERVICE_URL: ${script.env.PRECHECKOUT_SERVICE_URL}"
            } else if ( artifactoryUtil.getAppName().matches(/.*checkout-service.*/) ) {
                script.env.CHECKOUT_SERVICE_URL = isPR == true ?  "https://${appHostName}.${appUrl}" :  "https://green-${appHostName}.${appUrl}"
                steps.echo "CHECKOUT_SERVICE_URL: ${script.env.CHECKOUT_SERVICE_URL}"
            } else if ( artifactoryUtil.getAppName().matches(/.*utility-service.*/) ) {
                script.env.UTILITY_SERVICE_URL = isPR == true ?  "https://${appHostName}.${appUrl}" :  "https://green-${appHostName}.${appUrl}"
                steps.echo "UTILITY_SERVICE_URL: ${script.env.UTILITY_SERVICE_URL}"
            } else if ( artifactoryUtil.getAppName().matches(/.*consumer-service.*/) ) {
                script.env.CONSUMER_SERVICE_URL = isPR == true ?  "https://${appHostName}.${appUrl}" :  "https://green-${appHostName}.${appUrl}"
                steps.echo "CONSUMER_SERVICE_URL: ${script.env.CONSUMER_SERVICE_URL}"
            } else if ( artifactoryUtil.getAppName().matches(/.*app-instance-service.*/) ) {
                script.env.APP_INSTANCE_SERVICE_URL = isPR == true ?  "https://${appHostName}.${appUrl}" :  "https://green-${appHostName}.${appUrl}"
                steps.echo "APP_INSTANCE_SERVICE_URL: ${script.env.APP_INSTANCE_SERVICE_URL}"
            } else if ( artifactoryUtil.getAppName().matches(/.*address-service.*/) ) {
                script.env.ADDRESS_SERVICE_URL = isPR == true ?  "https://${appHostName}.${appUrl}" :  "https://green-${appHostName}.${appUrl}"
                steps.echo "ADDRESS_SERVICE_URL: ${script.env.ADDRESS_SERVICE_URL}"
            } else if ( artifactoryUtil.getAppName().matches(/.*paymentinstrument-services.*/) ) {
                script.env.CARD_SERVICE_URL = isPR == true ?  "https://${appHostName}.${appUrl}" :  "https://green-${appHostName}.${appUrl}"
                steps.echo "CARD_SERVICE_URL: ${script.env.CARD_SERVICE_URL}"
            } else if ( artifactoryUtil.getAppName().matches(/.*card-art-service.*/) ) {
                script.env.CARD_ART_SERVICE_URL = isPR == true ?  "https://${appHostName}.${appUrl}" :  "https://green-${appHostName}.${appUrl}"
                steps.echo "CARD_ART_SERVICE_URL: ${script.env.CARD_ART_SERVICE_URL}"
            }
            else {
                steps.echo "Couldn't identify the project name to set Service URL"
            }

            try {
                //enable jenkins-rally connectivity: documentation on https://fusion.mastercard.int/confluence/display/DSTBizOps/Jenkins-Rally+Connectivity
                if (steps.fileExists("build.gradle")) {
                    steps.sh "${script.env.GRADLE4}/bin/gradle clean integrationTest -DapiKey=${apiKey} -DenableRallyTestUpdate=${enableRallyTestUpdate} -DisJenkins=true"
                }
                if (steps.fileExists("pom.xml")){
                    steps.sh "${script.env.M3}/bin/mvn -Dtest=*IT test -DfailIfNoTests=false"
                }
            } finally {
                steps.stash includes: '**', name: 'int'
            }

            try {
                if (steps.fileExists("build.gradle")) {
                    steps.junit 'build/test-results/integrationTest/*.xml'
                }
            }
            catch (Exception ex) {
                steps.echo "${ex}"
            }

            // rename back as E2E is going to use
            if (isPR) {
                albertaPcfUtil.renameAppInManifest(oldAppHostName)
                albertaPcfUtil.renameServicesInManifest(script, oldAppHostName)
                //setDynamicServiceRedisReference(script, oldAppHostName)
                }
            }
            catch (Exception ex) {
                steps.echo "${ex}"
                steps.echo "Error while trying to execute Integration Tests. Please go through the logs for more details..."
                steps.sh "exit 1"
            }
            finally {
                if (isDeleteApps != false && isPR == true) {
                    albertaPcfUtil.deleteAppsDeployed(script, pcfCredentials, true)
                    albertaPcfUtil.deletePcfServiceInstance(script, pcfCredentials, true)
                }
            }
       // }
    }

    /**
     * Function to Archive and publish Test Results
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     *
     */
    public void publishTestResults(script, String reportType, String env, String stashName, String pathToArchive, String reportFile) {
        try {
            steps.echo "Publishing ${reportType} ${env} Report"
            steps.unstash "${stashName}"
            steps.archive (includes: "${pathToArchive}/${reportFile}")
            steps.publishHTML (target: [
                allowMissing: true,
                alwaysLinkToLastBuild: false,
                keepAll: true,
                reportDir: "${pathToArchive}",
                reportFiles: "${reportFile}",
                reportName: "${reportType} ${env}"
            ])
        } catch( Exception ex) {
            steps.echo "${ex}"
        }
    }



    /**
     * Function to prepare job for deploying to E2E Environment
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param pcfCredentials name of the credentialsId you want to use to access pcf and git
     * @param stashNameForCurrentComponent name of the jenkins pipeline dsl stash you performed after building current component to allow it to be unstashed during deployment
     * @return LIST_OF_APPS_DEPLOYED_E2E this will create an environment variable available in the pipeline further which has comma separated value for each of the apps deployed with the full app name including the current app's name with it pull request number if it is a pull request
     */
    public void prepareForE2ETests( script, String pcfCredentials, String stashNameForCurrentComponent = null, Map keyMap) {
        def artifactoryUtil = new ArtifactoryUtil(steps)
        def albertaPcfUtil = new AlbertaPCFUtil(steps)
        def mrtBuildUtil = new MRTBuildUtil(steps)
        def appHostName = artifactoryUtil.getAppName()
        def pcfFoundation = albertaPcfUtil.getPcfFoundation(script)
        def pcfOrg = albertaPcfUtil.getPcfOrg(script)
        def pcfSpace = albertaPcfUtil.getE2ESpaceName(script)
        script.env.LIST_OF_APPS_DEPLOYED_E2E = ""
        def appDomain = albertaPcfUtil.getPcfFoundationDomain(script)
        def stepsForParallel = [:]
        def servicesForParallel = [:]

        if ( ! script.env.CHANGE_ID ) {
            steps.echo "This is not a Pull Request and hence ${appHostName} should already be deployed to ${pcfFoundation} -> ${pcfOrg} -> ${pcfSpace} space in PCF for integration tests"
            //deployCurrentComponent(script, pcfCredentials, appHostName)
        }
        else {

            steps.echo "This is a Pull Request, initiating workflow for a Pull Request for preparing E2E environment"
            appHostName = "${appHostName}-${script.env.CHANGE_ID}"

            //Create all services from PCF Marketplace if required by all components before deploying them to the given Org and Space in PCF
            servicesForParallel['configService'] = { ->
                albertaPcfUtil.createConfigServerInstance(script, pcfCredentials, appHostName)

            }

            steps.echo "These ara parallel steps for Dependent Services: ${servicesForParallel}"
            steps.parallel servicesForParallel


            def cerseiMap = [repoName:'cersei', branchName:'dev', buildForEnv:'stage', gitRepo: "https://globalrepository.mclocal.int/stash/scm/ALBERTA/cersei.git"]
            def varysMap =  [repoName:'varys', branchName:'dev', buildForEnv:'stage', gitRepo: "https://globalrepository.mclocal.int/stash/scm/ALBERTA/varys.git"]
            def durableDataServiceMap = [repoName:'dds', branchName:'dev', buildForEnv:'', gitRepo: "https://globalrepository.mclocal.int/stash/scm/ALBERTA/durable-data-service.git"]
            def identityServiceMap = [repoName:'is', branchName:'dev', buildForEnv:'', gitRepo: "https://globalrepository.mclocal.int/stash/scm/ALBERTA/identity-service.git"]
            def remoteLoggingServiceMap = [repoName:'rls', branchName:'dev', buildForEnv:'', gitRepo: "https://globalrepository.mclocal.int/stash/scm/ALBERTA/remote-logging-service.git"]
            def srciMiddlewareMap = [repoName:'sm', branchName:'dev', buildForEnv:'', gitRepo: "https://globalrepository.mclocal.int/stash/scm/ALBERTA/srci-middleware.git"]
            def srciMerchantdataervicesMap = [repoName:'smds', branchName:'dev', buildForEnv:'', gitRepo: "https://globalrepository.mclocal.int/stash/scm/ALBERTA/srci-merchantdata-services.git"]
            def mdesFacadeMap = [repoName:'mf', branchName:'dev', buildForEnv:'', gitRepo: "https://globalrepository.mclocal.int/stash/scm/ALBERTA/mdes-facade.git"]
            def checkoutServiceMap = [repoName:'cs', branchName:'dev', buildForEnv:'', gitRepo: "https://globalrepository.mclocal.int/stash/scm/ALBERTA/checkout-service.git"]
            def precheckoutServiceMap = [repoName:'pcs', branchName:'dev', buildForEnv:'', gitRepo: "https://globalrepository.mclocal.int/stash/scm/ALBERTA/precheckout-service.git"]
            def utilityServiceMap = [repoName:'us', branchName:'dev', buildForEnv:'', gitRepo: "https://globalrepository.mclocal.int/stash/scm/ALBERTA/utility-service.git"]
            def consumerServiceMap = [repoName:'con-svc', branchName:'dev', buildForEnv:'', gitRepo: "https://globalrepository.mclocal.int/stash/scm/ALBERTA/consumer-service.git"]

            try {
                        // Deploy Remaining components
                   if (!appHostName.matches(/.*cersei.*/)) {
                        stepsForParallel['cersei'] = { ->
                          buildAndDeployFrontEnd(script, pcfCredentials, appHostName, cerseiMap['repoName'], cerseiMap['branchName'], cerseiMap['buildForEnv'], cerseiMap['gitRepo'], keyMap)

                        }
                    }
                    if ( ! appHostName.matches(/.*varys.*/) ) {
                        stepsForParallel['varys'] = { ->
                            buildAndDeployFrontEnd(script, pcfCredentials, appHostName, varysMap['repoName'], varysMap['branchName'], varysMap['buildForEnv'], varysMap['gitRepo'], keyMap)

                        }
                    }
                       stepsForParallel['mrt'] = { ->
                         mrtBuildUtil.buildAndDeployMRT(script, pcfCredentials, appHostName, keyMap)
                       }
                    if ( ! appHostName.matches(/.*durable-data-service.*/) ) {
                        stepsForParallel['dds'] = { ->
                            buildAndDeployBackEnd(script, pcfCredentials, appHostName , durableDataServiceMap['repoName'], durableDataServiceMap['branchName'], durableDataServiceMap['buildForEnv'], durableDataServiceMap['gitRepo'], keyMap)

                        }
                    }
                    if ( ! appHostName.matches(/.*identity-service.*/) ) {
                        stepsForParallel['is'] = { ->
                            buildAndDeployBackEnd(script, pcfCredentials, appHostName, identityServiceMap['repoName'], identityServiceMap['branchName'], identityServiceMap['buildForEnv'], identityServiceMap['gitRepo'], keyMap)

                        }
                    }
                    if ( ! appHostName.matches(/.*remote-logging-service.*/) ) {
                        stepsForParallel['rls'] = { ->
                            buildAndDeployBackEnd(script, pcfCredentials, appHostName, remoteLoggingServiceMap['repoName'], remoteLoggingServiceMap['branchName'], remoteLoggingServiceMap['buildForEnv'], remoteLoggingServiceMap['gitRepo'], keyMap)
                        }
                    }
                    if ( ! appHostName.matches(/.*srci-middleware.*/) ) {
                        stepsForParallel['sm'] = { ->
                            buildAndDeployBackEnd(script, pcfCredentials, appHostName, srciMiddlewareMap['repoName'], srciMiddlewareMap['branchName'], srciMiddlewareMap['buildForEnv'], srciMiddlewareMap['gitRepo'], keyMap)

                        }
                    }
                    if ( ! appHostName.matches(/.*srci-merchantdata-services.*/) ) {
                        stepsForParallel['smds'] = { ->
                            buildAndDeployBackEnd(script, pcfCredentials, appHostName, srciMerchantdataervicesMap['repoName'], srciMerchantdataervicesMap['branchName'], srciMerchantdataervicesMap['buildForEnv'], srciMerchantdataervicesMap['gitRepo'], keyMap)

                        }
                    }
                    if ( ! appHostName.matches(/.*mdes-facade.*/) ) {
                        stepsForParallel['mf'] = { ->
                            buildAndDeployBackEnd(script, pcfCredentials, appHostName, mdesFacadeMap['repoName'], mdesFacadeMap['branchName'], mdesFacadeMap['buildForEnv'], mdesFacadeMap['gitRepo'], keyMap)

                        }
                    }
                    if ( ! appHostName.startsWith('checkout-service')  ) {
                        stepsForParallel['cs'] = { ->
                            buildAndDeployBackEnd(script, pcfCredentials, appHostName, checkoutServiceMap['repoName'], checkoutServiceMap['branchName'], checkoutServiceMap['buildForEnv'], checkoutServiceMap['gitRepo'], keyMap)
                        }
                    }
                    if ( ! appHostName.matches(/.*precheckout-service.*/) ) {
                        stepsForParallel['pcs'] = { ->
                            buildAndDeployBackEnd(script, pcfCredentials, appHostName, precheckoutServiceMap['repoName'], precheckoutServiceMap['branchName'], precheckoutServiceMap['buildForEnv'], precheckoutServiceMap['gitRepo'], keyMap)

                        }
                    }
                    if ( ! appHostName.matches(/.*utility-service.*/) ) {
                        stepsForParallel['us'] = { ->
                            buildAndDeployBackEnd(script, pcfCredentials, appHostName, utilityServiceMap['repoName'], utilityServiceMap['branchName'], utilityServiceMap['buildForEnv'], utilityServiceMap['gitRepo'], keyMap)
                        }
                    }
                    if ( ! appHostName.matches(/.*consumer-service.*/) ) {
                        stepsForParallel['con-svc'] = { ->
                            buildAndDeployBackEnd(script, pcfCredentials, appHostName, consumerServiceMap['repoName'], consumerServiceMap['branchName'], consumerServiceMap['buildForEnv'], consumerServiceMap['gitRepo'], keyMap)
                        }
                    }

                script.env.E2E_ENTRYPOINT = "cersei-${appHostName}.${appDomain}"

                if ( appHostName.matches(/.*varys.*/) || appHostName.matches(/.*cersei.*/) ) {
                    stepsForParallel['currentComponentFrontend'] = { ->
                        buildAndDeployCurrentFrontEnd(script, pcfCredentials, appHostName, keyMap)
                    }
                    if(appHostName.matches(/.*cersei.*/)){
                        script.env.E2E_ENTRYPOINT = "${appHostName}.${appDomain}"

                    }else {
                        script.env.E2E_ENTRYPOINT = "cersei-${appHostName}.${appDomain}"
                    }
                }else {
                    stepsForParallel['currentComponentBackend'] = { ->
                        deployCurrentComponent(script, pcfCredentials, appHostName, keyMap)
                    }
                    script.env.E2E_ENTRYPOINT = "cersei-${appHostName}.${appDomain}"
                }

                steps.echo "These ara parallel steps for Dependent Applications: ${stepsForParallel}"

                stepsForParallel.failFast = true  //Fail immediately at failure
                steps.parallel stepsForParallel

            } catch (Exception ex) {
                steps.echo "${ex}"
                steps.echo "Error while trying to build and deploy all components, hence deleting the ones deployed so far"

                albertaPcfUtil.deleteAppsDeployed(script, pcfCredentials)
                albertaPcfUtil.deletePcfServiceInstance(script, pcfCredentials)

                steps.echo "Error while trying to prepareE2E Environment. Please refer to logs for additional details."
                steps.sh "exit 1"
            }
        }
    }

    /**
     *
     * @param script
     * @param String
     * @param pcfCredentials
     * @param repoName
     * @param mainAppHostName
     */
    public void setCustomApiRoutes(script, String pcfCredentials, String repoName, String mainAppHostName = null) {
        def albertaPcfUtil = new AlbertaPCFUtil(steps)
        def durableDataServicesPath = "api"
        def checkoutServicesPath = "api/checkout"
        def precheckoutServicesPath = "api/precheckout"
        def srciMiddleWarePath = "api"
        def remoteLoggingPath = "api/logging"
        def identityServicePath1 = "api/verification"
        def identityServicePath2 = "api/link"
        def appHostName = repoName
        def srcRouteName

        if (mainAppHostName) {
            srcRouteName = getSrcRouteName(mainAppHostName)
            appHostName = "${repoName}-${mainAppHostName}"
        }
        else {
            srcRouteName = getSrcRouteName(repoName)
        }

        if (repoName.matches(/.*durable-data-service.*/) || repoName.contains("dds")) {
            if(mainAppHostName){
                if(mainAppHostName.contains("varys")) {
                    srcRouteName = "${mainAppHostName}"
                }
                else{
                    srcRouteName = "varys-${mainAppHostName}"
                }
            }else {
                srcRouteName = "varys-${appHostName}"
            }
            albertaPcfUtil.setCustomPcfRoute(script, pcfCredentials, appHostName, srcRouteName, durableDataServicesPath)
        }
      	else if ((repoName.matches(/.*srci-middleware.*/) || repoName.contains("sm")) && ! repoName.contains("smds") ) {
            if(mainAppHostName){
                if(mainAppHostName.contains("cersei")) {
                    srcRouteName = "${mainAppHostName}"
                }
                else{
                    srcRouteName = "cersei-${mainAppHostName}"
                }
            }else {
                srcRouteName = "cersei-${appHostName}"
            }
            albertaPcfUtil.setCustomPcfRoute(script, pcfCredentials, appHostName, srcRouteName, srciMiddleWarePath)
        }
        else if (repoName.matches(/.*remote-logging-service.*/) || repoName.contains("rls")) {
            if(mainAppHostName){
                if(mainAppHostName.contains("varys")) {
                    srcRouteName = "${mainAppHostName}"
                }
                else{
                    srcRouteName = "varys-${mainAppHostName}"
                }
            } else {
                srcRouteName = "varys-${appHostName}"
            }

          	albertaPcfUtil.setCustomPcfRoute(script, pcfCredentials, appHostName, srcRouteName, remoteLoggingPath)

          	if(mainAppHostName){
                if(mainAppHostName.contains("cersei")) {
                    srcRouteName = "${mainAppHostName}"
                }
                else{
                    srcRouteName = "cersei-${mainAppHostName}"
                }
            } else {
                srcRouteName = "cersei-${appHostName}"
            }

            albertaPcfUtil.setCustomPcfRoute(script, pcfCredentials, appHostName, srcRouteName, remoteLoggingPath)
        }
      	else if (repoName.startsWith("cs") ){
            if(mainAppHostName){
                if(mainAppHostName.contains("varys")) {
                    srcRouteName = "${mainAppHostName}"
                }
                else{
                    srcRouteName = "varys-${mainAppHostName}"
                }
            }else {
                srcRouteName = "varys-${appHostName}"
            }
           albertaPcfUtil.setCustomPcfRoute(script, pcfCredentials, appHostName, srcRouteName, checkoutServicesPath)
        }
      	else if (repoName.startsWith("pcs") ){
            if(mainAppHostName){
                if(mainAppHostName.contains("varys")) {
                    srcRouteName = "${mainAppHostName}"
                }
                else{
                    srcRouteName = "varys-${mainAppHostName}"
                }
            }else {
                srcRouteName = "varys-${appHostName}"
            }
            albertaPcfUtil.setCustomPcfRoute(script, pcfCredentials, appHostName, srcRouteName, precheckoutServicesPath)
        }
      	else if ( repoName.matches(/.*precheckout-service.*/)  ) {
            if(mainAppHostName){
                if(mainAppHostName.contains("varys")) {
                    srcRouteName = "${mainAppHostName}"
                }
                else{
                    srcRouteName = "varys-${mainAppHostName}"
                }
            }else {
                srcRouteName = "varys-${appHostName}"
            }
            albertaPcfUtil.setCustomPcfRoute(script, pcfCredentials, appHostName, srcRouteName, precheckoutServicesPath)
        }
      	else if (repoName.matches(/.*checkout-service.*/) ) {
            if(mainAppHostName){
                if(mainAppHostName.contains("varys")) {
                    srcRouteName = "${mainAppHostName}"
                }
                else{
                    srcRouteName = "varys-${mainAppHostName}"
                }
            }else {
                srcRouteName = "varys-${appHostName}"
            }
            albertaPcfUtil.setCustomPcfRoute(script, pcfCredentials, appHostName, srcRouteName, checkoutServicesPath)
        }
      	else if (repoName.matches(/.*identity-service.*/) || repoName.contains("is")) {
            albertaPcfUtil.setCustomPcfRoute(script, pcfCredentials, appHostName, srcRouteName, identityServicePath1)
            albertaPcfUtil.setCustomPcfRoute(script, pcfCredentials, appHostName, srcRouteName, identityServicePath2)

        }
        else {
            steps.echo "No custom routes need to be set"
        }
    }

    /**
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param pcfCredentials name of the credentialsId you want to use to access pcf
     * @param appHostName optional host name of the main app which triggered the build as that will be suffixed to the name of every other application deployed
     */
    public void deployCurrentComponent(script, String pcfCredentials, String appHostName = null, Boolean intTest = false, Map keyMap) {
        def artifactoryUtil = new ArtifactoryUtil(steps)

        def pcfUtil = new org.mastercard.pipeline.utility.PCFUtil(steps)
       // def keyMap = [:]

        def fileUtil = new org.mastercard.pipeline.utility.FileUtil(steps)
        def pipelineConfigData = fileUtil.readPipelineConfig()
        def artifactoryCredentials = pipelineConfigData.pipeline.credentialids.artifactory
        def intBranch = pipelineConfigData.pipeline.branch.integration

        def albertaPcfUtil = new AlbertaPCFUtil(steps)
        def pcfFoundation = albertaPcfUtil.getPcfFoundation(script)
        def pcfOrg = albertaPcfUtil.getPcfOrg(script)
        def pcfSpace = intTest == false ? albertaPcfUtil.getE2ESpaceName(script)
                : albertaPcfUtil.getIntSpaceName(script)

        def stashName = "currentWorkspace"

        if ( ! appHostName ) {
            appHostName = artifactoryUtil.getAppName()
            if (script.env.CHANGE_ID) {
                // This is a pull request
                appHostName = "${appHostName}-${script.env.CHANGE_ID}"
            }
        }

        if ( script.env.CHANGE_ID || (steps.env.BRANCH_NAME == intBranch )) {
            steps.echo "Rebuilding the application since have modified the redis service related pcf spring profile file."
            steps.sh "${script.env.GRADLE4}/bin/gradle clean build -x test"

            steps.stash name: "${stashName}"
        }
        steps.node('DTL-CF-CLI') {
            if ( script.env.CHANGE_ID || (steps.env.BRANCH_NAME == intBranch )) {
                steps.unstash "${stashName}"
                albertaPcfUtil.renameAppInManifest(appHostName)
                albertaPcfUtil.renameServicesInManifest(script, appHostName)
            }
            else {
                if ( ! appHostName.matches(/.*varys.*/) || ! appHostName.contains(/.*cersei.*/) ) {
                    steps.echo "Downloading artifact from artifactory since this is not a Pull Request"
                    artifactoryUtil.artifactoryDownload(script, artifactoryCredentials)

                    if ( intTest ) {
                        albertaPcfUtil.renameAppInManifest(appHostName)
                        albertaPcfUtil.renameServicesInManifest(script, appHostName)
                    }
                }
            }

            if ( intTest ) {
                script.env.LIST_OF_APPS_DEPLOYED_INT = "${script.env.LIST_OF_APPS_DEPLOYED_INT},${appHostName}"
                steps.echo "list of Apps deployed until now are: ${script.env.LIST_OF_APPS_DEPLOYED_INT}"
            }
            else {
                script.env.LIST_OF_APPS_DEPLOYED_E2E = "${script.env.LIST_OF_APPS_DEPLOYED_E2E},${appHostName}"
                steps.echo "list of Apps deployed until now are: ${script.env.LIST_OF_APPS_DEPLOYED_E2E}"
            }

            pcfUtil.deployToPCFGoRouter(script,
                    appHostName,
                    pcfFoundation,
                    pcfOrg,
                    pcfSpace,
                    pcfCredentials, null, null, keyMap, true , false, null)

            if (!intTest) {
                setCustomApiRoutes(script, pcfCredentials, appHostName)
            }
        }
    }


    /**
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param pcfCredentials name of the credentialsId you want to use to access pcf and git
     * @param mainAppHostName host name of the main app which triggered the build as that will be suffixed to the name of every other application deployed
     * @param repoName
     * @param branchName
     * @param buildForEnv
     * @param gitRepo
     */

    public void buildAndDeployCurrentFrontEnd(script, String pcfCredentials, String appHostName, Map keyMap) {
        def pcfUtil = new org.mastercard.pipeline.utility.PCFUtil(steps)

        def albertaPcfUtil = new AlbertaPCFUtil(steps)
        def pcfFoundation = albertaPcfUtil.getPcfFoundation(script)
        def pcfOrg = albertaPcfUtil.getPcfOrg(script)
        def pcfSpace = albertaPcfUtil.getE2ESpaceName(script)
        def YarnUtil = new org.mastercard.alberta.YarnUtil(steps)
        def DotEnvUtil = new org.mastercard.alberta.DotEnvUtil(steps)
        def appDomain = albertaPcfUtil.getPcfFoundationDomain(script)

        def applicationPcfData = ""

        script.env.PATH = "${script.env.NODE8}/bin:${script.env.YARN1}/bin:${script.env.PATH}"


        steps.node('DEVCLD-YARN') {
            steps.deleteDir()

            steps.unstash "workspace"
            //steps.sh "yarn cache clean"

            steps.sh "ls -altr"

            if (appHostName.contains("cersei")) {
                YarnUtil.install(script)

                def cerseiHost = "https://${appHostName}.${appDomain}"
                def varysHost = "https://varys-${appHostName}.${appDomain}"

                DotEnvUtil.create(cerseiHost, varysHost)

                steps.sh "yarn build"
            }else {
                if (steps.fileExists("config/environment.js")) {
                    applicationPcfData = steps.readFile("config/environment.js")
                    // Todo: Update this code to perform search and replace in an optimized way over replacing static value
                    applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys/, "${appHostName}")
                    steps.writeFile(file: "config/environment.js", text: applicationPcfData)
                }
                steps.sh "ls -ltar"
                steps.sh"sed -i 's,https://registry.yarnpkg.com,${script.env.ALBERTA_ARTIFACTORY_URL}/api/npm/npm-all,g' yarn.lock"
                steps.sh"SASS_BINARY_SITE=${script.env.ALBERTA_ARTIFACTORY_URL}/archive-external-release/node-sass/ CYPRESS_SKIP_BINARY_INSTALL=1 yarn"
                steps.sh "yarn build:stage"
            }

            steps.stash name: "${appHostName}"

       }

        if(appHostName.contains('varys')){
            script.env.VarysURl = "${appHostName}.${appDomain}"
        }else{
            script.env.CerseiURl = "${appHostName}.${appDomain}"
            script.env.AlbertaJSURl = "${appHostName}.${appDomain}"
        }

        script.env.LIST_OF_APPS_DEPLOYED_E2E = "${script.env.LIST_OF_APPS_DEPLOYED_E2E},${appHostName}"

        steps.echo "list of Apps deployed until now are: ${script.env.LIST_OF_APPS_DEPLOYED_E2E}"

        steps.node('DTL-CF-CLI') {
            steps.deleteDir()
            steps.unstash "${appHostName}"
            steps.sh "ls -altr"
            steps.echo "Deploying ${appHostName} to PCF"

            pcfUtil.deployToPCFGoRouter(script,
                    appHostName,
                    pcfFoundation,
                    pcfOrg,
                    pcfSpace,
                    pcfCredentials, null, null, keyMap, false, false, null)
        }
    }

    /**
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param pcfCredentials name of the credentialsId you want to use to access pcf and git
     * @param mainAppHostName host name of the main app which triggered the build as that will be suffixed to the name of every other application deployed
     * @param repoName
     * @param branchName
     * @param buildForEnv
     * @param gitRepo
     */
    public void buildAndDeployFrontEnd(script, String pcfCredentials, String mainAppHostName, String repoName, String branchName, String buildForEnv, String gitRepo, Map keyMap) {
        def newAppHostName = "${repoName}-${mainAppHostName}"
        def pcfUtil = new org.mastercard.pipeline.utility.PCFUtil(steps)
        script.env.PATH = "${script.env.NODE8}/bin:${script.env.YARN1}/bin:${script.env.PATH}"

        def albertaPcfUtil = new AlbertaPCFUtil(steps)
        def pcfFoundation = albertaPcfUtil.getPcfFoundation(script)
        def pcfOrg = albertaPcfUtil.getPcfOrg(script)
        def pcfSpace = albertaPcfUtil.getE2ESpaceName(script)
        def YarnUtil = new org.mastercard.alberta.YarnUtil(steps)
        def DotEnvUtil = new org.mastercard.alberta.DotEnvUtil(steps)

        def applicationPcfData = ""

        script.env.PATH = "${script.env.NODE8}/bin:${script.env.YARN1}/bin:${script.env.PATH}"

        steps.node('DEVCLD-YARN') {
            steps.deleteDir()
            steps.git branch: branchName, url: gitRepo, credentialsId: pcfCredentials
            //steps.sh "yarn cache clean"

            if (repoName.contains("cersei")) {
                YarnUtil.install(script)

                def cerseiHost = "https://cersei-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
                def varysHost

                if(mainAppHostName.contains('varys')){
                     varysHost = "https://${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"

                }else{
                     varysHost = "https://varys-${mainAppHostName}.apps.stl.pcfstage00.mastercard.int"
                }
                DotEnvUtil.create(cerseiHost, varysHost)

                steps.sh "yarn build"
            }else {
                if (steps.fileExists("config/environment.js")) {
                    applicationPcfData = steps.readFile("config/environment.js")
                    // Todo: Update this code to perform search and replace in an optimized way over replacing static value
                    applicationPcfData = applicationPcfData.replaceAll(/src-stage-varys/, "${newAppHostName}")
                    steps.writeFile(file: "config/environment.js", text: applicationPcfData)
                }

                steps.sh"sed -i 's,https://registry.yarnpkg.com,${script.env.ALBERTA_ARTIFACTORY_URL}/api/npm/npm-all,g' yarn.lock"
                steps.sh"SASS_BINARY_SITE=${script.env.ALBERTA_ARTIFACTORY_URL}/archive-external-release/node-sass/ CYPRESS_SKIP_BINARY_INSTALL=1 yarn"
                steps.sh "yarn build:${buildForEnv}"
            }

            steps.stash name: "${repoName}"

        }

        script.env.LIST_OF_APPS_DEPLOYED_E2E = "${script.env.LIST_OF_APPS_DEPLOYED_E2E},${newAppHostName}"
        steps.echo "list of Apps deployed until now are: ${script.env.LIST_OF_APPS_DEPLOYED_E2E}"
        steps.node('DTL-CF-CLI') {
            steps.deleteDir()
            steps.unstash "${repoName}"
            steps.sh "ls -altr"
            steps.echo "Deploying ${repoName} to PCF"
            pcfUtil.deployToPCFGoRouter(script,
                    newAppHostName,
                    pcfFoundation,
                    pcfOrg,
                    pcfSpace,
                    pcfCredentials, null, null, keyMap, false, false, null)

        }
    }

    /**
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param pcfCredentials name of the credentialsId you want to use to access pcf and git
     * @param mainAppHostName host name of the main app which triggered the build as that will be suffixed to the name of every other application deployed
     * @param repoName
     * @param branchName
     * @param buildForEnv
     * @param gitRepo
     */
    public void buildAndDeployBackEnd(script, String pcfCredentials, String mainAppHostName, String repoName, String branchName, String buildForEnv, String gitRepo, Map keyMap) {
        def newAppHostName = "${repoName}-${mainAppHostName}"
        def pcfUtil = new org.mastercard.pipeline.utility.PCFUtil(steps)

        def albertaPcfUtil = new AlbertaPCFUtil(steps)
        def pcfFoundation = albertaPcfUtil.getPcfFoundation(script)
        def pcfOrg = albertaPcfUtil.getPcfOrg(script)
        def pcfSpace = albertaPcfUtil.getE2ESpaceName(script)

        steps.node('DTL-GRADLE') {
            steps.deleteDir()
            steps.sh "ls -altr"
            //steps.echo "Building ${repoName}"
            steps.git branch: branchName, url: gitRepo, credentialsId: pcfCredentials

            //albertaPcfUtil.createPcfServiceInstance(script, pcfCredentials, newAppHostName, "${script.env.redisCustomPlan}")
            //setDynamicServiceRedisReference(script, newAppHostName)
            albertaPcfUtil.renameAppInManifest(newAppHostName)
            albertaPcfUtil.renameServicesInManifest(script, newAppHostName, mainAppHostName)

            steps.sh "${script.env.GRADLE4}/bin/gradle clean build -x test"
            steps.stash name: "${repoName}"
        }

        script.env.LIST_OF_APPS_DEPLOYED_E2E = "${script.env.LIST_OF_APPS_DEPLOYED_E2E},${newAppHostName}"
        steps.node('DTL-CF-CLI') {
            steps.deleteDir()
            steps.unstash "${repoName}"
            steps.echo "Deploying ${repoName} to PCF"
            pcfUtil.deployToPCFGoRouter(script,
                    newAppHostName,
                    pcfFoundation,
                    pcfOrg,
                    pcfSpace,
                    pcfCredentials, null, null, keyMap, true, false, null)

            setCustomApiRoutes(script, pcfCredentials, repoName, mainAppHostName)
        }
    }

    /**
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param mainAppHostName host name of the main app which triggered the build as that will be suffixed to the name of the redis service
     */
    public void setDynamicServiceRedisReference(script, String mainAppHostName) {
        def redisAppFilePath = "src/main/resources/application-pcf.yml"
        def albertaPcfUtil = new AlbertaPCFUtil(steps)
        def servicesList = albertaPcfUtil.getPcfServicesList(script).tokenize(',')

        if (steps.fileExists("src/main/resources/application-pcf.yml")) {
            def applicationPcfData = steps.readFile("src/main/resources/application-pcf.yml")
            for (service in servicesList) {
                if (service.matches(/.*redis.*/)) {
                    // Todo: Update this code to perform search and replace in an optimized way over replacing static value
                    applicationPcfData = applicationPcfData.replaceAll(/alberta-redis/,"redis-${mainAppHostName}")
                    applicationPcfData = applicationPcfData.replaceAll(/srci-merchantdata-services-redis/,"redis-${mainAppHostName}")
                    applicationPcfData = applicationPcfData.replaceAll(/srci-middleware-redis/,"redis-${mainAppHostName}")
                }
            }
            steps.writeFile(file: "src/main/resources/application-pcf.yml", text: applicationPcfData)
        }
    }

    /**
     *
     * @param mainAppHostName host name of the main app which triggered the build as that will be suffixed to the name of every other application deployed
     * @return E2E_ENTRYPOINT this will be the first part of the url to execute the E2E Tests over the stl-stage paas
     */
    public void setDynamicEnv( script, String mainAppHostName ) {
        // Todo: update environment.js file in the source code based on the env value passed
        def albertaPcfUtil = new AlbertaPCFUtil(steps)
        def stageAppDomain = "apps.stl.pcfstage00.mastercard.int"
        def appDomain = albertaPcfUtil.getPcfFoundationDomain(script)

        if (steps.fileExists("config/environment.js")) {
            def envConfigFileData = steps.readFile("config/environment.js")
            // replace references to varys/src component
            envConfigFileData = envConfigFileData.replaceAll("src.${stageAppDomain}","src-${mainAppHostName}.${appDomain}")
            // replace references to cersei component
            envConfigFileData = envConfigFileData.replaceAll("cersei.${stageAppDomain}","cersei-${mainAppHostName}.${appDomain}")
            steps.writeFile(file: "config/environment.js", text: envConfigFileData)
            steps.echo "New Environment Config File data:\n ${envConfigFileData}"
            script.env.E2E_ENTRYPOINT = "cersei-${mainAppHostName}.${appDomain}"
        }
    }

    /**
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param pcfCredentials name of the credentialsId you want to use to access pcf and git
     * @param e2eEntrypoint the entry point url for starting e2e tests with
     * @param isDeleteApps optional, default set to true. If set to false, it will not delete all apps after completing E2E Tests
     */
    public void executeE2ETests(script, String pcfCredentials, String env, String e2eEntrypoint = null, Boolean isDeleteApps = true, boolean crossBrowser = false,  String Browser=null, String BrowserVersion=null, String OS=null, String osVersion =null){
        boolean e2eTestsPassed = true
        def repoName = "e2e"
        def e2eTestRepoBranchName = "dev"
        def appRepoBranchName = script.env.BRANCH_NAME
        def gitRepo = "https://globalrepository.mclocal.int/stash/scm/alberta/trident-alberta-e2e.git"
        def albertaPcfUtil = new AlbertaPCFUtil(steps)
        def artifactoryUtil = new ArtifactoryUtil(steps)
        def appHostName = artifactoryUtil.getAppName()
        def appDomain = albertaPcfUtil.getPcfFoundationDomain(script)
        def E2E_Env
        def mrtURL
        def varysEndPoint

        def CF_CLI_LABEL = env.contains('prod') ? "CF-CLI" : "DTL-CF-CLI"

        if (script.env.CHANGE_ID) {
            if (!appHostName.matches(/.*-[0-9]+/)) {
                appHostName = "${appHostName}-${script.env.CHANGE_ID}"
            }
        }
        steps.node("${CF_CLI_LABEL}") {
            steps.deleteDir()
            try {
                switch (env) {
                    case 'src-stage':
                        mrtURL = steps.globalVars.E2E_Stage_Merchant_URL;
                        E2E_Env = steps.globalVars.E2E_Env_Stage;
                        varysEndPoint = steps.globalVars.E2E_Stage_Varys_URL;
                        break;
                    case 'pre-prod':
                        mrtURL = steps.globalVars.E2E_preprod_Merchant_URL;
                        E2E_Env = steps.globalVars.E2E_Env_PreProd;
                        varysEndPoint = steps.globalVars.E2E_preprod_Varys_URL;
                        break;
                    case 'prod':
                        mrtURL = steps.globalVars.E2E_prod_Merchant_URL;
                        E2E_Env = steps.globalVars.E2E_Env_Prod;
                        varysEndPoint = steps.globalVars.E2E_prod_Varys_URL;
                        break;
                    case 'src-perf':
                        mrtURL = steps.globalVars.E2E_perf_Merchant_URL;
                        E2E_Env = steps.globalVars.E2E_Env_Perf;
                        varysEndPoint = steps.globalVars.E2E_perf_Varys_URL;
                        break;
                    default:
                        mrtURL = steps.globalVars.E2E_e2e_Merchant_URL;
                        E2E_Env = steps.globalVars.E2E_Env_Default; //Currently set to e2e space
                        varysEndPoint = steps.globalVars.E2E_e2e_Varys_URL;
                }

                if (!e2eEntrypoint) {
                    if (!script.env.E2E_ENTRYPOINT) {
                        steps.echo "ERROR: Please provide a entrypoint url for executing end to end tests"
                        steps.sh "exit 1"
                    }
                    e2eEntrypoint = script.env.E2E_ENTRYPOINT
                    E2E_Env = "pr-int"; //Change it to pr-e2e

                }
                script.env.PATH = "${script.env.NODE8}/bin:${script.env.PATH}"

                steps.echo "Building E2E Tests"
                steps.sh "mkdir -p ${repoName}"
                steps.sh "cd ${repoName}"
                steps.echo "Checking if ${appRepoBranchName} exists for ${gitRepo}"
                def checkIfSourceBranchExists = steps.sh([script: "git ls-remote --heads ${gitRepo} ${appRepoBranchName}", returnStdout: true]).trim()
                steps.echo "checkIfSourceBranchExists : *${checkIfSourceBranchExists}* "
                if (checkIfSourceBranchExists == null || checkIfSourceBranchExists == '') {
                    steps.echo "${appRepoBranchName} does not exists for ${gitRepo}. so considering the default branch as dev "
                    e2eTestRepoBranchName = "dev"
                } else {
                    steps.echo "${appRepoBranchName} does exists for ${gitRepo}. so considering the ${appRepoBranchName} branch for e2etest git repo"
                    e2eTestRepoBranchName = appRepoBranchName
                }
                steps.echo "Checking out E2E tests repo - ${gitRepo} branch - ${e2eTestRepoBranchName}"

                //if( script.env.selectedEnvironment == script.env.PRE_PROD_ENVIRONMENT || script.env.selectedEnvironment == script.env.PROD_ENVIRONMENT ) {
                if ( env.contains('prod') ) {
                    steps.checkout scm: [$class           	: 'GitSCM',
                                         userRemoteConfigs	: [[url: "https://globalrepository.mclocal.int/stash/scm/alberta/e2e-trident.git"]],
                                         branches         	: [[name: "refs/tags/${script.env.e2eReleaseTag}"]]], poll: false
                } else if(e2eTestRepoBranchName == 'master') {
                    steps.checkout([$class: 'GitSCM', branches: [[name: e2eTestRepoBranchName]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'LocalBranch', localBranch: e2eTestRepoBranchName], [$class: 'CleanBeforeCheckout'], [$class: 'CloneOption', depth: 1, noTags: false, reference: '', shallow: true, timeout: 20]], submoduleCfg: [], userRemoteConfigs: [[url: gitRepo, refspec: '+refs/heads/master' + ':refs/remotes/origin/master']]])

                } else {
                    steps.checkout([$class: 'GitSCM', branches: [[name: e2eTestRepoBranchName]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'LocalBranch', localBranch: e2eTestRepoBranchName], [$class: 'CleanBeforeCheckout'], [$class: 'CloneOption', depth: 1, noTags: false, reference: '', shallow: true, timeout: 20]], submoduleCfg: [], userRemoteConfigs: [[url: gitRepo]]])

                    //steps.git branch: e2eTestRepoBranchName, url: gitRepo, credentialsId: pcfCredentials
                }

                steps.env.E2E_COMMIT = steps.sh(returnStdout: true, script: "git log -n 1 --pretty=format:'%h'").trim()
                steps.env.E2E_CHANGE_AUTHOR = steps.sh(script: 'git --no-pager show -s --format=\'%an\'', returnStdout: true ).trim()
                def changeMessage = steps.sh(script: "git rev-list --format=%B --max-count=1 ${steps.env.E2E_COMMIT}", returnStdout: true ).trim()
                steps.env.E2E_CHANGE_MESSAGE = changeMessage.replace("\n","").replace("\"", "")

                steps.sh "pwd"
                steps.sh "ls -lrt"

                if (crossBrowser) {
                    OS = "\"${OS}\""
                    osVersion = "\"${osVersion}\""

                    steps.sh "${steps.tool 'M3'}/bin/mvn test -DplatformType=BROWSERSTACK -Dbrowser=${Browser} -DbrowserVersion=${BrowserVersion} -Dos=${OS} -DosVersion=${osVersion} -DbsUserName=${script.env.BROWSERSTACK_USER} -DbsuserKey=${script.env.BROWSERSTACK_KEY}  -DuseProxy=true -Denvironment=${E2E_Env} -DMRT_URL=${script.env.MRT_Tool}  -e -U "

                } else if (env.contains('prod')){

                    steps.sh "${steps.tool 'M3'}/bin/mvn test -DplatformType=BROWSERSTACK  -DbsUserName=${script.env.BROWSERSTACK_USER} -DbsuserKey=${script.env.BROWSERSTACK_KEY} -DuseProxy=true -Denvironment=${E2E_Env} -DMRT_URL=${script.env.MRT_Tool} -e -U "
                }
                else{
                    steps.sh "${script.env.GRADLE4}/bin/gradle clean browserstackRun testHighPriority testMediumPriority testLowPriority -Dalberta.cookieUrl=${varysEndPoint} -Dspring.profiles.active=browserstack -Dalberta.env=${E2E_Env} -Dalberta.url=${mrtURL}"

                }
            }
            catch (Exception ex) {
                steps.echo "${ex}"
                steps.echo "ERROR - Error while trying to execute End to End Tests."
                e2eTestsPassed = false
            } finally {
                if (isDeleteApps != false) {
                    //moving this to post stages block
                    // albertaPcfUtil.deleteAppsDeployed(script, pcfCredentials)
                    // albertaPcfUtil.deletePcfServiceInstance(script, pcfCredentials)
                }
            }
            if (! env.contains('prod') ) {
                steps.sh "${script.env.GRADLE4}/bin/gradle allureReport"
            }
            steps.stash includes: '**', name: 'e2e'
            steps.stash name: "${repoName}"

            // if e2eTests failed, exit the pipeline job
            if (!e2eTestsPassed) {
                steps.echo "JOB STOPPED due to E2E Test failures."
                steps.sh "exit 1"
            }
        }
    }
}
