/**
 * org.mastercard.alberta is a collection of alberta utility tasks for jenkins dsl to perform pipeline related tasks.
 */

package org.mastercard.alberta

/**
 * Email Utility functions used to extend functionality of pipeline
 *
 * @Author neel.shah@mastercard.com
 */
class EmailUtil implements Serializable {

    /**
     * a reference to the pipeline that allows you to run pipeline steps in your shared libary
     */
    def steps

    /**
     * Constructor
     *
     * @param steps a reference to the pipeline that allows you to run pipeline steps in your shared libary
     */
    public EmailUtil(steps) {this.steps = steps}

    /**
     * Function to prepare for Email Notification by getting information from Bitbucket using REST API and preparing Email Body.
     * If the current build is run against a regular branch commit, it will get email of the last committer using Bitbucket rest api.
     * If the current build is run against a Pull Request, it will get email of the person who created the pull request, pull request
     * reviewers assigned while creating it. It also get information related to the source branch from which this Pull Request was created.
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param stashCredentials name of the credentialsId you want to use to access the repository
     * @return RECIPIENTS environment variable available for use in further pipeline which contains the email address for last committer or the one who created Pull Request
     * @return PR_REVIEWERS environment variable available for use in further pipeline which contains the email address of all Pull Request Reviewers if this is a Pull Request build or empty space value
     * @return EMAIL_BODY environment variable available for use in further pipeline which contains the body of the email notification with Bitbucket URL, Jenkins Build URL, Commit Hash, Branch Name, Pull Request Target, Pull Request Title, Pull Request Author and Pull Request URL
     */
    public void prepareEmailNotification(script, String stashCredentials = null, String jobType, String result, String mrtJobType = null) {
        def lastCommitHash = steps.sh(returnStdout: true, script: 'git rev-parse HEAD').trim()
        def bitbucketUrl = steps.sh(returnStdout: true, script: 'grep -m 1 "^[[:space:]]url.*" .git/config | grep -o "http.*"').trim()
        def prDetails = " "
        def prReviewers = " "
        def recipients = " "
        def sourceBranchName = "${script.env.BRANCH_NAME}"
        def bitbucketApiDataFile = 'bitbucket_api_data.json'
        def getRepoEndpoint = steps.sh(returnStdout: true, script: "grep -m 1 '^[[:space:]]url.*' .git/config | grep -o 'http.*' | sed 's@stash/scm/@stash/rest/api/1.0/projects/@' | sed 's@projects/~@users/@' | sed 's@\\([a-zA-Z0-9._-]*.git\\)@repos/\\1@' | sed 's@.git@@'").trim()

        if ( ! script.env.CHANGE_TITLE ) {
            // Get Bitbucket REST API Endpoint when this is not a Pull Request
            def commitEndpoint = "${getRepoEndpoint}/commits/${lastCommitHash}/?until=${sourceBranchName}"

            if (stashCredentials) {
                steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${stashCredentials}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
                    try {
                        steps.sh "curl -u ${script.USERNAME}:${script.PASSWORD} -H 'Content-Type: application/json' ${commitEndpoint} > ${bitbucketApiDataFile}"
                    } catch (Exception ex) {
                        steps.echo "ERROR! Trying to access the bitbucket repository using the credentials id provided: ${stashCredentials}"
                        steps.echo "${ex}"
                    }
                }
            }
            else {
                steps.sh "curl -H 'Content-Type: application/json' ${commitEndpoint} > ${bitbucketApiDataFile}"
            }
            // Parse all JSON Data from BitBucket API Request
            try {
                recipients = steps.sh(returnStdout: true, script: "cat ${bitbucketApiDataFile} | python -c \"import sys, json; print json.load(sys.stdin)['committer']['emailAddress']\"").trim()
            } catch (Exception ex) {
                steps.echo "ERROR! Trying to parse JSON Data from bitbucket api response."
                steps.echo "${ex}"
            }
        }
        else {
            // Get Bitbucket REST API Endpoint when this is a Pull Request
            def getBranchDetails = steps.sh(returnStdout: true, script: 'grep -m 1 "^[[:space:]]fetch.*" .git/config | grep -o "+refs.*:" | sed "s/+refs//" | sed "s@/from@@" |  sed "s@:@@"').trim()
            def pullRequestEndpoint = "${getRepoEndpoint}${getBranchDetails}"

            if (stashCredentials) {
                steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${stashCredentials}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
                    try {
                        steps.sh "curl -u ${script.USERNAME}:${script.PASSWORD} -H 'Content-Type: application/json' ${pullRequestEndpoint} > ${bitbucketApiDataFile}"
                    } catch (Exception ex) {
                        steps.echo "ERROR! Trying to access the bitbucket repository using the credentials id provided: ${stashCredentials}"
                        steps.echo "${ex}"
                    }
                }
            }
            else {
                steps.sh "curl -H 'Content-Type: application/json' ${pullRequestEndpoint} > ${bitbucketApiDataFile}"
            }
            // Parse all JSON Data from BitBucket API Request
            try {
                prReviewers = steps.sh(returnStdout: true, script: "cat ${bitbucketApiDataFile} | python -c \$'import sys, json\nfor item in json.load(sys.stdin)[\"reviewers\"]:print item[\"user\"][\"emailAddress\"]'").trim()
                sourceBranchName = steps.sh(returnStdout: true, script: "cat ${bitbucketApiDataFile} | python -c \"import sys, json; print json.load(sys.stdin)['fromRef']['displayId']\"").trim()
                recipients = steps.sh(returnStdout: true, script: "cat ${bitbucketApiDataFile} | python -c \"import sys, json; print json.load(sys.stdin)['author']['user']['emailAddress']\"").trim()
            } catch (Exception ex) {
                steps.echo "ERROR! Trying to parse JSON Data from bitbucket api response."
                steps.echo "${ex}"
            }
            prDetails = "\nPull Request Target : ${script.env.CHANGE_TARGET} \nPull Request Title : ${script.env.CHANGE_TITLE} \nPull Request Author : ${script.env.CHANGE_AUTHOR} \nPull Request URL : ${script.env.CHANGE_URL} \n"
        }
        
        script.env.RECIPIENTS = recipients
        script.env.PR_REVIEWERS = prReviewers
        script.env.EMAIL_SUBJECT = "BUILD ${result}: Job '${script.env.JOB_NAME} [${script.env.BUILD_NUMBER}]'"
        script.env.EMAIL_BODY = "Bitbucket URL: ${bitbucketUrl} \nJenkins Build URL: ${script.env.BUILD_URL} \nCommit Hash: ${lastCommitHash} \nBranch Name: ${sourceBranchName} ${prDetails}"
        
        if (mrtJobType) {
            getCustomStageStatus(script, jobType, mrtJobType)
        }
        else {
            getCustomStageStatus(script, jobType)
        }
        script.env.EMAIL_BODY = "${script.env.STATUS_EMAIL_BODY}"

        if( result == "FAILURE" || result == "ABORTED" || result == "UNSTABLE" ) {
            getBuildLog(script, stashCredentials)
            script.env.EMAIL_BODY = "${script.env.FAILURE_EMAIL_BODY}"
        }
    }

    /**
     * Function to prepare for Email Notification and Email Body, when the job type is 'release'.
     * If the current build is run against a regular branch commit, it will get email of the last committer using Bitbucket rest api.
     * If the current build is run against a Pull Request, it will get email of the person who created the pull request, pull request
     * reviewers assigned while creating it. It also get information related to the source branch from which this Pull Request was created.
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param jenkinsCredentials credentials for accessing Jenkins
     * @return RECIPIENTS environment variable available for use in further pipeline which contains the email address of the person who triggers the job.
     * @return PR_REVIEWERS environment variable added to syncup the single pipeline approach of merging stage and release pipelines.
     * @return EMAIL_BODY environment variable available for use in further pipeline which contains the body of the email notification.
     */
    public void prepareReleaseEmailNotification(script, String jenkinsCredentials, String jobType, String result, String mrtJobType = null) {
      	      
        script.env.RECIPIENTS = steps.emailextrecipients([[$class: 'RequesterRecipientProvider']])
        script.env.EMAIL_SUBJECT = "BUILD ${result}: Job '${script.env.JOB_NAME} [${script.env.BUILD_NUMBER}]'"

        if (mrtJobType) {
            script.env.EMAIL_BODY = "\nBUILD ${result}: \n\nCHANGE REQUEST ID: ${script.env.RELEASE_CHANGE_REQUEST} \n\nPCF Foundation: ${script.env.PCF_FOUNDATION} \nPCF Org: ${script.env.PCF_ORG} \nPCF Space: ${script.env.PCF_DEV_SPACE} \nApplication Name: ${script.env.APP_HOST_NAME} \n\nJenkins Build URL: ${script.env.BUILD_URL}"
            getCustomStageStatus(script, jobType, mrtJobType)
        }
        else {
            if ( script.env.FRONTEND_JOB ) {
                script.env.EMAIL_BODY = "\nBUILD ${result}: \n\nCHANGE REQUEST ID: ${script.params.CHG_REQUEST_ID} \n\nArtifact Name = ${script.env.ARTIFACT_ID} \nArtifactory Space = ${script.env.ARTIFACT_URL} \n\nPCF Foundation: ${script.env.PCF_FOUNDATION} \nPCF Org: ${script.env.PCF_ORG} \nPCF Space: ${script.env.PCF_DEV_SPACE} \nApplication Name: ${script.env.APP_HOST_NAME} \n\nJenkins Build URL: ${script.env.BUILD_URL}"
            }
            else {
                script.env.EMAIL_BODY = "\nBUILD ${result}: \n\nCHANGE REQUEST ID: ${script.env.ChangeRequestID} \n\nArtifact Name = ${script.env.artifactName} \nArtifactory Space = ${script.env.ArtifactSpace} \n\nPCF Foundation: ${script.PCF_FOUNDATION} \nPCF Org: ${script.PCF_ORG} \nPCF Space: ${script.PCF_DEV_SPACE} \nApplication Name: ${script.APP_HOST_NAME}-blue \n\nJenkins Build URL: ${script.env.BUILD_URL}"
            }
            getCustomStageStatus(script, jobType)
        }

        script.env.EMAIL_BODY = "${script.env.STATUS_EMAIL_BODY}"

        if( result == "FAILURE" || result == "ABORTED" || result == "UNSTABLE" ) {
            getBuildLog(script, jenkinsCredentials)
            script.env.EMAIL_BODY = "${script.env.FAILURE_EMAIL_BODY}"
        }
    }

    /**
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param jenkinsCredentials credentials for accessing Jenkins
     * @param noOfLines optional parameter as an Integer value to specify the number of lines for extracting the log file.
     * @return FAILURE_EMAIL_BODY It create a new environment variable called FAILURE_EMAIL_BODY which has custom build log appended towards the end of it for failure notifications
     */
    public void getBuildLog(script, String jenkinsCredentials, Integer noOfLines = null) {
        def buildLogUrl = "${script.env.BUILD_URL}consoleText"
        def crumbUrl = "${script.env.JENKINS_URL}crumbIssuer/api/json"
        def insecureConnection = buildLogUrl.contains('stage.cd.mastercard.int') ? "--insecure" : ""
        def logOutput = "custom_build_log.txt"
        def filteredOutput = "custom_build_log_filtered.txt"
        steps.echo "Starting to extract the log file for current build..."
        if ( ! noOfLines ) {
            noOfLines = 200
        }
        steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${jenkinsCredentials}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
            def crumb = steps.sh(returnStdout: true, script: "curl -u ${script.USERNAME}:${script.PASSWORD} -H 'Content-Type: application/json' ${insecureConnection} ${crumbUrl} | python -c 'import sys,json;j=json.load(sys.stdin);print j[\"crumbRequestField\"] + \":\" + j[\"crumb\"]'").trim()
            steps.sh (returnStdout: true, script:"curl -u ${script.USERNAME}:${script.PASSWORD} -H \"${crumb}\" ${insecureConnection} ${buildLogUrl} > ${logOutput}")
        }
        // Todo: Need to parse this ${logOutput} file to filter unnecessary data and only output meaningful info for the email notification
        steps.sh "sed '/(Declarative: Post Actions)/q' ${logOutput} > ${filteredOutput}"
        def customLog = steps.sh(returnStdout: true, script: "tail -n ${noOfLines} ${filteredOutput}").trim()
        script.env.FAILURE_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\nBuild Log:\n${customLog}"
    }

    /**
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @return EMAIL_BODY environment by appending the status for each of these variables SCM_CHECKOUT, UNIT_TESTS, BUILD_ARTIFACT, SONAR_CHECK, ARTIFACTORY_PUBLISH, SETUP_E2E, GET_CERTS, DEPLOY_GREEN, INTEGRATION_TESTS, FLIP_TRAFFIC, AUTOSCALE_APP, RETRIEVE_PACKAGE, DEPLOY_TO_PCF, E2E_TESTS towards the end of EMAIL_BODY variable
     */
    public void getCustomStageStatus(script, String jobType, String mrtJobType = null) {
        // Todo: Make this code more dynamic by parsing the filteredOutput file from getBuildLog() and setting the status for each of the below variables
        // MRT Pipeline Jobs and Other Connector Jobs
        switch (mrtJobType) {
            // MRT Backend
            case 'backend':
                switch (jobType) {
                    // MRT Backend PR and Feature Jobs, and Other Connector PR Jobs
                    case 'pr':
                    case 'feature':
                        switch (script.env.STAGE_STATUS) {
                            case 'CHECKED_OUT_SCM': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: FAILED \nBuild: SKIPPED \nUnit Tests: SKIPPED \nSonar Analysis: SKIPPED"; break;
                            case 'INITIALIZED_ENV': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nBuild: FAILED \nUnit Tests: SKIPPED \nSonar Analysis: SKIPPED"; break;
                            case 'BUILD_COMPLETED': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nBuild: PASSED \nUnit Tests: FAILED \nSonar Analysis: SKIPPED"; break;
                            case 'EXECUTED_UNIT_TESTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nBuild: PASSED \nUnit Tests: PASSED \nSonar Analysis: FAILED"; break;
                            case 'SONAR_COMPLETED': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nBuild: PASSED \nUnit Tests: PASSED \nSonar Analysis: PASSED"; break;
                            default: script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: SKIPPED \nInitialize Environment: SKIPPED \nBuild: SKIPPED \nUnit Tests: SKIPPED \nSonar Analysis: SKIPPED"; break;
                        }
                    break;

                    // MRT Backend Release Jobs
                    case 'perf':
                  	case 'pre-prod':
                  	case 'prod':
                    case 'srcmtf':
                    case 'srcint':
                    case 'srcprerelease':
                    case 'src-prod':
                        switch (script.env.STAGE_STATUS) {
                            case 'CHECKED_OUT_SCM': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: FAILED \nBuild: SKIPPED \nUnit Tests: SKIPPED \nApp Deployment: SKIPPED"; break;
                            case 'INITIALIZED_ENV': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nBuild: FAILED \nUnit Tests: SKIPPED \nApp Deployment: SKIPPED"; break;
                            case 'BUILD_COMPLETED': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nBuild: PASSED \nUnit Tests: FAILED \nApp Deployment: SKIPPED"; break;
                            case 'EXECUTED_UNIT_TESTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nBuild: PASSED \nUnit Tests: PASSED \nApp Deployment: FAILED"; break;
                            case 'DEPLOYED_APP': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nBuild: PASSED \nUnit Tests: PASSED \nApp Deployment: PASSED"; break;
                            default: script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: SKIPPED \nInitialize Environment: SKIPPED \nBuild: SKIPPED \nUnit Tests: SKIPPED \nApp Deployment: SKIPPED"; break;
                        }
                    break;

                    // MRT Backend dev Merge Job
                    default:
                        switch (script.env.STAGE_STATUS) {
                            case 'CHECKED_OUT_SCM': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: FAILED \nBuild: SKIPPED \nUnit Tests: SKIPPED \nSonar Analysis: SKIPPED \nApp Deployment: SKIPPED"; break;
                            case 'INITIALIZED_ENV': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nBuild: FAILED \nUnit Tests: SKIPPED \nSonar Analysis: SKIPPED \nApp Deployment: SKIPPED"; break;
                            case 'BUILD_COMPLETED': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nBuild: PASSED \nUnit Tests: FAILED \nSonar Analysis: SKIPPED \nApp Deployment: SKIPPED"; break;
                            case 'EXECUTED_UNIT_TESTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nBuild: PASSED \nUnit Tests: PASSED \nSonar Analysis: FAILED \nApp Deployment: SKIPPED"; break;
                            case 'SONAR_COMPLETED': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nBuild: PASSED \nUnit Tests: PASSED \nSonar Analysis: PASSED \nApp Deployment: FAILED"; break;
                            case 'DEPLOYED_APP': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nBuild: PASSED \nUnit Tests: PASSED \nSonar Analysis: PASSED \nApp Deployment: PASSED"; break;
                            default: script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: SKIPPED \nInitialize Environment: SKIPPED \nBuild: SKIPPED \nUnit Tests: SKIPPED \nSonar Analysis: SKIPPED \nApp Deployment: SKIPPED"; break;

                            // Other Connector Jobs like "address-config-lib"
                            if ( script.env.CONNECTOR_NAME ) {
                                switch (script.env.STAGE_STATUS) {
                                    case 'CHECKED_OUT_SCM': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: FAILED \nBuild: SKIPPED \nUnit Tests: SKIPPED \nSonar Analysis: SKIPPED \nArtifactory Upload: SKIPPED"; break;
                                    case 'INITIALIZED_ENV': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nBuild: FAILED \nUnit Tests: SKIPPED \nSonar Analysis: SKIPPED \nArtifactory Upload: SKIPPED"; break;
                                    case 'BUILD_COMPLETED': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nBuild: PASSED \nUnit Tests: FAILED \nSonar Analysis: SKIPPED \nArtifactory Upload: SKIPPED"; break;
                                    case 'EXECUTED_UNIT_TESTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nBuild: PASSED \nUnit Tests: PASSED \nSonar Analysis: FAILED \nArtifactory Upload: SKIPPED"; break;
                                    case 'SONAR_COMPLETED': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nBuild: PASSED \nUnit Tests: PASSED \nSonar Analysis: PASSED \nArtifactory Upload: FAILED"; break;
                                    case 'ARTIFACTORY_PUBLISH': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nBuild: PASSED \\nUnit Tests: PASSED \nSonar Analysis: PASSED \nArtifactory Upload: PASSED"; break;
                                    default: script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: SKIPPED \\nInitialize Environment: SKIPPED \\nBuild: SKIPPED \\\\nUnit Tests: SKIPPED \\nSonar Analysis: SKIPPED \nArtifactory Upload: SKIPPED"; break;
                                }
                            }
                        }
                    break;
                }
            break;

            // MRT Frontend
            case 'frontend':
                switch (jobType) {
                    // MRT Frontend PR and Feature Jobs
                    case 'pr':
                    case 'feature':
                        switch (script.env.STAGE_STATUS) {
                            case 'CHECKED_OUT_SCM': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: FAILED \nInstall Dependencies: SKIPPED \nBuild: SKIPPED \nLint Tests: SKIPPED \nUnit Tests: SKIPPED \nSonar Analysis: SKIPPED"; break;
                            case 'INITIALIZED_ENV': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: FAILED \nBuild: SKIPPED \nLint Tests: SKIPPED \nUnit Tests: SKIPPED \nSonar Analysis: SKIPPED"; break;
                            case 'INSTALLED_DEPENDENCIES': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: FAILED \nLint Tests: SKIPPED \nUnit Tests: SKIPPED \nSonar Analysis: SKIPPED"; break;
                            case 'BUILD_COMPLETED': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: FAILED \nUnit Tests: SKIPPED \nSonar Analysis: SKIPPED"; break;
                            case 'EXECUTED_LINT_TESTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: FAILED \nSonar Analysis: SKIPPED"; break;
                            case 'EXECUTED_UNIT_TESTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nSonar Analysis: FAILED"; break;
                            case 'SONAR_COMPLETED': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nSonar Analysis: PASSED"; break;
                            default: script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: SKIPPED \nInitialize Environment: SKIPPED \nInstall Dependencies: SKIPPED \nBuild: SKIPPED \nLint Tests: SKIPPED \nUnit Tests: SKIPPED \nSonar Analysis: SKIPPED"; break;
                        }
                    break;

                    // MRT Frontend Release Jobs
                    case 'perf':
                  	case 'pre-prod':
                  	case 'prod':
                    case 'srcmtf':
                    case 'srcint':
                    case 'srcprerelease':
                    case 'src-prod':
                        switch (script.env.STAGE_STATUS) {
                            case 'CHECKED_OUT_SCM': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: FAILED \nInstall Dependencies: SKIPPED \nBuild: SKIPPED \nLint Tests: SKIPPED \nUnit Tests: SKIPPED \nApp Deployment: SKIPPED"; break;
                            case 'INITIALIZED_ENV': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: FAILED \nBuild: SKIPPED \nLint Tests: SKIPPED \nUnit Tests: SKIPPED \nApp Deployment: SKIPPED"; break;
                            case 'INSTALLED_DEPENDENCIES': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: FAILED \nLint Tests: SKIPPED \nUnit Tests: SKIPPED \nApp Deployment: SKIPPED"; break;
                            case 'BUILD_COMPLETED': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED\nLint Tests: FAILED \nUnit Tests: SKIPPED \nApp Deployment: SKIPPED"; break;
                            case 'EXECUTED_LINT_TESTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: FAILED \nApp Deployment: SKIPPED"; break;
                            case 'EXECUTED_UNIT_TESTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nApp Deployment: FAILED"; break;
                            case 'DEPLOYED_APP': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nApp Deployment: PASSED"; break;
                            default: script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: SKIPPED \nInitialize Environment: SKIPPED \nInstall Dependencies: SKIPPED \nBuild: SKIPPED \nLint Tests: SKIPPED \nUnit Tests: SKIPPED \nApp Deployment: SKIPPED"; break;
                        }
                    break;

                    // MRT Frontend dev Merge Job
                    default:
                        switch (script.env.STAGE_STATUS) {
                            case 'CHECKED_OUT_SCM': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: FAILED \nInstall Dependencies: SKIPPED \nBuild: SKIPPED \nLint Tests: SKIPPED \nUnit Tests: SKIPPED \nSonar Analysis: SKIPPED \nApp Deployment: SKIPPED"; break;
                            case 'INITIALIZED_ENV': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: FAILED \nBuild: SKIPPED \nLint Tests: SKIPPED \nUnit Tests: SKIPPED \nSonar Analysis: SKIPPED \nApp Deployment: SKIPPED"; break;
                            case 'INSTALLED_DEPENDENCIES': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: FAILED \nLint Tests: SKIPPED \nUnit Tests: SKIPPED \nSonar Analysis: SKIPPED \nApp Deployment: SKIPPED"; break;
                            case 'BUILD_COMPLETED': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED\nLint Tests: FAILED \nUnit Tests: SKIPPED \nSonar Analysis: SKIPPED \nApp Deployment: SKIPPED"; break;
                            case 'EXECUTED_LINT_TESTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: FAILED \nSonar Analysis: SKIPPED \nApp Deployment: SKIPPED"; break;
                            case 'EXECUTED_UNIT_TESTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nSonar Analysis: FAILED \nApp Deployment: SKIPPED"; break;
                            case 'SONAR_COMPLETED': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nSonar Analysis: PASSED \nApp Deployment: FAILED"; break;
                            case 'DEPLOYED_APP': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nSonar Analysis: PASSED \nApp Deployment: PASSED"; break;
                            default: script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: SKIPPED \nInitialize Environment: SKIPPED \nInstall Dependencies: SKIPPED \nBuild: SKIPPED \nLint Tests: SKIPPED \nUnit Tests: SKIPPED \nSonar Analysis: SKIPPED \nApp Deployment: SKIPPED"; break;
                        }
                    break;
                }
            break;

            // Backend and Frontend PCF Application Pipeline Jobs
            default:
                // Release Pipeline Jobs for Higher Environments
                switch (jobType) {
                    // Preprod and Perf Release Jobs for Backend
                    case 'pre-prod-release':
                    case 'perf-release' :
                    case 'src-mtf-release':
                    case 'src-int-release':
                    case 'src-pre-release-release':
                    
                        switch (script.env.STAGE_STATUS) {
                            case 'SCM_CHECKOUT': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: FAILED \nRetrieve Package: SKIPPED \nGet Certificates: SKIPPED \nDeploy Green App: SKIPPED \nIntegration Tests: SKIPPED \nFlip Traffic: SKIPPED \nAutoScale App: SKIPPED \nE2E Tests: SKIPPED"; break;
                            case 'INITIALIZE_ENV': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: FAILED \nGet Certificates: SKIPPED \nDeploy Green App: SKIPPED \nIntegration Tests: SKIPPED \nFlip Traffic: SKIPPED \nAutoScale App: SKIPPED \nE2E Tests: SKIPPED"; break;
                            case 'RETRIEVE_PACKAGE': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: PASSED \nGet Certificates: FAILED \nDeploy Green App: SKIPPED \nIntegration Tests: SKIPPED \nFlip Traffic: SKIPPED \nAutoScale App: SKIPPED \nE2E Tests: SKIPPED"; break;
                            case 'GET_CERTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: PASSED \nGet Certificates: PASSED \nDeploy Green App: FAILED \nIntegration Tests: SKIPPED \nFlip Traffic: SKIPPED \nAutoScale App: SKIPPED \nE2E Tests: SKIPPED"; break;
                            case 'DEPLOY_GREEN': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: PASSED \nGet Certificates: PASSED \nDeploy Green App: PASSED \nIntegration Tests: FAILED \nFlip Traffic: SKIPPED \nAutoScale App: SKIPPED \nE2E Tests: SKIPPED"; break;
                            case 'INTEGRATION_TESTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: PASSED \nGet Certificates: PASSED \nDeploy Green App: PASSED \nIntegration Tests: PASSED \nFlip Traffic: FAILED \nAutoScale App: SKIPPED \nE2E Tests: SKIPPED"; break;
                            case 'FLIP_TRAFFIC': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: PASSED \nGet Certificates: PASSED \nDeploy Green App: PASSED \nIntegration Tests: PASSED \nFlip Traffic: PASSED \nAutoScale App: FAILED \nE2E Tests: SKIPPED"; break;
                            case 'AUTOSCALE_APP': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: PASSED \nGet Certificates: PASSED \nDeploy Green App: PASSED \nIntegration Tests: PASSED \nFlip Traffic: PASSED \nAutoScale App: PASSED \nE2E Tests: FAILED"; break;
                            case 'E2E_TESTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: PASSED \nGet Certificates: PASSED \nDeploy Green App: PASSED \nIntegration Tests: PASSED \nFlip Traffic: PASSED \nAutoScale App: PASSED \nE2E Tests: PASSED"; break;
                            default: script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: SKIPPED \nInitialize Environment: SKIPPED \nRetrieve Package: SKIPPED \nGet Certificates: SKIPPED \nDeploy Green App: SKIPPED \nIntegration Tests: SKIPPED \nFlip Traffic: SKIPPED \nAutoScale App: SKIPPED \nE2E Tests: SKIPPED"; break;
                        }
                    break;

                    // Prod Release Job for Backend
                    case 'prod-release':
                    case 'src-prod-release':
                        switch (script.env.STAGE_STATUS) {
                            case 'SCM_CHECKOUT': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: FAILED \nRetrieve Package: SKIPPED \nGet Certificates: SKIPPED \nDeploy Green App: SKIPPED \nIntegration Tests: SKIPPED \nFlip Traffic: SKIPPED \nAutoScale App: SKIPPED"; break;
                            case 'INITIALIZE_ENV': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: FAILED \nGet Certificates: SKIPPED \nDeploy Green App: SKIPPED \nIntegration Tests: SKIPPED \nFlip Traffic: SKIPPED \nAutoScale App: SKIPPED"; break;
                            case 'RETRIEVE_PACKAGE': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: PASSED \nGet Certificates: FAILED \nDeploy Green App: SKIPPED \nIntegration Tests: SKIPPED \nFlip Traffic: SKIPPED \nAutoScale App: SKIPPED"; break;
                            case 'GET_CERTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: PASSED \nGet Certificates: PASSED \nDeploy Green App: FAILED \nIntegration Tests: SKIPPED \nFlip Traffic: SKIPPED \nAutoScale App: SKIPPED \nE2E Tests: SKIPPED"; break;
                            case 'DEPLOY_GREEN': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: PASSED \nGet Certificates: PASSED \nDeploy Green App: PASSED \nIntegration Tests: FAILED \nFlip Traffic: SKIPPED \nAutoScale App: SKIPPED"; break;
                            case 'INTEGRATION_TESTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: PASSED \nGet Certificates: PASSED \nDeploy Green App: PASSED \nIntegration Tests: PASSED \nFlip Traffic: FAILED \nAutoScale App: SKIPPED"; break;
                            case 'FLIP_TRAFFIC': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: PASSED \nGet Certificates: PASSED \nDeploy Green App: PASSED \nIntegration Tests: PASSED \nFlip Traffic: PASSED \nAutoScale App: FAILED"; break;
                            case 'AUTOSCALE_APP': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: PASSED \nGet Certificates: PASSED \nDeploy Green App: PASSED \nIntegration Tests: PASSED \nFlip Traffic: PASSED \nAutoScale App: PASSED"; break;
                            default: script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: SKIPPED \nInitialize Environment: SKIPPED \nRetrieve Package: SKIPPED \nGet Certificates: SKIPPED \nDeploy Green App: SKIPPED \nIntegration Tests: SKIPPED \nFlip Traffic: SKIPPED \nAutoScale App: SKIPPED"; break;
                        }
                    break;

                    // Higher Environment Release Jobs for Frontend
                    case 'perf':
                    case 'pre-prod-stl':
                    case 'pre-prod-ksc':
                    case 'prod-stl':
                    case 'prod-ksc':
                    case 'mtf-stl':
                    case 'src-int':
                    case 'src-pre-release':
                    
                        switch (script.env.STAGE_STATUS) {
                            case 'CHECKED_OUT_SCM': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: FAILED \nRetrieve Package: SKIPPED \nPact Publish: SKIPPED \nApp Deployment: SKIPPED \nIntegration Tests: SKIPPED \nExecute E2E: SKIPPED"; break;
                            case 'INITIALIZED_ENV': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: FAILED \nPact Publish: SKIPPED \nApp Deployment: SKIPPED \nIntegration Tests: SKIPPED \nExecute E2E: SKIPPED"; break;
                            case 'RETRIEVED_ARTIFACT': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: PASSED \nPact Publish: FAILED \nApp Deployment: SKIPPED \nIntegration Tests: SKIPPED \nExecute E2E: SKIPPED"; break;
                            case 'PUBLISHED_PACT': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: PASSED \nPact Publish: PASSED \nApp Deployment: FAILED \nIntegration Tests: SKIPPED \nExecute E2E: SKIPPED"; break;
                            case 'DEPLOYED_APP': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: PASSED \nPact Publish: PASSED \nApp Deployment: PASSED \nIntegration Tests: FAILED \nExecute E2E: SKIPPED"; break;
                            case 'EXECUTED_INTEGRATION_TEST': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: PASSED \nPact Publish: PASSED \nApp Deployment: PASSED \nIntegration Tests: PASSED \nExecute E2E: FAILED"; break;
                            case 'EXECUTED_E2E': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: PASSED \nPact Publish: PASSED \nApp Deployment: PASSED \nIntegration Tests: PASSED \nExecute E2E: PASSED"; break;
                            default: script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: SKIPPED \nInitialize Environment: SKIPPED \nRetrieve Package: SKIPPED \nPact Publish: SKIPPED \nApp Deployment: SKIPPED \nIntegration Tests: SKIPPED \nExecute E2E: SKIPPED"; break;
                        }

                        if ( script.env.STAGE_STATUS == "DEPLOYED_APP" || script.env.STAGE_STATUS == "EXECUTED_INTEGRATION_TEST" || script.env.STAGE_STATUS == "EXECUTED_E2E" ) {
                            if (script.params.EXECUTE_INTEGRATION_STAGE == "ENABLE" && script.params.EXECUTE_E2E_STAGE != "ENABLE") {
                                switch (script.env.STAGE_STATUS) {
                                    case 'EXECUTED_INTEGRATION_TEST': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: PASSED \nPact Publish: PASSED \nApp Deployment: PASSED \nIntegration Tests: PASSED \nExecute E2E: SKIPPED"; break;
                                    default: script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: PASSED \nPact Publish: PASSED \nApp Deployment: PASSED \nIntegration Tests: FAILED \nExecute E2E: SKIPPED"; break;
                                }
                            }
                            else if (script.params.EXECUTE_INTEGRATION_STAGE != "ENABLE" && script.params.EXECUTE_E2E_STAGE == "ENABLE") {
                                switch (script.env.STAGE_STATUS) {
                                    case 'EXECUTED_E2E': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: PASSED \nPact Publish: PASSED \nApp Deployment: PASSED \nIntegration Tests: SKIPPED \nExecute E2E: PASSED"; break;
                                    default: script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: PASSED \nPact Publish: PASSED \nApp Deployment: PASSED \nIntegration Tests: SKIPPED \nExecute E2E: FAILED"; break;
                                }
                            }
                            else if (script.params.EXECUTE_INTEGRATION_STAGE != "ENABLE" && script.params.EXECUTE_E2E_STAGE != "ENABLE") {
                                switch (script.env.STAGE_STATUS) {
                                    default: script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nRetrieve Package: PASSED \nPact Publish: PASSED \nApp Deployment: PASSED \nIntegration Tests: SKIPPED \nExecute E2E: SKIPPED"; break;
                                }
                            }
                        }

                        if (script.env.ROLLBACK_STATUS) {
                            script.env.STATUS_EMAIL_BODY = "${script.env.STATUS_EMAIL_BODY} \n\nApplication Rollback: COMPLETED"
                        }

                    break;

                    // Stage Jobs for Backend and Frontend
                    default:
                        switch (script.env.CHANGE_TITLE) {
                            // PR Jobs
                            case String:
                                switch (script.env.FRONTEND_JOB) {
                                    // Frontend PR Job
                                    case 'true':
                                        switch (script.env.STAGE_STATUS) {
                                            case 'CHECKED_OUT_SCM': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: FAILED \nInstall Dependencies: SKIPPED \nBuild: SKIPPED \nLint Tests: SKIPPED \nUnit Tests: SKIPPED \nPact Publish: SKIPPED \nApp Deployment: SKIPPED \nIntegration Tests: SKIPPED \nExecute E2E: SKIPPED"; break;
                                            case 'INITIALIZED_ENV': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: FAILED \nBuild: SKIPPED \nLint Tests: SKIPPED \nUnit Tests: SKIPPED \nPact Publish: SKIPPED \nApp Deployment: SKIPPED \nIntegration Tests: SKIPPED \nExecute E2E: SKIPPED"; break;
                                            case 'INSTALLED_DEPENDENCIES': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: FAILED \nLint Tests: SKIPPED \nUnit Tests: SKIPPED \nPact Publish: SKIPPED \nApp Deployment: SKIPPED \nIntegration Tests: SKIPPED \nExecute E2E: SKIPPED"; break;
                                            case 'BUILD_COMPLETED': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED\nLint Tests: FAILED \nUnit Tests: SKIPPED \nPact Publish: SKIPPED \nApp Deployment: SKIPPED \nIntegration Tests: SKIPPED \nExecute E2E: SKIPPED"; break;
                                            case 'EXECUTED_LINT_TESTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: FAILED \nPact Publish: SKIPPED \nApp Deployment: SKIPPED \nIntegration Tests: SKIPPED \nExecute E2E: SKIPPED"; break;
                                            case 'EXECUTED_UNIT_TESTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nPact Publish: FAILED \nApp Deployment: SKIPPED \nIntegration Tests: SKIPPED \nExecute E2E: SKIPPED"; break;
                                            case 'PUBLISHED_PACT': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nPact Publish: PASSED \nApp Deployment: FAILED \nIntegration Tests: SKIPPED \nExecute E2E: SKIPPED"; break;
                                            case 'DEPLOYED_APP': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nPact Publish: PASSED \nApp Deployment: PASSED \nIntegration Tests: FAILED \nExecute E2E: SKIPPED"; break;
                                            case 'EXECUTED_INTEGRATION_TEST': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nPact Publish: PASSED \nApp Deployment: PASSED \nIntegration Tests: PASSED \nExecute E2E: FAILED"; break;
                                            case 'EXECUTED_E2E': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nPact Publish: PASSED \nApp Deployment: PASSED \nIntegration Tests: PASSED \nExecute E2E: PASSED"; break;
                                            default: script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: SKIPPED \nInitialize Environment: SKIPPED \nInstall Dependencies: SKIPPED \nBuild: SKIPPED \nLint Tests: SKIPPED \nUnit Tests: SKIPPED \nSonar Analysis: SKIPPED \nApp Deployment: SKIPPED \nIntegration Tests: SKIPPED \nExecute E2E: SKIPPED"; break;
                                        }

                                        if (script.env.STAGE_STATUS == "EXECUTED_INTEGRATION_TEST" || script.env.STAGE_STATUS == "EXECUTED_E2E" || script.env.STAGE_STATUS == "UPLOADED_TO_ARTIFACTORY") {
                                            if (script.params.EXECUTE_INTEGRATION_STAGE != "ENABLE" && script.params.EXECUTE_E2E_STAGE != "ENABLE") {
                                                script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nPact Publish: PASSED \nApp Deployment: PASSED \nIntegration Tests: SKIPPED \nExecute E2E: SKIPPED"
                                            } else if (script.params.EXECUTE_INTEGRATION_STAGE == "ENABLE" && script.params.EXECUTE_E2E_STAGE != "ENABLE") {
                                                script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nPact Publish: PASSED \nApp Deployment: PASSED \nIntegration Tests: PASSED \nExecute E2E: SKIPPED"
                                            } else if (script.params.EXECUTE_INTEGRATION_STAGE != "ENABLE" && script.params.EXECUTE_E2E_STAGE == "ENABLE") {
                                                switch (script.env.STAGE_STATUS) {
                                                    case 'EXECUTED_E2E': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nPact Publish: PASSED \nApp Deployment: PASSED \nIntegration Tests: SKIPPED \nExecute E2E: PASSED"; break;
                                                    default: script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nSonar Analysis: PASSED \nApp Deployment: PASSED \nIntegration Tests: SKIPPED \nExecute E2E: FAILED"; break;
                                                }
                                            }
                                        }

                                        if (script.env.ROLLBACK_STATUS) {
                                            script.env.STATUS_EMAIL_BODY = "${script.env.STATUS_EMAIL_BODY} \n\nApplication Rollback: COMPLETED"
                                        }
                                    break;

                                    // Backend PR Job
                                    case null:
                                        switch (script.env.STAGE_STATUS) {
                                            case 'SCM_CHECKOUT': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: FAILED \nUnit Tests: SKIPPED \nBuild Artifact: SKIPPED \nPact Publish: SKIPPED \nSonar Check: SKIPPED \nGet Certificates: SKIPPED \nIntegration Tests: SKIPPED \nPact Verification: SKIPPED \nE2E Tests: SKIPPED"; break;
                                            case 'INITIALIZE_ENV': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nUnit Tests: FAILED \nBuild Artifact: SKIPPED \nPact Publish: SKIPPED \nSonar Check: SKIPPED \nGet Certificates: SKIPPED \nIntegration Tests: SKIPPED \nPact Verification: SKIPPED \nE2E Tests: SKIPPED"; break;
                                            case 'UNIT_TESTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nUnit Tests: PASSED \nBuild Artifact: FAILED \nPact Publish: SKIPPED \nSonar Check: SKIPPED \nGet Certificates: SKIPPED \nIntegration Tests: SKIPPED \nPact Verification: SKIPPED \nE2E Tests: SKIPPED"; break;
                                            case 'BUILD_ARTIFACT': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nUnit Tests: PASSED \nBuild Artifact: PASSED \nPact Publish: FAILED \nSonar Check: SKIPPED \nGet Certificates: SKIPPED \nIntegration Tests: SKIPPED \nPact Verification: SKIPPED \nE2E Tests: SKIPPED"; break;
                                            case 'PUBLISH_PACT': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nUnit Tests: PASSED \nBuild Artifact: PASSED \nPact Publish: PASSED \nSonar Check: FAILED \nGet Certificates: SKIPPED \nIntegration Tests: SKIPPED \nPact Verification: SKIPPED \nE2E Tests: SKIPPED"; break;
                                            case 'SONAR_CHECK': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nUnit Tests: PASSED \nBuild Artifact: PASSED \nPact Publish: PASSED \nSonar Check: PASSED \nGet Certificates: FAILED \nIntegration Tests: SKIPPED \nPact Verification: SKIPPED \nE2E Tests: SKIPPED"; break;
                                            case 'GET_CERTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nUnit Tests: PASSED \nBuild Artifact: PASSED \nPact Publish: PASSED \nSonar Check: PASSED \nGet Certificates: PASSED \nIntegration Tests: FAILED \nPact Verification: SKIPPED \nE2E Tests: SKIPPED"; break;
                                            case 'INTEGRATION_TESTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nUnit Tests: PASSED \nBuild Artifact: PASSED \nPact Publish: PASSED \nSonar Check: PASSED \nGet Certificates: PASSED \nIntegration Tests: PASSED \nPact Verification: FAILED \nE2E Tests: SKIPPED"; break;
                                            case 'VERIFY_PACT': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nUnit Tests: PASSED \nBuild Artifact: PASSED \nPact Publish: PASSED \nSonar Check: PASSED \nGet Certificates: PASSED \nIntegration Tests: PASSED \nPact Verification: PASSED \nE2E Tests: FAILED"; break;
                                            case 'E2E_TESTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nUnit Tests: PASSED \nBuild Artifact: PASSED \nPact Publish: PASSED \nSonar Check: PASSED \nGet Certificates: PASSED \nIntegration Tests: PASSED \nPact Verification: PASSED \nE2E Tests: PASSED"; break;
                                            default: script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: SKIPPED \nInitialize Environment: SKIPPED \nUnit Tests: SKIPPED \nBuild Artifact: SKIPPED \nPact Publish: SKIPPED \nSonar Check: SKIPPED \nGet Certificates: SKIPPED \nIntegration Tests: SKIPPED \nPact Verification: SKIPPED \nE2E Tests: SKIPPED"; break;
                                        }
                                    break;
                                }
                            break;

                            // dev Merge Jobs
                            case null:
                                switch (script.env.FRONTEND_JOB) {
                                    // Frontend dev Merge Job
                                    case 'true':
                                        switch (script.env.STAGE_STATUS) {
                                            case 'CHECKED_OUT_SCM': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: FAILED \nInstall Dependencies: SKIPPED \nBuild: SKIPPED \nLint Tests: SKIPPED \nUnit Tests: SKIPPED \nPact Publish: SKIPPED \nApp Deployment: SKIPPED \nIntegration Tests: SKIPPED \nExecute E2E: SKIPPED \nArtifactory Upload: SKIPPED"; break;
                                            case 'INITIALIZED_ENV': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: FAILED \nBuild: SKIPPED \nLint Tests: SKIPPED \nUnit Tests: SKIPPED \nPact Publish: SKIPPED \nApp Deployment: SKIPPED \nIntegration Tests: SKIPPED \nExecute E2E: SKIPPED \nArtifactory Upload: SKIPPED"; break;
                                            case 'INSTALLED_DEPENDENCIES': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: FAILED \nLint Tests: SKIPPED \nUnit Tests: SKIPPED \nPact Publish: SKIPPED \nApp Deployment: SKIPPED \nIntegration Tests: SKIPPED \nExecute E2E: SKIPPED \nArtifactory Upload: SKIPPED"; break;
                                            case 'BUILD_COMPLETED': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED\nLint Tests: FAILED \nUnit Tests: SKIPPED \nPact Publish: SKIPPED \nApp Deployment: SKIPPED \nIntegration Tests: SKIPPED \nExecute E2E: SKIPPED \nArtifactory Upload: SKIPPED"; break;
                                            case 'EXECUTED_LINT_TESTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: FAILED \nPact Publish: SKIPPED \nApp Deployment: SKIPPED \nIntegration Tests: SKIPPED \nExecute E2E: SKIPPED \nArtifactory Upload: SKIPPED"; break;
                                            case 'EXECUTED_UNIT_TESTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nPact Publish: FAILED \nApp Deployment: SKIPPED \nIntegration Tests: SKIPPED \nExecute E2E: SKIPPED \nArtifactory Upload: SKIPPED"; break;
                                            case 'PUBLISHED_PACT': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nPact Publish: PASSED \nApp Deployment: FAILED \nIntegration Tests: SKIPPED \nExecute E2E: SKIPPED \nArtifactory Upload: SKIPPED"; break;
                                            case 'DEPLOYED_APP': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nPact Publish: PASSED \nApp Deployment: PASSED \nIntegration Tests: FAILED \nExecute E2E: SKIPPED \nArtifactory Upload: SKIPPED"; break;
                                            case 'EXECUTED_INTEGRATION_TEST': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nPact Publish: PASSED \nApp Deployment: PASSED \nIntegration Tests: PASSED \nExecute E2E: FAILED \nArtifactory Upload: SKIPPED"; break;
                                            case 'EXECUTED_E2E': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nPact Publish: PASSED \nApp Deployment: PASSED \nIntegration Tests: PASSED \nExecute E2E: PASSED \nArtifactory Upload: FAILED"; break;
                                            case 'UPLOADED_TO_ARTIFACTORY': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nPact Publish: PASSED \nApp Deployment: PASSED \nIntegration Tests: PASSED \nExecute E2E: PASSED \nArtifactory Upload: PASSED"; break;
                                            default: script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: SKIPPED \nInitialize Environment: SKIPPED \nInstall Dependencies: SKIPPED \nBuild: SKIPPED \nLint Tests: SKIPPED \nUnit Tests: SKIPPED \nSonar Analysis: SKIPPED \nApp Deployment: SKIPPED \nIntegration Tests: SKIPPED \nExecute E2E: SKIPPED \nArtifactory Upload: SKIPPED"; break;
                                        }

                                        if (script.env.STAGE_STATUS == "EXECUTED_INTEGRATION_TEST" || script.env.STAGE_STATUS == "EXECUTED_E2E" || script.env.STAGE_STATUS == "UPLOADED_TO_ARTIFACTORY") {
                                            if (script.params.EXECUTE_INTEGRATION_STAGE != "ENABLE" && script.params.EXECUTE_E2E_STAGE != "ENABLE") {
                                                script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nPact Publish: PASSED \nApp Deployment: PASSED \nIntegration Tests: SKIPPED \nExecute E2E: SKIPPED \nArtifactory Upload: SKIPPED"
                                            } else if (script.params.EXECUTE_INTEGRATION_STAGE == "ENABLE" && script.params.EXECUTE_E2E_STAGE != "ENABLE") {
                                                script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nPact Publish: PASSED \nApp Deployment: PASSED \nIntegration Tests: PASSED \nExecute E2E: SKIPPED \nArtifactory Upload: SKIPPED"
                                            } else if (script.params.EXECUTE_INTEGRATION_STAGE != "ENABLE" && script.params.EXECUTE_E2E_STAGE == "ENABLE") {
                                                switch (script.env.STAGE_STATUS) {
                                                    case 'EXECUTED_E2E': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nPact Publish: PASSED \nApp Deployment: PASSED \nIntegration Tests: SKIPPED \nExecute E2E: PASSED \nArtifactory Upload: FAILED"; break;
                                                    case 'UPLOADED_TO_ARTIFACTORY': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nPact Publish: PASSED \nApp Deployment: PASSED \nIntegration Tests: SKIPPED \nExecute E2E: PASSED \nArtifactory Upload: PASSED"; break;
                                                    default: script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nInstall Dependencies: PASSED \nBuild: PASSED \nLint Tests: PASSED \nUnit Tests: PASSED \nSonar Analysis: PASSED \nApp Deployment: PASSED \nIntegration Tests: SKIPPED \nExecute E2E: FAILED \nArtifactory Upload: SKIPPED"; break;
                                                }
                                            }
                                        }

                                        if (script.env.ROLLBACK_STATUS) {
                                            script.env.STATUS_EMAIL_BODY = "${script.env.STATUS_EMAIL_BODY} \n\nApplication Rollback: COMPLETED"
                                        }

                                    break;

                                    // Backend dev Merge Job
                                    case null:
                                        switch (script.env.STAGE_STATUS) {
                                            case 'SCM_CHECKOUT': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: FAILED \nUnit Tests: SKIPPED \nBuild Artifact: SKIPPED \nSonar Check: SKIPPED \nGet Certificates: SKIPPED \nDeploy Green: SKIPPED \nPact Publish: SKIPPED \nIntegration Tests: SKIPPED \nPact Verification: SKIPPED \nFlip Traffic: SKIPPED \nAutoScale App: SKIPPED \nE2E Tests: SKIPPED \nArtifactory Publish: SKIPPED"; break;
                                            case 'INITIALIZE_ENV': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nUnit Tests: FAILED \nBuild Artifact: SKIPPED \nSonar Check: SKIPPED \nGet Certificates: SKIPPED \nDeploy Green: SKIPPED \nPact Publish: SKIPPED \nIntegration Tests: SKIPPED \nPact Verification: SKIPPED \nFlip Traffic: SKIPPED \nAutoScale App: SKIPPED \nE2E Tests: SKIPPED \nArtifactory Publish: SKIPPED"; break;
                                            case 'UNIT_TESTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nUnit Tests: PASSED \nBuild Artifact: FAILED \nSonar Check: SKIPPED \nGet Certificates: SKIPPED \nDeploy Green: SKIPPED \nPact Publish: SKIPPED \nIntegration Tests: SKIPPED \nPact Verification: SKIPPED \nFlip Traffic: SKIPPED \nAutoScale App: SKIPPED \nE2E Tests: SKIPPED \nArtifactory Publish: SKIPPED"; break;
                                            case 'BUILD_ARTIFACT': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nUnit Tests: PASSED \nBuild Artifact: PASSED \nSonar Check: FAILED \nGet Certificates: SKIPPED \nDeploy Green: SKIPPED \nPact Publish: SKIPPED \nIntegration Tests: SKIPPED \nPact Verification: SKIPPED \nFlip Traffic: SKIPPED \nAutoScale App: SKIPPED \nE2E Tests: SKIPPED \nArtifactory Publish: SKIPPED"; break;
                                            case 'SONAR_CHECK': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nUnit Tests: PASSED \nBuild Artifact: PASSED \nSonar Check: PASSED \nGet Certificates: FAILED \nDeploy Green: SKIPPED \nPact Publish: SKIPPED \nIntegration Tests: SKIPPED \nPact Verification: SKIPPED \nFlip Traffic: SKIPPED \nAutoScale App: SKIPPED \nE2E Tests: SKIPPED \nArtifactory Publish: SKIPPED"; break;
                                            case 'GET_CERTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nUnit Tests: PASSED \nBuild Artifact: PASSED \nSonar Check: PASSED \nGet Certificates: PASSED \nDeploy Green: FAILED \nPact Publish: SKIPPED \nIntegration Tests: SKIPPED \nPact Verification: SKIPPED \nFlip Traffic: SKIPPED \nAutoScale App: SKIPPED \nE2E Tests: SKIPPED \nArtifactory Publish: SKIPPED"; break;
                                            case 'DEPLOY_GREEN': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nUnit Tests: PASSED \nBuild Artifact: PASSED \nSonar Check: PASSED \nGet Certificates: PASSED \nDeploy Green: PASSED \nPact Publish: FAILED \nIntegration Tests: SKIPPED \nPact Verification: SKIPPED \nFlip Traffic: SKIPPED \nAutoScale App: SKIPPED \nE2E Tests: SKIPPED \nArtifactory Publish: SKIPPED"; break;
                                            case 'PUBLISH_PACT': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nUnit Tests: PASSED \nBuild Artifact: PASSED \nSonar Check: PASSED \nGet Certificates: PASSED \nDeploy Green: PASSED \nPact Publish: PASSED \nIntegration Tests: FAILED \nPact Verification: SKIPPED \nFlip Traffic: SKIPPED \nAutoScale App: SKIPPED \nE2E Tests: SKIPPED \nArtifactory Publish: SKIPPED"; break;
                                            case 'INTEGRATION_TESTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nUnit Tests: PASSED \nBuild Artifact: PASSED \nSonar Check: PASSED \nGet Certificates: PASSED \nDeploy Green: PASSED \nPact Publish: PASSED \nIntegration Tests: PASSED \nPact Verification: FAILED \nFlip Traffic: SKIPPED \nAutoScale App: SKIPPED \nE2E Tests: SKIPPED \nArtifactory Publish: SKIPPED"; break;
                                            case 'VERIFY_PACT': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nUnit Tests: PASSED \nBuild Artifact: PASSED \nSonar Check: PASSED \nGet Certificates: PASSED \nDeploy Green: PASSED \nPact Publish: PASSED \nIntegration Tests: PASSED \nPact Verification: PASSED \nFlip Traffic: FAILED \nAutoScale App: SKIPPED \nE2E Tests: SKIPPED \nArtifactory Publish: SKIPPED"; break;
                                            case 'FLIP_TRAFFIC': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nUnit Tests: PASSED \nBuild Artifact: PASSED \nSonar Check: PASSED \nGet Certificates: PASSED \nDeploy Green: PASSED \nPact Publish: PASSED \nIntegration Tests: PASSED \nPact Verification: PASSED \nFlip Traffic: PASSED \nAutoScale App: FAILED \nE2E Tests: SKIPPED \nArtifactory Publish: SKIPPED"; break;
                                            case 'AUTOSCALE_APP': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nUnit Tests: PASSED \nBuild Artifact: PASSED \nSonar Check: PASSED \nGet Certificates: PASSED \nDeploy Green: PASSED \nPact Publish: PASSED \nIntegration Tests: PASSED \nPact Verification: PASSED \nFlip Traffic: PASSED \nAutoScale App: PASSED \nE2E Tests: FAILED \nArtifactory Publish: SKIPPED"; break;
                                            case 'E2E_TESTS': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nUnit Tests: PASSED \nBuild Artifact: PASSED \nSonar Check: PASSED \nGet Certificates: PASSED \nDeploy Green: PASSED \nPact Publish: PASSED \nIntegration Tests: PASSED \nPact Verification: PASSED \nFlip Traffic: PASSED \nAutoScale App: PASSED \nE2E Tests: PASSED \nArtifactory Publish: FAILED"; break;
                                            case 'ARTIFACTORY_PUBLISH': script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: PASSED \nInitialize Environment: PASSED \nUnit Tests: PASSED \nBuild Artifact: PASSED \nSonar Check: PASSED \nArtifactory Publish: PASSED \nGet Certificates: PASSED \nDeploy Green: PASSED \nPact Publish: PASSED \nIntegration Tests: PASSED \nPact Verification: PASSED \nFlip Traffic: PASSED \nAutoScale App: PASSED \nE2E Tests: PASSED \nArtifactory Publish: PASSED"; break;
                                            default: script.env.STATUS_EMAIL_BODY = "${script.env.EMAIL_BODY} \n\n\nSCM Checkout: SKIPPED \nInitialize Environment: SKIPPED \nUnit Tests: SKIPPED \nBuild Artifact: SKIPPED \nSonar Check: SKIPPED \nGet Certificates: SKIPPED \nDeploy Green: SKIPPED \nPact Publish: SKIPPED \nIntegration Tests: SKIPPED \nPact Verification: SKIPPED \nFlip Traffic: SKIPPED \nAutoScale App: SKIPPED \nE2E Tests: SKIPPED \nArtifactory Publish: SKIPPED "; break;
                                        }
                                    break;
                                }
                            break;
                        }
                    break;
                }
            break;
        }
    }
}