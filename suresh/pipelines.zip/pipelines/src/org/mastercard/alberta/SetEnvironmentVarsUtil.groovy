/**
 * org.mastercard.pipeline.utility is a collection of utilities to perform common pipeline tasks.
 */
package org.mastercard.alberta

/**
 * Needs more refactoring to be done.
 */
class SetEnvironmentVarsUtil implements Serializable {

    /**
     * a reference to the pipeline that allows you to run pipeline steps in your shared libary
     */
    def steps

    public final String VALIDATION_JOB_TYPE = "validation";
    /**
     * Constructor
     *
     * @param steps A reference to the steps in a pipeline to give access to them in the shared library.
     */
    public SetEnvironmentVarsUtil(steps) { this.steps = steps }

    public void setDefaultVars() {

        def fileUtil = new org.mastercard.pipeline.utility.FileUtil(steps)
        def pipelineConfigData = fileUtil.readPipelineConfig()
        def envConfiguration = fileUtil.readEnvironmentsConfig()

        steps.echo "Configuring Default Environment Specific Values..."
        //TODO: Need to move prod specific credentials to environmentconfig.yml

        steps.env.STASH_CREDENTIALS = pipelineConfigData.pipeline.credentialids.stash
        steps.env.ARTIFACTORY_CREDENTIALS = pipelineConfigData.pipeline.credentialids.artifactory
        steps.env.SONAR_CREDENTIALS = pipelineConfigData.pipeline.credentialids.sonar
        steps.env.SYNAPSE_CLIENT_NAME = pipelineConfigData.pipeline.synapse.clientname
        steps.env.INTEGRATION_BRANCH = pipelineConfigData.pipeline.branch.integration
        steps.env.BUILD_TEST_EXECUTION = pipelineConfigData.pipeline.buildtestexecution
        steps.env.ALBERTA_ARTIFACTORY_URL = steps.globalVars.artifactory_url

        //steps.env.testFileDir = pipelineConfigData.pipeline.jmeter.testfiledir
        steps.env.INFO_ENDPOINT = pipelineConfigData.pipeline.infoendpoint
        steps.env.ORG_GRADLE_PROJECT_PROVIDER_PORT = steps.globalVars.providerPort
        steps.env.ORG_GRADLE_PROJECT_PROVIDER_PROTOCOL = steps.globalVars.providerProtocol

        //defaulting the environment
        steps.env.startStage = envConfiguration.pr.start
        steps.env.endStage = envConfiguration.pr.end

        steps.env.SERVICE_TYPE = pipelineConfigData.pipeline.serviceType

        steps.env.commit = steps.sh(returnStdout: true, script: "git log -n 1 --pretty=format:'%h'").trim()
        steps.env.CHANGE_AUTHOR = steps.sh(script: 'git --no-pager show -s --format=\'%an\'', returnStdout: true ).trim()
        def changeMessage = steps.sh(script: "git rev-list --format=%B --max-count=1 ${steps.env.commit}", returnStdout: true ).trim()
        steps.env.CHANGE_MESSAGE = changeMessage.replace("\n","").replace("\"", "").replace("'","")        
        steps.env.CHANGE_TITLE = steps.sh(script: "git log --oneline --format=%B -n 1 HEAD | head -n 1", returnStdout: true ).trim()
    }

    public void setPrVars() {
        def fileUtil = new org.mastercard.pipeline.utility.FileUtil(steps)
        def pipelineConfigData = fileUtil.readPipelineConfig()

        steps.echo "Configuring PR Environment Specific Values..."

        steps.env.PCF_ORG = 'SealTeam6-Stage'  //Use this org for pr builds
        steps.env.PCF_FOUNDATION = pipelineConfigData.pipeline.pcf.pr.foundation
        steps.env.PCF_DEV_SPACE = pipelineConfigData.pipeline.pcf.pr.space
        steps.env.PCF_CREDENTIALS = pipelineConfigData.pipeline.pcf.pr.credid
        steps.env.ENTRY_URL = pipelineConfigData.pipeline.pcf.pr.entryurl
        steps.env.redisCustomPlan = 'dedicated-vm'
        //steps.env.redisCustomPlan = pipelineConfigData.pipeline.pcf.pr.redisCustomPlan //TODO move it to an external file

        // Pact Broker URL for Backend
        steps.env.ORG_GRADLE_PROJECT_PACT_BROKER_URL = steps.globalVars.pr_pactBrokerURL

        // Pact Broker URL for Frontend
        steps.env.PACT_BROKER_URL = steps.globalVars.pr_pactBrokerURL

        steps.env.ORG_GRADLE_PROJECT_PROVIDER_HOST = steps.globalVars.providerHost
        steps.env.PACT_BROKER_HOST = steps.globalVars.pr_pactBrokerHost

        steps.env.CERSEI_URL = 'https://' + steps.env.PCF_DEV_SPACE + '-' + 'cersei' + '.' + steps.globalVars.stl_stageDomain
        steps.env.VARYS_URL = 'https://' + steps.env.PCF_DEV_SPACE + '-' + 'varys' + '.' + steps.globalVars.stl_stageDomain
    }

    public void setStageVars() {
        def fileUtil = new org.mastercard.pipeline.utility.FileUtil(steps)
        def pipelineConfigData = fileUtil.readPipelineConfig()
        def envConfiguration = fileUtil.readEnvironmentsConfig()

        steps.echo "Configuring Stage Environment Specific Values..."
        // For Dev Merge Flow
        steps.env.PCF_ORG = pipelineConfigData.pipeline.pcf.stage.org
        steps.env.PCF_FOUNDATION = pipelineConfigData.pipeline.pcf.stage.foundation
        steps.env.PCF_DEV_SPACE = pipelineConfigData.pipeline.pcf.stage.space
        //steps.env.PCF_DEV_SPACE="e2e"
        steps.env.PCF_CREDENTIALS = pipelineConfigData.pipeline.pcf.stage.credid
        steps.env.ENTRY_URL = pipelineConfigData.pipeline.pcf.stage.entryurl
        steps.env.redisCustomPlan = 'dedicated-vm'
        //steps.env.redisCustomPlan = pipelineConfigData.pipeline.pcf.pr.redisCustomPlan //TODO move it to an external file

        // Pact Broker URL for Backend
        steps.env.ORG_GRADLE_PROJECT_PACT_BROKER_URL = steps.globalVars.stage_pactBrokerURL

        // Pact Broker URL for Frontend
        steps.env.PACT_BROKER_URL = steps.globalVars.stage_pactBrokerURL

        steps.env.ORG_GRADLE_PROJECT_PROVIDER_HOST = steps.globalVars.providerHost
        steps.env.PACT_BROKER_HOST = steps.globalVars.stage_pactBrokerHost

        steps.env.CERSEI_URL = 'https://' + steps.env.PCF_DEV_SPACE + '-' + 'cersei' + '.' + steps.globalVars.stl_stageDomain
        steps.env.VARYS_URL = 'https://' + steps.env.PCF_DEV_SPACE + '-' + 'varys' + '.' + steps.globalVars.stl_stageDomain

        //Stage start-end values
        steps.env.startStage = envConfiguration.stage.start
        steps.env.endStage = envConfiguration.stage.end
       //steps.env.commit = steps.sh(returnStdout: true, script: "git log -n 1 --pretty=format:'%h'").trim()
    }

    public void setPerfVars() {
        def fileUtil = new org.mastercard.pipeline.utility.FileUtil(steps)
        def envConfiguration = fileUtil.readEnvironmentsConfig()

        steps.echo "Configuring Perf Environment Specific Values..."

        // For Perf Release
        steps.env.PCF_ORG = envConfiguration.perf.pcf.org
        steps.env.PCF_FOUNDATION = envConfiguration.perf.pcf.foundation
        steps.env.PCF_DEV_SPACE = envConfiguration.perf.pcf.space
        //steps.env.PCF_DEV_SPACE = "e2e"

        steps.env.PCF_CREDENTIALS = envConfiguration.perf.pcf.credid
        steps.env.ENTRY_URL = envConfiguration.perf.pcf.entryurl
        steps.env.ORG_GRADLE_PROJECT_PROVIDER_HOST = steps.globalVars.providerHost
        steps.env.ORG_GRADLE_PROJECT_PACT_BROKER_URL = steps.globalVars.perf_pactBrokerURL
        steps.env.PACT_BROKER_HOST = steps.globalVars.perf_pactBrokerHost

        steps.env.CERSEI_URL = 'https://' + steps.env.PCF_DEV_SPACE + '-' + 'cersei' + '.' + steps.globalVars.stl_stageDomain
        steps.env.VARYS_URL = 'https://' + steps.env.PCF_DEV_SPACE + '-' + 'varys' + '.' + steps.globalVars.stl_stageDomain

        //Stage start-end values
        steps.env.startStage = envConfiguration.perf.start
        steps.env.endStage = envConfiguration.perf.end

    }

    public void setPreProdVars() {
        def fileUtil = new org.mastercard.pipeline.utility.FileUtil(steps)
        def envConfiguration = fileUtil.readEnvironmentsConfig()

        steps.echo "Configuring Pre-Prod Environment Specific Values..."

        // For Pre-Prod Release
        steps.env.PCF_ORG = envConfiguration.preprod.pcf.org
        steps.env.PCF_FOUNDATION = envConfiguration.preprod.pcf.foundation
        steps.env.PCF_DEV_SPACE = envConfiguration.preprod.pcf.space
        steps.env.PCF_CREDENTIALS = envConfiguration.preprod.pcf.credid
        steps.env.ENTRY_URL = envConfiguration.preprod.pcf.entryurl
        steps.env.ORG_GRADLE_PROJECT_PROVIDER_HOST = steps.globalVars.preprodAndprodproviderHost
        steps.env.ORG_GRADLE_PROJECT_PACT_BROKER_URL = steps.globalVars.preprod_pactBrokerURL
        steps.env.PACT_BROKER_HOST = steps.globalVars.preprod_pactBrokerHost

        steps.env.CERSEI_URL = 'https://' + steps.env.PCF_DEV_SPACE + '-' + 'cersei' + '.' + steps.globalVars.stl_prodDomain
        steps.env.VARYS_URL = 'https://' + steps.env.PCF_DEV_SPACE + '-' + 'varys' + '.' + steps.globalVars.stl_prodDomain

        //Stage start-end values
        steps.env.startStage = envConfiguration.preprod.start
        steps.env.endStage = envConfiguration.preprod.end

    }

    public void setProdVars() {
        def fileUtil = new org.mastercard.pipeline.utility.FileUtil(steps)
        def envConfiguration = fileUtil.readEnvironmentsConfig()

        steps.echo "Configuring Prod Environment Specific Values..."

        // For Prod Release
        steps.env.PCF_ORG = envConfiguration.prod.pcf.org
        steps.env.PCF_FOUNDATION = envConfiguration.prod.pcf.foundation
        steps.env.PCF_DEV_SPACE = envConfiguration.prod.pcf.space
        steps.env.PCF_CREDENTIALS = envConfiguration.prod.pcf.credid
        steps.env.ENTRY_URL = envConfiguration.prod.pcf.entryurl
        steps.env.ORG_GRADLE_PROJECT_PROVIDER_HOST = steps.globalVars.preprodAndprodproviderHost
        steps.env.ORG_GRADLE_PROJECT_PACT_BROKER_URL = steps.globalVars.prod_pactBrokerURL
        steps.env.PACT_BROKER_HOST = steps.globalVars.prod_pactBrokerHost

        steps.env.CERSEI_URL = 'https://' + steps.env.PCF_DEV_SPACE + '-' + 'cersei' + '.' + steps.globalVars.stl_prodDomain
        steps.env.VARYS_URL = 'https://' + steps.env.PCF_DEV_SPACE + '-' + 'varys' + '.' + steps.globalVars.stl_prodDomain

        //Stage start-end values
        steps.env.startStage = envConfiguration.prod.start
        steps.env.endStage = envConfiguration.prod.end
    }

    public void setValidationJobVars(String jobType) {
        def fileUtil = new org.mastercard.pipeline.utility.FileUtil(steps)
        def envConfiguration = fileUtil.readEnvironmentsConfig()

        if (jobType == VALIDATION_JOB_TYPE) {

            steps.env.PCF_ORG = envConfiguration.validation.pcf.org
            steps.env.PCF_FOUNDATION = envConfiguration.validation.pcf.foundation
            steps.env.PCF_DEV_SPACE = envConfiguration.validation.pcf.space
            steps.env.PCF_CREDENTIALS = envConfiguration.validation.pcf.credid
            steps.env.ENTRY_URL = envConfiguration.validation.pcf.entryurl
            steps.env.ORG_GRADLE_PROJECT_PROVIDER_HOST = steps.globalVars.providerHost
            steps.env.ORG_GRADLE_PROJECT_PACT_BROKER_URL = steps.globalVars.stage_pactBrokerURL

            steps.env.CERSEI_URL = 'https://' + steps.env.PCF_DEV_SPACE + '-' + 'cersei' + '.' + steps.globalVars.stl_stageDomain
            steps.env.VARYS_URL = 'https://' + steps.env.PCF_DEV_SPACE + '-' + 'varys' + '.' + steps.globalVars.stl_stageDomain

            //Stage start-end values
            steps.env.startStage = envConfiguration.validation.start
            steps.env.endStage = envConfiguration.validation.end
        }

    }

    public void setSrcProdVars() {
        def fileUtil = new org.mastercard.pipeline.utility.FileUtil(steps)
        def envConfiguration = fileUtil.readEnvironmentsConfig()

        steps.echo "Configuring src-prod Environment Specific Values..."

        // For Prod Release
        steps.env.PCF_ORG = envConfiguration.srcprod.pcf.org
        steps.env.PCF_FOUNDATION = envConfiguration.srcprod.pcf.foundation
        steps.env.PCF_DEV_SPACE = envConfiguration.srcprod.pcf.space
        steps.env.PCF_CREDENTIALS = envConfiguration.srcprod.pcf.credid
        steps.env.ENTRY_URL = envConfiguration.srcprod.pcf.entryurl
        steps.env.ORG_GRADLE_PROJECT_PROVIDER_HOST = steps.globalVars.preprodAndprodproviderHost
        steps.env.ORG_GRADLE_PROJECT_PACT_BROKER_URL = steps.globalVars.src_prod_pactBrokerURL
        steps.env.PACT_BROKER_HOST = steps.globalVars.src_prod_pactBrokerHost

        steps.env.CERSEI_URL = 'https://' + steps.env.PCF_DEV_SPACE + '-' + 'cersei' + '.' + steps.globalVars.stl_prodDomain
        steps.env.VARYS_URL = 'https://' + steps.env.PCF_DEV_SPACE + '-' + 'varys' + '.' + steps.globalVars.stl_prodDomain

    }

    public void setStageDynatraceVars() {
        def fileUtil = new org.mastercard.pipeline.utility.FileUtil(steps)
        def envConfiguration = fileUtil.readEnvironmentsConfig()

        steps.echo "Configuring Dynatrace Stage Environment Specific Values..."
        // For Dev Merge Flow
        steps.env.PCF_ORG = envConfiguration.stage.pcf.org
        steps.env.PCF_FOUNDATION = envConfiguration.stage.pcf.foundation
        steps.env.PCF_DEV_SPACE = envConfiguration.stage.pcf.space
        steps.env.PCF_CREDENTIALS = envConfiguration.stage.pcf.credid
        steps.env.redisCustomPlan = 'dedicated-vm'

        //Stage start-end values
        steps.env.startStage = envConfiguration.stage.start
        steps.env.endStage = envConfiguration.stage.end
    }

    public void setenvVarsMRTFrontendPipelinconfig(String selectedenv) {
        def fileUtil = new org.mastercard.pipeline.utility.FileUtil(steps)
        def pipelineConfigData = fileUtil.readPipelineConfig()

        steps.env.SONAR_CREDENTIALS = pipelineConfigData.pipeline.credentialids.sonar
        steps.env.INTEGRATION_BRANCH = pipelineConfigData.pipeline.branch.integration
        steps.env.MRT_JOB_TYPE = pipelineConfigData.pipeline.mrt.jobtype
        steps.env.PCF_FOUNDATION = pipelineConfigData.pipeline.pcf[selectedenv].foundation;
        steps.env.PCF_ORG = pipelineConfigData.pipeline.pcf[selectedenv].org;
        steps.env.PCF_DEV_SPACE = pipelineConfigData.pipeline.pcf[selectedenv].space;
        steps.env.APP_HOST_NAME = steps.env.PCF_DEV_SPACE + "-" + pipelineConfigData.pipeline.hostname;
        steps.env.STASH_CREDENTIALS = pipelineConfigData.pipeline.credentialids.stagestash;
        steps.env.ALBERTA_PCF_CREDENTIALS = pipelineConfigData.pipeline.pcf[selectedenv].credid;
        steps.env.BUILD_FOR_ENV = pipelineConfigData.pipeline.pcf[selectedenv].buildforenv;
        steps.env.CF_LABEL = pipelineConfigData.pipeline.pcf[selectedenv].label.cf;
        steps.env.YARN_LABEL = pipelineConfigData.pipeline.pcf[selectedenv].label.yarn;
        steps.env.SONAR_LABEL = pipelineConfigData.pipeline.pcf[selectedenv].label.sonar;

        steps.env.ALBERTA_ARTIFACTORY_URL = steps.globalVars.artifactory_url

        steps.env.MRT_UI_PUBLIC_NAME = steps.env.PCF_DEV_SPACE + "-" + "mrt-ui"
    }

    public void setenvVarsMRTBackendPipelinconfig(String selectedenv) {

        def fileUtil = new org.mastercard.pipeline.utility.FileUtil(steps)
        def pipelineConfigData = fileUtil.readPipelineConfig()

        steps.env.PCF_FOUNDATION = pipelineConfigData.pipeline.pcf[selectedenv].foundation;
        steps.env.PCF_ORG = pipelineConfigData.pipeline.pcf[selectedenv].org;
        steps.env.PCF_DEV_SPACE = pipelineConfigData.pipeline.pcf[selectedenv].space;
        steps.env.APP_HOST_NAME = steps.env.PCF_DEV_SPACE + "-" + pipelineConfigData.pipeline.hostname;
        steps.env.STASH_CREDENTIALS = pipelineConfigData.pipeline.credentialids.stagestash;
        steps.env.ALBERTA_PCF_CREDENTIALS = pipelineConfigData.pipeline.pcf[selectedenv].credid;
        steps.env.CERSEI_URL = pipelineConfigData.pipeline.pcf[selectedenv].cerseiURL;
        steps.env.CF_LABEL = pipelineConfigData.pipeline.pcf[selectedenv].label.cf;
        steps.env.M3_LABEL = pipelineConfigData.pipeline.pcf[selectedenv].label.m3;
        steps.env.INTEGRATION_BRANCH = pipelineConfigData.pipeline.branch.integration
        steps.env.MRT_JOB_TYPE = pipelineConfigData.pipeline.mrt.jobtype
    }

    public void setSrcIntVars() {
        def fileUtil = new org.mastercard.pipeline.utility.FileUtil(steps)
        def envConfiguration = fileUtil.readEnvironmentsConfig()

        steps.echo "Configuring src-int Environment Specific Values..."

        steps.env.PCF_ORG = envConfiguration.srcint.pcf.org
        steps.env.PCF_FOUNDATION = envConfiguration.srcint.pcf.foundation
        steps.env.PCF_DEV_SPACE = envConfiguration.srcint.pcf.space
        steps.env.PCF_CREDENTIALS = envConfiguration.srcint.pcf.credid
        steps.env.ENTRY_URL = envConfiguration.srcint.pcf.entryurl
        steps.env.ORG_GRADLE_PROJECT_PROVIDER_HOST = steps.globalVars.providerHost
        steps.env.ORG_GRADLE_PROJECT_PACT_BROKER_URL = steps.globalVars.srcint_pactBrokerURL

        steps.env.CERSEI_URL = 'https://' + steps.env.PCF_DEV_SPACE + '-' + 'cersei' + '.' + steps.globalVars.stl_stageDomain
        steps.env.VARYS_URL = 'https://' + steps.env.PCF_DEV_SPACE + '-' + 'varys' + '.' + steps.globalVars.stl_stageDomain

        //Stage start-end values
        //steps.env.startStage = envConfiguration.perf.start
        //steps.env.endStage = envConfiguration.perf.end

    }

    public void setSrcPreReleaseVars() {
        def fileUtil = new org.mastercard.pipeline.utility.FileUtil(steps)
        def envConfiguration = fileUtil.readEnvironmentsConfig()

        steps.echo "Configuring src-pre-release Environment Specific Values..."

        steps.env.PCF_ORG = envConfiguration.srcprerelease.pcf.org
        steps.env.PCF_FOUNDATION = envConfiguration.srcprerelease.pcf.foundation
        steps.env.PCF_DEV_SPACE = envConfiguration.srcprerelease.pcf.space
        steps.env.PCF_CREDENTIALS = envConfiguration.srcprerelease.pcf.credid
        steps.env.ENTRY_URL = envConfiguration.srcprerelease.entryurl
        steps.env.ORG_GRADLE_PROJECT_PROVIDER_HOST = steps.globalVars.providerHost
        steps.env.ORG_GRADLE_PROJECT_PACT_BROKER_URL = steps.globalVars.srcprerelease_pactBrokerURL

        steps.env.CERSEI_URL = 'https://' + steps.env.PCF_DEV_SPACE + '-' + 'cersei' + '.' + steps.globalVars.stl_stageDomain
        steps.env.VARYS_URL = 'https://' + steps.env.PCF_DEV_SPACE + '-' + 'varys' + '.' + steps.globalVars.stl_stageDomain

        //Stage start-end values
        //steps.env.startStage = envConfiguration.perf.start
        //steps.env.endStage = envConfiguration.perf.end

    }

    public void setMtfVars() {
        def fileUtil = new org.mastercard.pipeline.utility.FileUtil(steps)
        def envConfiguration = fileUtil.readEnvironmentsConfig()

        steps.echo "Configuring MTF Environment Specific Values..."

        // For mtf Release
        steps.env.PCF_ORG = envConfiguration.srcmtf.pcf.org
        steps.env.PCF_FOUNDATION = envConfiguration.srcmtf.pcf.foundation
        steps.env.PCF_DEV_SPACE = envConfiguration.srcmtf.pcf.space
        steps.env.PCF_CREDENTIALS = envConfiguration.srcmtf.pcf.credid
        steps.env.ENTRY_URL = envConfiguration.srcmtf.pcf.entryurl
        steps.env.ORG_GRADLE_PROJECT_PROVIDER_HOST = steps.globalVars.preprodAndprodproviderHost
        steps.env.ORG_GRADLE_PROJECT_PACT_BROKER_URL = steps.globalVars.mtf_pactBrokerURL
         steps.env.CERSEI_URL = 'https://' + steps.env.PCF_DEV_SPACE + '-' + 'cersei' + '.' + steps.globalVars.stl_prodDomain
        steps.env.VARYS_URL = 'https://' + steps.env.PCF_DEV_SPACE + '-' + 'varys' + '.' + steps.globalVars.stl_prodDomain
        //Stage start-end values
        //steps.env.startStage = envConfiguration.preprod.start
        //steps.env.endStage = envConfiguration.preprod.end

    }

}
