package org.mastercard.alberta

/**
 * QA Utility functions used to extend functionality of pipeline related to Quality Assurance
 *
 * @Author neel.shah@mastercard.com
 */

class MRTBuildUtil implements Serializable {

    /**
     * a reference to the pipeline that allows you to run pipeline steps in your shared libary
     */
    def steps

    /**
     * Constructor
     *
     * @param steps a reference to the pipeline that allows you to run pipeline steps in your shared libary
     */
    public MRTBuildUtil(steps) { this.steps = steps }

    /**
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param pcfCredentials name of the credentialsId you want to use to access pcf
     * @param appHostName optional host name of the main app which triggered the build as that will be suffixed to the name of every other application deployed
     */

    public void buildAndDeployMRT(script, String pcfCredentials, String mainAppHostName, Map keyMap) {
        def applicationPcfData = ""
        def newAppHostName = "mrt-${mainAppHostName}"
        def pcfUtil = new org.mastercard.pipeline.utility.PCFUtil(steps)

        def albertaPcfUtil = new AlbertaPCFUtil(steps)
        def pcfFoundation = albertaPcfUtil.getPcfFoundation(script)
        def pcfOrg = albertaPcfUtil.getPcfOrg(script)
        def pcfSpace = albertaPcfUtil.getE2ESpaceName(script)


        steps.node('DTL-M3') {
            steps.deleteDir()
            steps.git branch: 'dev', url: 'https://globalrepository.mclocal.int/stash/scm/alberta/mrt-backend.git', credentialsId: pcfCredentials
            steps.sh "${steps.tool 'M3'}/bin/mvn clean install -DskipTests"
            steps.stash includes: '**', name: 'backend-workspace'

        }
        script.env.LIST_OF_APPS_DEPLOYED_E2E = "${script.env.LIST_OF_APPS_DEPLOYED_E2E},${newAppHostName}-api"

        steps.node('DTL-CF-CLI') {
            steps.deleteDir()
            steps.unstash 'backend-workspace'
            steps.withEnv(["CF_HOME=."]) {
                pcfUtil.deployToPCFGoRouter(script,
                        "${newAppHostName}-api",
                        pcfFoundation,
                        pcfOrg,
                        pcfSpace,
                        pcfCredentials, null, null, keyMap, false, false, null)

                def paas_url = script.globalVars.stagePaas_url

                steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: pcfCredentials, usernameVariable: 'PCF_USERNAME', passwordVariable: 'PCF_PASSWORD']]) {
                    steps.sh "cf login -a ${paas_url} -u ${script.PCF_USERNAME} -p ${script.PCF_PASSWORD} -o ${pcfOrg} -s ${pcfSpace}"
                }
                steps.sh "cf set-env ${newAppHostName}-api cerseiURL https://${script.env.E2E_ENTRYPOINT}"
                steps.sh "cf restage ${newAppHostName}-api"
                steps.sh "cf start ${newAppHostName}-api"
                steps.sh "cf logout"
            }
        }

        steps.node('YARN') {
            steps.deleteDir()
            steps.git branch: 'bugfix/include-typings', url: 'https://globalrepository.mclocal.int/stash/scm/alberta/mrt-frontend.git', credentialsId: pcfCredentials
            if (steps.fileExists("src/environments/environment.pr-int.ts")) {
                applicationPcfData = steps.readFile("src/environments/environment.pr-int.ts")
                // Todo: Update this code to perform search and replace in an optimized way over replacing static value
                applicationPcfData = applicationPcfData.replaceAll(/pr-int-cersei.apps.stl.pcfstage00.mastercard.int/, "${script.env.E2E_ENTRYPOINT}")
                applicationPcfData = applicationPcfData.replaceFirst(/pr-int-alberta-js/, "alberta-js-${mainAppHostName}")  //Todo: change it to replaceAll
                //Todo: replace second entry of srcmark with src-stage url
                applicationPcfData = applicationPcfData.replaceAll(/pr-int-merchant-reference-tool-api/, "${newAppHostName}-api")

                script.env.MRT_Tool = "mrt-${mainAppHostName}"

                steps.writeFile(file: "src/environments/environment.pr-int.ts", text: applicationPcfData)
            }
            if (steps.fileExists('yarn.lock')) {
                steps.sh "sed -i 's,https://registry.yarnpkg.com,${steps.env.ALBERTA_ARTIFACTORY_URL}/api/npm/npm-all,g' yarn.lock"
            }
            steps.withEnv(["PATH+NODEJS=${steps.env.NODE8}/bin", "PATH+YARN=${steps.env.YARN1}/bin","PUPPETEER_SKIP_CHROMIUM_DOWNLOAD=true"]) {
                steps.sh "node -v"
                steps.sh "npm install node-sass@4.9.0 --sass-binary-site=${steps.env.ALBERTA_ARTIFACTORY_URL}/archive-external-release/node-sass"
                steps.sh "npm install typings"
                steps.sh "npm install"
                steps.sh "npm run build:pr-int"
            }

            steps.stash includes: '**', name: 'frontend-workspace'

        }
        script.env.LIST_OF_APPS_DEPLOYED_E2E = "${script.env.LIST_OF_APPS_DEPLOYED_E2E},${newAppHostName}"

        steps.node('DTL-CF-CLI') {
            steps.deleteDir()
            steps.unstash 'frontend-workspace'
            steps.withEnv(["CF_HOME=."]) {
                pcfUtil.deployToPCFGoRouter(script,
                        newAppHostName,
                        pcfFoundation,
                        pcfOrg,
                        pcfSpace,
                        pcfCredentials, null, null, keyMap, false, false, null)
            }
        }
    }
}