/*
 * org.mastercard.alberta is a collection of alberta utility tasks for jenkins dsl to perform pipeline related tasks.
*/

package org.mastercard.alberta

/*
 * Common Utility functions used to extend functionality of pipeline
 *
 * @Author Veera.Mallipudi@mastercard.com
*/
class CommonUtil implements Serializable {

    /*
     * a reference to the pipeline that allows us to run pipeline steps in our shared libary
    */
    def steps

    /*
     * Constructor
     *
     * @param steps a reference to the pipeline that allows us to run pipeline steps in our shared libary
    */
    public CommonUtil(steps) {this.steps = steps}

    /*
     * Function to prepare for echo steps to be displayed during the pipeline execution.
     * This function prints the informational message in three lines. By reading the length of second line, this function
     * calculates the lenghts of first and third lines dynamically, and prints the output on Pipeline Console Output.
     *
     * @param newEcho reference to pipeline script, passed directly from the pipeline.
    */

    public void echoSteps(String newEcho) {

        def line2= "***** INFO: ${newEcho} *****"
        def line13=""

        for (int i=0; i < line2.length(); i++)
        {
            line13=line13+"*";
        }

        steps.echo "${line13}"
        steps.echo "${line2}"
        steps.echo "${line13}"
    }

    /*
    * Function to find the repoName for the given artifact url.
    *
    * @param reference to pipeline 'artifact_url' passed directly from the pipeline.
   */

    public String getRepoName(String artifactURL){
        if(artifactURL == "" || artifactURL == null){
            return artifactURL
        }
        def splitArtifactURL = artifactURL.split('alberta')[1].split('/')[1]
        return splitArtifactURL
    }

    /*
     * Function to find the manifestArtifactName for the given artifactID.
     * This function maps the artifactID to manifestArifactName
     *
     * @param reference to pipeline script, artifactID passed directly from the pipeline.
    */
    //TODO Remove this.
    public String getManifestArtifactName(script, String artifactID) {
        if ( artifactID.matches(/.*durable-data-service.*/) ) {
            script.env.manifestArtifactName = "durable-data-service"
        }
        if ( artifactID.matches(/.*identity-service.*/) ) {
            script.env.manifestArtifactName = "identity-service"
        }
        if ( artifactID.matches(/.*remote-logging-service.*/) ) {
            script.env.manifestArtifactName = "remote-logging-service"
        }
        if ( artifactID.matches(/.*srci-merchantdata-services.*/) ) {
            script.env.manifestArtifactName = "srci-merchantdata-services"
        }
        if ( artifactID.matches(/.*srci-middleware.*/) ) {
            script.env.manifestArtifactName = "srci-middleware"
        }
        if ( artifactID.matches(/.*mdes-facade.*/) ) {
            script.env.manifestArtifactName = "mdes-facade"
        }
        //The order should be 'Checkout' and then 'Precheckout' to eliminate string matching issues
        if ( artifactID.matches(/.*checkout-service.*/) ) {
            script.env.manifestArtifactName = "checkout-service"
        }
        //The order should be 'Checkout' and then 'Precheckout' to eliminate string matching issues
        if ( artifactID.matches(/.*precheckout-service.*/) ) {
            script.env.manifestArtifactName = "precheckout-service"
        }
        if ( artifactID.matches(/.*consumer-service.*/) ) {
            script.env.manifestArtifactName = "consumer-service"
        }
        if ( artifactID.matches(/.*utility-service.*/) ) {
            script.env.manifestArtifactName = "utility-service"
        }
        if ( artifactID.matches(/.*card-art-service.*/) ) {
            script.env.manifestArtifactName = "card-art-service"
        }
        if ( artifactID.matches(/.*paymentinstrument-services.*/) ) {
            script.env.manifestArtifactName = "paymentinstrument-services"
        }

        // Added entries to map artifact name to manifestArifactName of app-instance service and address-service
        if ( artifactID.matches(/.*app-instance-service.*/) ) {
            script.env.manifestArtifactName = "app-instance-service"
        }
        if ( artifactID.matches(/.*address-service.*/) ) {
            script.env.manifestArtifactName = "address-service"
        }
        if ( artifactID.matches(/.*cersei.*/) ) {
            script.env.manifestArtifactName = "cersei"
        }
        if ( artifactID.matches(/.*varys.*/) ) {
            script.env.manifestArtifactName = "varys"
        }

        if ( !script.env.manifestArtifactName ) {
            steps.echo "Please Enter an Artifact Name having App Name mentioned in it. \n\n Eg: durable-data-service-1.0-20180514.134220-1.jar"
            script.env.manifestArtifactName = ""
        }
        return script.env.manifestArtifactName
    }

    public void getManifest(String repoBaseName) {
        // def repoBaseName = getManifestArtifactName(steps, artifactId)
        steps.sh """
                  curl -ks -o manifest.yml \
                  "https://globalrepository.mclocal.int/stash/projects/ALBERTA/repos/${repoBaseName}/raw/manifest.yml?at=refs%2Fheads%2Fdev"
           """
    }

    public void getAutoscale(String repoBaseName) {
        // def repoBaseName = getManifestArtifactName(steps, artifactId)
        steps.sh """
                  curl -ks -o autoscale.yml \
                  "https://globalrepository.mclocal.int/stash/projects/ALBERTA/repos/${repoBaseName}/raw/autoscale.yml?at=refs%2Fheads%2Fdev"
           """
    }

    public String getAppNameFromManifest() {
        def manifestAppName = steps.sh(returnStdout: true, script: "grep 'name[ ]*:' manifest.yml | head -1").trim()
        if ( manifestAppName != "" ) {
            manifestAppName = manifestAppName.split(':')[1].replaceAll("\"|\'| ", "")
            steps.echo "appHostName : ${manifestAppName}"
        }else{
            steps.error "Either manifest.yml file not found, or App Name not found in manifest.yml"
        }
        return manifestAppName;
    }

    public int getInstanceCount(String appHostName){
        def instances = steps.sh(script: "cf apps | awk '\$1 == \"${appHostName}''\"' | awk '{print \$3}'",returnStdout: true).trim()
        if(null == instances || instances == ""){
            instances = 0
        }else{
            instances = instances.replaceAll("\"|\'| ", "").split('/')[0]
        }
        
        steps.echo "Current Blue Instances: ${instances}"
        return instances.toInteger()
    }

    public String getPathForRoute(String route){
        def apis = ((route =~ /\/(.*)|([^\/]*)(?<!\/)$/)[0][1])
        String path = (apis != null && "${apis}" != '') ? " --path ${apis}" : ""
        return path
    }

    public String[] getRoutesForApp(String appToGetRouteFrom){
        //map all routes from blue to green
        def allRoutes = steps.sh(script: "cf app ${appToGetRouteFrom}", returnStdout: true).trim()
        def route = ((allRoutes =~ /[r|R]outes:[\s*^\n](.*)/)[0][1]).trim()
        String[] routes = route.split(',')
        return  routes
    }

    public void addResourceFiles(){
        if (steps.fileExists("pipelineconfig.yml")) {
            steps.sh "cp pipelineconfig.yml src/main/resources/"
        }
        if (steps.fileExists("manifest.yml")) {
            steps.sh "cp manifest.yml src/main/resources/"
        }
        if (steps.fileExists("autoscale.yml")) {
            steps.sh "cp autoscale.yml src/main/resources/"
        }

    }

}

