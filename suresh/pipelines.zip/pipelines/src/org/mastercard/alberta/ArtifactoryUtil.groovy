/**
 * org.mastercard.alberta is a collection of alberta utility tasks for jenkins dsl to perform pipeline related tasks.
 */

package org.mastercard.alberta
import java.text.SimpleDateFormat

/**
 * Artifactory Utility functions used to extend functionality of pipeline related to JFrog Artifactory
 *
 * @Author neel.shah@mastercard.com
 */

class ArtifactoryUtil implements Serializable {

    /**
     * a reference to the pipeline that allows you to run pipeline steps in your shared libary
     */
    def steps

    /**
     * a reference to the build directory for artifacts in release or snapshots repo
     */
    def buildDir

    /**
     * a reference to the target directory for artifacts stored in artifactory
     */
    def targetDir

    /**
     * a reference to the file extension for the artifact generated
     */
    def artifactFileType

    /**
     * Location of artifactories
     */
    def artifactoryURL = "https://artifacts.mastercard.int/artifactory/"
    /**
     * Constructor
     *
     * @param steps a reference to the pipeline that allows you to run pipeline steps in your shared libary
     */
    public ArtifactoryUtil(steps) { this.steps = steps }

    /**
     * An object of artifactory server using Artifactory Plugin DSL
     *
     * @param artifactoryCredentials name of the credentialsId you want to use to access artifactory
     */
    public void artifactoryServer(String artifactoryCredentials) {
        steps.Artifactory.newServer( url: artifactoryURL, credentialsId: artifactoryCredentials )
    }

    /**
     * Function to upload artifacts to artifactory
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param artifactoryCredentials name of the credentialsId you want to use to access artifactory
     */
    public void artifactoryUpload(script, String artifactoryCredentials) {

        def hasDup = hasDuplicateArtifact(script, artifactoryCredentials)
        if(hasDup) {
            return
        }

        def version = getVersion()
        def appName = getAppName()

        def orgSpace = getOrgSpace(script.env.ARTIFACTORY_ORGSPACE)

        def artifactName = setArtifactName(appName, version)
        setArtifactTargetDir(orgSpace, appName, version)

        def uploadMap = getUploadSpecMap()
        def artifactVersion = generateArtifactName(appName, version, script.env.commit)

        script.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: artifactoryCredentials , usernameVariable: 'UNAME', passwordVariable: 'PASS']]) {
            script.sh "curl -X PUT -u ${script.UNAME}:${script.PASS} -T ${uploadMap['buildPath']}/${artifactName} ${steps.env.ALBERTA_ARTIFACTORY_URL}/${uploadMap['targetPath']}/${artifactVersion}"
        }

       // artifactoryServer(artifactoryCredentials).upload(getUploadSpec())

        script.env.ARTIFACT_ID = artifactName
        script.env.ARTIFACT_UPLOAD_PATH = getArtifactTargetDir()
        
        //def lastArtifact = readLastJarFromArtifactory("${script.env.ARTIFACT_UPLOAD_PATH}")
        script.env.artifactURL = "${uploadMap['targetPath']}/${artifactVersion}"
    }

    /**
     *
     * @return orgSpace the space in artifactory where the app should be stored in either release/snapshot dir
     */
    public getOrgSpace(String customSpace = null) {
        def orgSpace = customSpace ? customSpace : 'com/mastercard/alberta'
        return orgSpace
    }

    /**
     *
     * @param buildPath
     */
    public void setBuildDir(String buildPath) {
        buildDir = buildPath
    }

    /**
     *
     * @return
     */
    public getBuildDir() {
        return buildDir
    }

    /**
     *
     * @param orgSpace
     * @param appName
     * @param version
     */
    public void setArtifactTargetDir(String orgSpace, String appName, String version) {
        String repoName = artifactoryRepoName()
        targetDir = "${repoName}/${orgSpace}/${appName}/${version}"
    }

    /**
     *
     * @return
     */
    public getArtifactTargetDir() {
        return targetDir
    }

    /**
     *
     * @param fileType
     */
    public void setArtifactFileType(String fileType) {
        artifactFileType = fileType
    }

    /**
     *
     * @return
     */
    public getArtifactFileType() {
        return artifactFileType
    }

    public getVersion() {
        def version = steps.env.NEW_TAG_VERSION
        if(! version) {
            version = getVersionFromFile()
        } else {
            //still call this because it unfortunately has side effects as currently written
            getVersionFromFile()
        }
        return version
    }
    /**
     *
     * @return
     */
    public getVersionFromFile() {
        String version = steps.env.VERSION_FROM_FILE
        if(version) {
            return version
        }
        //String version = ""
        def fromFile
        // Todo #3: check if each of the below files exists before trying to read them. Create precedence order (example check manifest.yml first, then pom.xml then build.gradle, then package.json and so on) to read file. If the required string value is found exit
        if (! version && steps.fileExists("build.gradle") ) {
            fromFile = "build.gradle"
            version = steps.sh(returnStdout: true, script: "grep 'version[ ]*=' ${fromFile} | head -1").trim()

            if ( version ) {
                version = version.split('=')[1].replaceAll("\"|\'| ", "")
            }
            // Todo: copy manifest.yml file if exists to the build dir and update upload spec accordingly to upload manifest.yml file in artifactory along with the builld package.
            setBuildDir("build/libs")
            setArtifactFileType(".jar")
        }
        if (! version && steps.fileExists("pom.xml")) {
            fromFile = "pom.xml"
            def pom = steps.readMavenPom file: fromFile
            version = pom.version
           // version = steps.sh(returnStdout: true, script: "grep 'version[ ]*=' ${fromFile} | head -1").trim()

          //  if ( version != "" ) {
         //       version = version.split('=')[1].replaceAll("\"|\'| ", "")
          //  }
            // Todo: copy manifest.yml file if exists to the build dir and update upload spec accordingly to upload manifest.yml file in artifactory along with the builld package.
            setBuildDir("application/target")
            setArtifactFileType(".jar")
        }
        if (! version && steps.fileExists("manifest.yml")) {
            fromFile = "manifest.yml"
            version = steps.sh(returnStdout: true, script: "grep 'version[ ]*:' ${fromFile} | head -1").trim()
            if ( version ) {
                version = version.split(':')[1].replaceAll("\"|\'| ", "")
            }
        }
        if (! version && steps.fileExists("package.json") ) {
            fromFile = "package.json"
            version = steps.sh(returnStdout: true, script: "grep '\"version\"[ ]*:' ${fromFile} | head -1").trim()
            if ( version ) {
                version = version.split(':')[1].replaceAll("\"|\'|,| ", "")
            }
        }
        steps.env.VERSION_FROM_FILE = version
        return version
    }

    /**
     *
     * @return
     */
    public getAppName() {
        def appName = ""
        def fromFile
        // Todo #4: check if each of the below files exists before trying to read them. Create precedence order (example check manifest.yml first, then pom.xml then build.gradle, then package.json and so on) to read file. If the required string value is found exit
        if (steps.fileExists("manifest.yml") && appName == "") {
            fromFile = "manifest.yml"
            appName = steps.sh(returnStdout: true, script: "grep 'name[ ]*:' ${fromFile} | head -1").trim()
            if ( appName != "" ) {
                appName = appName.split(':')[1].replaceAll("\"|\'| ", "")
            }
        }
        if (steps.fileExists("package.json") && appName == "") {
            fromFile = "package.json"
            appName = steps.sh(returnStdout: true, script: "grep '\"name\"[ ]*:' ${fromFile} | head -1").trim()
            if ( appName != "" ) {
                appName = appName.split(':')[1].replaceAll("\"|\'|,| ", "")
            }
        }
        if (steps.fileExists("build.gradle") && appName == "") {
            fromFile = "build.gradle"
            appName = steps.sh(returnStdout: true, script: "grep 'name[ ]*=' ${fromFile} | head -1").trim()
            if ( appName != "" ) {
                appName = appName.split('=')[1].replaceAll("\"|\'| ", "")
            }
        }
        return appName
    }

    /**
     *
     * @param appName
     * @param version
     * @return
     */
    public setArtifactName(String appName, String version) {
        def fileType = getArtifactFileType()
        def artifactName = generateArtifactBaseName(appName, version)
        return artifactName + fileType
    }

    /**
     *
     * @return
     */
    public getUploadSpec() {
        def buildPath = getBuildDir()
        def targetPath = getTargetDir()
        def artifactFileType = getArtifactFileType()
        steps.echo("buildpath: ${buildPath}, targetPath: ${targetPath} , artifactFileType: ${artifactFileType}")
        def artifactSpec = """{
            "files": [
                {
                  "pattern": "${buildPath}/*${artifactFileType}",
                  "target": "${targetPath}/"
                }
            ]
        }"""
        return artifactSpec
    }

    /**
     *
     * @return
     */
    public getUploadSpecMap() {
        def buildPath = getBuildDir()
        def targetPath = getTargetDir()
        def artifactFileType = getArtifactFileType()
        steps.echo("buildpath: ${buildPath}, targetPath: ${targetPath} , artifactFileType: ${artifactFileType}")
        def artifactSpec = [buildPath: buildPath, targetPath: targetPath, artifactFileType: artifactFileType ]

        return artifactSpec
    }

    /**
     * Function to get Artifact ID
     */

    public getArtifactVersion() {
        def appName = getAppName()
        def uploadMap = getUploadSpecMap()

        def dateFormat = new SimpleDateFormat("yyyyMMddHHmm")
        def date = new Date()
        def currentYear = dateFormat.format(date)

        def artifactVersion = "${appName}-${currentYear}-${script.env.commit}${uploadMap['artifactFileType']}"

        return artifactVersion
    }
    public void artifactoryDownloadFromURL( String artifactUploadPath){
        if (steps.fileExists("pom.xml")){
            setBuildDir("application/target")
        }
        if (steps.fileExists("build.gradle")){
            setBuildDir("build/libs")
        }
        def artifactDir = getBuildDir()
        steps.sh(returnStdout: true, script: "mkdir -p ${artifactDir}")
        def artifactId=steps.sh(returnStdout: true, script: "basename ${artifactUploadPath}")
        steps.env.artifactURL = artifactUploadPath
        steps.dir(artifactDir){
            steps.sh "curl -O --fail ${artifactUploadPath}"
        }
        
        //artifactoryServer(artifactoryCredentials).download(getDownloadSpec(artifactUploadPath, artifactDir))
        if (steps.fileExists("build.gradle")) {
            steps.sh "ls -ltr build/libs"
        }
        if (steps.fileExists("pom.xml")) {
            steps.sh "ls -ltr application/target"
        }
    
        if (steps.fileExists("manifest.yml")) {
            steps.echo "Found manifest.yml file, will update the path value with the downloaded artifact path"
            def manifestData = steps.readFile("manifest.yml")
            steps.writeFile(file: "manifest.yml", text: manifestData.replaceAll(/path:[a-zA-Z0-9. \/-]+/,"path: ${artifactDir}/${artifactId}"))
            steps.sh("more manifest.yml")
        }      
    }
    
    public String artifactoryRepoName() {
        return isSnapshot() ? 'snapshots' : 'releases'
    }

    //disable snapshots completely
    public boolean isSnapshot() {
        //String v = getVersionFromFile()
        //return v != null && v.contains('SNAPSHOT')
        return false;
    }

    /**
     * Function to download artifacts from artifactory
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param artifactId name of the artifact you want to download from artifactory
     */
    public void artifactoryDownload(script, String artifactoryCredentials, String selectedEnvironment = null, String artifactUploadPath = null) {
        //doing a checkout to get the gradle file, configurations related to
        //manifest and pipeline will be obtained from jar
        //this will resolve any conflicts
        //check if gradle is there to get info if not we need to get it, this is necessary in case
      //  if (!steps.fileExists("build.gradle")){
       //     steps.checkout(steps.scm)
      //  }

        def version = getVersion()
        steps.echo "This is the version ${version}"
        def appName = getAppName()
        steps.echo "This is the app name ${appName}"
        def orgSpace = getOrgSpace(script.env.ARTIFACTORY_ORGSPACE)
        setArtifactTargetDir(orgSpace, appName, version)

        //referenced to know where to download to
       // setBuildDir("build/libs")
        artifactUploadPath = targetDir
        steps.echo "This is the target directory ${targetDir}"

        def artifactDir = getBuildDir()
        def artifactId =  setArtifactName(appName, version)
        steps.echo "This is the artifact id ${artifactId}"
		
        if ( !selectedEnvironment ) {
            if ( ! artifactUploadPath ) {
                if ( ! script.env.ARTIFACT_UPLOAD_PATH ) {
                    steps.echo "ERROR: Please provide a path to download artifacts using ARTIFACT_TARGET environment variable"
                    steps.sh "exit 1"
                }
                artifactUploadPath = script.env.ARTIFACT_UPLOAD_PATH
            }
            if ( artifactId ) {
                //this is to account for the change of SNAPSHOT into timestamp
                //i obtain the latest snapshot that was uploaded
                //if its a release there will be only one of it
                //in the case of snapshot there can be multiple
                if(isSnapshot()){

                    def lastArtifact = readLastJarFromArtifactory(artifactUploadPath)

                    if(lastArtifact != "") {
                        artifactId = lastArtifact
                    }
                }
            }
        }
        else {
            //For Release Pipeline
            artifactId = script.env.ArtifactName
            script.env.ArtifactSpace = artifactUploadPath
        }
        steps.echo "This is the artifact id  ${artifactId}"
		
        artifactUploadPath = "${artifactUploadPath}/${artifactId}"

        script.env.artifactURL = artifactUploadPath

        // Todo #5: Prefer to use Jenkins File class over Shell script to check if Dir exists else create it
        steps.sh(returnStdout: true, script: "mkdir -p ${artifactDir}")
        artifactoryServer(artifactoryCredentials).download(getDownloadSpec(artifactUploadPath, artifactDir))

        //check if file was downloaded or exists, else we dont do anything
        if(steps.fileExists("${artifactDir}/${artifactId}")) {
            //get the three files from the jar, instead of checkout
            try {
                steps.sh("jar xf ${artifactDir}/${artifactId} BOOT-INF/classes/manifest.yml BOOT-INF/classes/pipelineconfig.yml BOOT-INF/classes/autoscale.yml")
                //moving and overriding the current files
                steps.sh("mv -f BOOT-INF/classes/*.* .")
                steps.sh("rm -r BOOT-INF")
            }catch(Exception e){
                steps.echo("The app does not have the files required for pipeline configuration")
            }
        }
        else {
            steps.echo "ERROR: Unable to download Artifact: ${artifactId}"
            steps.sh "exit 1"
        }

        if (steps.fileExists("manifest.yml")) {
            steps.echo "Found manifest.yml file, will update the path value with the downloaded artifact path"
            def manifestData = steps.readFile("manifest.yml")
            steps.writeFile(file: "manifest.yml", text: manifestData.replaceAll(/path:[a-zA-Z0-9. \/-]+/,"path: ${artifactDir}/${artifactId}"))
            steps.sh("more manifest.yml")
        }
    }

    /**
     * Generate Full Artifact Name
     */
    public String generateArtifactName(String appName, String version, String commitHash){
        return generateArtifactBaseName(appName, version) + "-" + commitHash + getArtifactFileType()
    }

    public String generateArtifactBaseName(String appName, String version) {
        return appName + "-" + version
    } 

    /**
     * Check for Duplicate Artifacts in Release Artifactory
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param artifactoryCredentials name of the credentialsId you want to use to access artifactory
     */
    public boolean hasDuplicateArtifact(script, String artifactoryCredentials) {
        def version = getVersion()

        def repo = artifactoryRepoName()
        if(! isSnapshot()) {
            def appName = getAppName()
            def orgSpace = getOrgSpace(script.env.ARTIFACTORY_ORGSPACE)
            def artifactName = setArtifactName(appName, version)
            setArtifactTargetDir(orgSpace, appName, version)
            def repoPath = "${orgSpace}/${appName}/${version}"
            def fileNameWildCard = "${appName}-${version}-*"
            def exactFileName = generateArtifactName(appName, version, script.env.commit)
            script.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: artifactoryCredentials , usernameVariable: 'ARTIFACT_USERNAME', passwordVariable: 'ARTIFACT_PASSWORD']]) {
                def artifactorySearchResult=script.sh(returnStdout: true, script: "curl -u ${script.ARTIFACT_USERNAME}:${script.ARTIFACT_PASSWORD} -X POST -d 'items.find({\"name\":{\"\$match\":\"${fileNameWildCard}\"},\"path\":{\"\$eq\":\"${repoPath}\"},\"repo\":{\"\$eq\": \"${repo}\"}})' -H \"Content-Type: text/plain\" https://artifacts.mastercard.int/artifactory/api/search/aql").trim()
                steps.echo(artifactorySearchResult)
                def artifactorySearchResultJson = script.readJSON text: artifactorySearchResult
                if(artifactorySearchResultJson.results && artifactorySearchResultJson.results.size() > 0) {
                    def exactMatchFound = false
                    for(artifactoryInfo in artifactorySearchResultJson.results) {
                        if(artifactoryInfo.name && artifactoryInfo.name == exactFileName) {
                            exactMatchFound = true
                        }
                    }
                    if(!exactMatchFound) {
                        //very rare case could occur if branch got rolled back to earlier tag or if tags have been manually changed
                        steps.echo("Similar Artifact found in Release Artifactory, but OK since not exact match")
                        steps.echo("File Name Wild Card Search: ${fileNameWildCard}")
                        steps.echo("Repo Path: ${repoPath}")
                        return false
                    } else {
                        steps.env.skipPublishArtifactStage = "YES"
                        steps.echo("Exact Match Artifact found in Release Artifactory - script.env.skipPublishArtifactStage ${script.env.skipPublishArtifactStage}")
                        steps.echo("File Name: ${exactFileName}")
                        steps.echo("Repo Path: ${repoPath}")
                        steps.echo("Exact Match Artifact found in Release Artifactory")
                        return true
                    }
                }
            }
        }
        return false
    }

    /**
     * Returns last element in the artifactory diretory
     * @param artifactUploadPath
     * @return
     */
    def readLastJarFromArtifactory(String artifactUploadPath){
        def output = steps.sh returnStdout: true, script: "curl ${artifactoryURL}${artifactUploadPath}/"
        //workaround to obtain the last element of the matching output
        //i do it this way because everything else (e.g. findall) is blocked within jenkins sandbox
        def i  = 0
        def jars = ((output =~ /<a.*>(.+.jar)<\/a>/))
        def lastArtifact = ""
        try{
            def count = 0
            //either terminate when we get the exception or when count is == 100
            //max number of artifacts we can have
            while(true || count != 100){
                def jar = jars[i][1]
                lastArtifact = jar
                i++
                count++
            }
        }catch(Exception e){
            steps.echo("Last element obtained")
            return lastArtifact
        }

        return ""
    }

    /**
     *
     * @param artifactId
     * @param artifactDir
     * @return
     */
    public getDownloadSpec(String artifactId, String artifactDir) {
        def artifactSpec = """{
            "files": [
                {
                  "pattern": "${artifactId}",
                  "target": "${artifactDir}/",
                  "flat": "true"
                }
            ]
        }"""
        return artifactSpec
    }

    /**
     * Uses GRADLE to deploy your code to artifactory. It assumes you have the correct parent pom set up in your project and
     * that you are in the directory with the pom. You also need to have deployer credentials set up in jenkins as they are required to deploy to Artifactory.
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param deployerCredentails string that represents the id of the jenkins credentials used for your Artifactory deployer
     */
    public void gradleDeployToArtifactory(script, String deployerCredentails) {

        steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${deployerCredentails}", usernameVariable: 'UNAME', passwordVariable: 'PASS']]) {
            steps.sh """
                export ARTIFACTORY_USR=${script.UNAME}
                export ARTIFACTORY_PSW=${script.PASS}
                ${script.GRADLE4}/bin/gradle -x clean publish
            """
        }
    }

}
