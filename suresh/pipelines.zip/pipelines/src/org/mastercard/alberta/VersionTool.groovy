package org.mastercard.alberta

import org.mastercard.alberta.VersionTool
import org.mastercard.alberta.GitUtil
import org.mastercard.alberta.ArtifactoryUtil
import org.mastercard.alberta.CommonUtil

/*
 * Semantic version calculator/manipulator
 *
 * @Author ari.kast@mastercard.com
*/
class VersionTool implements Serializable {
    def digitPattern = /(\d+)([-\w]*)/

    static final int MAJOR = 0;
    static final int MINOR = 1;
    static final int PATCH = 2;

    String[] parsedVersion

    private VersionTool() {

    }

    private void parseVersion(String v) {
        parsedVersion = v.trim().split("\\.")
    }

    public void bumpMajor() {
        bumpSlot(MAJOR)
    }

    public void setMajor(String value) {
        setSlot(MAJOR, value)
    }

    public void bumpMinor() {
        bumpSlot(MINOR)
        setPatch("0")
    }

    public void setMinor(String value) {
        setSlot(MINOR, value)
    }

    public void bumpPatch() {
        bumpSlot(PATCH)
    }

    public void setPatch(String value) {
        setSlot(PATCH, value)
    }

    private void bumpSlot(int slot) {
        if(parsedVersion.length > slot) {
            setSlot(slot, bumpNum(parsedVersion[slot]))
        }
    }

    private void setSlot(int slot, String value) {
        if(parsedVersion.length > slot) {
            parsedVersion[slot] = value
        }
    }

    private String bumpNum(String n) {
        String answer = ""
        def found = (n =~ /$digitPattern/)
        if(found) {
            String dig = found.group(1)
            int i = Integer.parseInt(dig)
            i += 1
            String suff = found.group(2)
            answer = i + suff
        }
        return answer
    }

    public String toVersionString() {
        //not allowed by sandbox
        //return String.join(".", parsedVersion)
        //StringBuilder also not allowed

        String sb = ""
        if(parsedVersion.length > 0) {
            sb += parsedVersion[0]
            for(int i=1; i<parsedVersion.length; i++) {
                sb += "."
                sb += parsedVersion[i]
            }
        }
        return sb
    }  

    @Override
    public String toString() {
        return this.toVersionString()
    }

    public static void checkoutCanonicalVersion(steps, GitUtil gitUtil) {
        String curVer = gitUtil.latestTaggedVersionInCommit()

        if(curVer == null || curVer.length() == 0) {
            //current commit was not already version tagged, so search through its ancestry for most recent version tag
            curVer = gitUtil.latestTaggedVersionInAncestry()
            if(curVer != null && curVer.length() > 0) {
                //we have found a prior tag.  if this tag's contents are identical to current commit, then just proceed to build that tag
                //that way no new artifact or commit hash is used, so that these contents are canonically versioned a single time

                String vCurVer = gitUtil.asVersionTag(curVer)
                if(! gitUtil.anyDiffSinceCommit(vCurVer)) {
                    steps.echo("current commit found to be identical to tagged version " + vCurVer )
                    steps.echo("therefore building tag instead so that a single canonical version is maintained for that content set" )
                    gitUtil.checkoutCommit(vCurVer)
                }
            }
        }
    }

    public static void setArtifactVersioningVars(steps, GitUtil gitUtil, ArtifactoryUtil artifactoryUtil) {

        boolean isSnapshot = artifactoryUtil.isSnapshot()
        def env = steps.env

        // if the current commit already has a version tag, then dont re-tag
        String curVer = gitUtil.latestTaggedVersionInCommit()

        if(curVer == null || curVer.length() == 0) {
            //current commit was not already version tagged, so search through its ancestry for most recent version tag
            curVer = gitUtil.latestTaggedVersionInAncestry()

            if(curVer == null || curVer.length() == 0) {
                //no version tags found whatsoever, so start at the basement
                curVer = "0.0.0"
            }

            //since this commit has not been version tagged, we'll generate a version tag for it now
            //only for non-SNAPSHOTs though
            if(! isSnapshot) {
                def versionTool = VersionTool.init(curVer)
                String branch = env.BRANCH_NAME
                if(branch) {
                    branch = branch.toLowerCase()
                    if(branch == "dev" ||
                        branch == "devlop" 
                        || branch == "development") {
                        versionTool.bumpMinor()
                    } else if(branch == "master") {
                        versionTool.bumpPatch()
                    }
                }
                env.NEW_TAG_VERSION=versionTool.toVersionString()
                steps.echo("calculated new version to be " )
                steps.echo(env.NEW_TAG_VERSION)
            } else {
                steps.echo("SNAPSHOT detected, version not bumped or tagged" )
            }
        } else {
            //since this commit already had version tag, we'll set the NEW_TAG_VERSION to 
            //simply be same as PREV_TAG_VERSION.  Then tagging step will recognize that no new tag need be created
            steps.echo("current commit already versioned, will not re-version")
            env.NEW_TAG_VERSION=curVer
        }
        env.PREV_TAG_VERSION=curVer
        if(isSnapshot) {
            env.NEW_TAG_VERSION = env.PREV_TAG_VERSION + "-SNAPSHOT"
        }
    }

    public static void tagIfNeeded(steps, GitUtil gitUtil, ArtifactoryUtil artifactoryUtil, CommonUtil commonUtil)  {
        if (VersionTool.newTagNeeded(steps, artifactoryUtil)) {
            gitUtil.tagVersion(steps.env.NEW_TAG_VERSION)
            commonUtil.echoSteps(
                String.format("git tagged as %s", gitUtil.asVersionTag(steps.env.NEW_TAG_VERSION))
            )
        } else {
            commonUtil.echoSteps(
                String.format("commit already version tagged as %s, no need to re-tag in git", gitUtil.asVersionTag(steps.env.NEW_TAG_VERSION))
            )
        }
    }

    public static boolean newTagNeeded(steps, ArtifactoryUtil artifactoryUtil) {
        return ! artifactoryUtil.isSnapshot() && steps.env.NEW_TAG_VERSION && (steps.env.NEW_TAG_VERSION != steps.env.PREV_TAG_VERSION)
    }

    public static VersionTool init(String version) {
        VersionTool answer = new VersionTool();
        answer.parseVersion(version);
        return answer;
    }

}