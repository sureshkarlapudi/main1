/**
 * org.mastercard.alberta is a collection of alberta utility tasks for jenkins dsl to perform pipeline related tasks.
 */

package org.mastercard.alberta
import java.text.SimpleDateFormat
import groovy.json.*
/**
 *
 * @Author ashok.gattu@mastercard.com
 */

class ReleaseSpecGenUtil implements Serializable {

    /**
     * a reference to the pipeline that allows you to run pipeline steps in your shared libary
     */
    def steps
    def date = new Date()
    def dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm")
    def currentYear = dateFormat.format(date)
    def blueAppList = []
    def paasUrl
    def commitMetadataArray = [:]
    def CONFIG_COMMIT_METADATA
    /**
     * Constructor
     *
     * @param steps a reference to the pipeline that allows you to run pipeline steps in your shared libary
     */
    public ReleaseSpecGenUtil(steps) { this.steps = steps }

    public getListOfAllBlueApps() {

        switch(steps.env.PCF_FOUNDATION) {
            case 'stl-stage':
                paasUrl = 'api.system.stl.pcfstage00.mastercard.int';
                steps.env.STASH_CREDENTIALS = 'alberta-pcfstage';
                steps.env.PCF_CREDENTIALS = 'alberta-pcf-creds-stl-stage'
                break;
            case 'stl-prod':
                paasUrl = 'api.system.stl.pcfprod00.mastercard.int';
                steps.env.STASH_CREDENTIALS = 'stash-creds';
                steps.env.PCF_CREDENTIALS = 'alberta-pcf-creds-stl-prod';
                break;
            case 'stl-dev': paasUrl = 'api.system.stl.pcfdev00.mastercard.int'; break;
            case 'bel-prod': paasUrl = 'api.system.bel.pcfprod00.mastercard.int'; break;
            case 'ksc-prod': paasUrl = 'api.system.ksc.pcfprod00.mastercard.int'; break;
        }
        steps.withEnv(["CF_HOME=."]) {

            try {

                steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${steps.env.PCF_CREDENTIALS}", usernameVariable: 'PCF_USERNAME', passwordVariable: 'PCF_PASSWORD']]) {
                    steps.sh "cf login -a ${paasUrl} -u ${steps.env.PCF_USERNAME} -p ${steps.env.PCF_PASSWORD} -o ${steps.env.PCF_ORG} -s ${steps.env.PCF_DEV_SPACE}"
                }

                blueAppList = steps.sh(script: "cf apps | grep ${steps.env.PCF_DEV_SPACE} | grep 'blue' | grep -v 'back' | awk '{print \$1}'", returnStdout: true).trim()
                blueAppList = blueAppList.split( '\n' )

                CONFIG_COMMIT_METADATA =  steps.sh(script: "cf env ${steps.env.PCF_ORG}-${steps.env.PCF_DEV_SPACE}-git-svc  | grep COMMIT_METADATA | awk -F'COMMIT_METADATA:' '{print \$2}'", returnStdout: true)

                if(!CONFIG_COMMIT_METADATA){
                    CONFIG_COMMIT_METADATA = """{"CHANGE_ID":"No Info","CHANGE_AUTHOR":"No Info","CHANGE_MESSAGE":"No Info"}"""
                }
                CONFIG_COMMIT_METADATA = steps.readJSON text: CONFIG_COMMIT_METADATA

            }
            finally {
                steps.sh "cf logout"
            }

        }
        return blueAppList
    }

    public readCommitMetadata() {
        def blueAppList = getListOfAllBlueApps()

        steps.withEnv(["CF_HOME=."]) {

            try {
                steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${steps.env.PCF_CREDENTIALS}", usernameVariable: 'PCF_USERNAME', passwordVariable: 'PCF_PASSWORD']]) {
                    steps.sh "cf login -a ${paasUrl} -u ${steps.env.PCF_USERNAME} -p ${steps.env.PCF_PASSWORD} -o ${steps.env.PCF_ORG} -s ${steps.env.PCF_DEV_SPACE}"
                }

                blueAppList += ["${steps.env.PCF_DEV_SPACE}-cersei","${steps.env.PCF_DEV_SPACE}-varys"]

                blueAppList.each { blueApp ->
                    def readJsonEnv = steps.sh(script: "cf env ${blueApp} | grep COMMIT_METADATA | awk -F'COMMIT_METADATA:' '{print \$2}'", returnStdout: true)
                    def getArtfactURL = steps.sh(script: "cf env ${blueApp} | grep ArtifactURL | awk '{print \$2}'", returnStdout: true).trim()
                    if(!getArtfactURL){
                        getArtfactURL = "No Info"
                    }
                    if(!readJsonEnv){
                        readJsonEnv = """{"CHANGE_ID":"No Info","CHANGE_AUTHOR":"No Info","CHANGE_MESSAGE":"No Info"}"""
                    }
                    commitMetadataArray."${blueApp}" = steps.readJSON text: readJsonEnv
                    commitMetadataArray."${blueApp}".ARTIFACT_URL = "${steps.env.ALBERTA_ARTIFACTORY_URL}/" + getArtfactURL
                }

            }
            finally {
                steps.sh "cf logout"
            }
        }

        return commitMetadataArray
    }

    public void generateReleaseSpecFile() {

        if ("${steps.env.E2E_CHANGE_AUTHOR}" == '' || "${steps.env.E2E_CHANGE_AUTHOR}" == "null"  ){
            getE2ECommitMetadata("${steps.env.E2E_COMMIT}")
        }

        def commitMetadata = readCommitMetadata()
        def APP_NAME = ""
        def blueAppList = getListOfAllBlueApps()
        def fileUtil = new org.mastercard.pipeline.utility.FileUtil(steps)
        if (steps.fileExists("pipelineconfig.yml")) {
            def pipelineConfigData = fileUtil.readPipelineConfig()
            APP_NAME = pipelineConfigData.pipeline.hostname
        }else{
            APP_NAME = "${steps.env.EXECUTED_BY}"  //For reference
        }

        def releaseSpecTemplate = """
                {"environment":"${steps.env.PCF_DEV_SPACE}","release":"${currentYear}","inputSpecificationFile":"${steps.env.RELEASE_SPEC_URL}","config":{},"e2e":{"EXECUTED_ON":"${currentYear}","EXECUTED_BY":"${APP_NAME}","CHANGE_ID":"${steps.env.E2E_COMMIT}","CHANGE_AUTHOR":"${steps.env.E2E_CHANGE_AUTHOR}","CHANGE_MESSAGE":"${steps.env.E2E_CHANGE_MESSAGE}"},"services":{"backend":{},"ui":{}}}
            """
        def releaseSpecArray = steps.readJSON text: releaseSpecTemplate

        blueAppList.each { blueApp ->
            def splitBlueApp = blueApp - "${steps.env.PCF_DEV_SPACE}-"
            splitBlueApp = splitBlueApp - '-blue'
            releaseSpecArray.services.backend."${splitBlueApp}" = commitMetadata."${blueApp}"
        }
        ['cersei','varys'].each { appName ->
            releaseSpecArray.services.ui."${appName}" = commitMetadata."${steps.env.PCF_DEV_SPACE}-${appName}"
        }


        //Adding config Metadata to final template
        releaseSpecArray.config = CONFIG_COMMIT_METADATA

        def prettyJsonReleaseSpecArray = JsonOutput.prettyPrint(releaseSpecArray.toString())
        commitAndPush(prettyJsonReleaseSpecArray)
    }

    public void commitAndPush(def prettyJsonRelSpec) {
        steps.figlet 'Push Repo'
        //TODO change this to Main repo
        steps.git url:"https://globalrepository.mclocal.int/stash/scm/digops/src-release-specs.git", branch:"master"
        def buildEnv = "${steps.env.PCF_DEV_SPACE}"
        def relSpecPath = "${buildEnv}/${currentYear}.json"

        steps.writeFile file: relSpecPath , text: prettyJsonRelSpec
        steps.sh "ls -latr ${buildEnv}/"
        def gitArr = getUrlStrip()
        def status = steps.sh returnStdout: true, script: "git ls-files --others --exclude-standard  --modified | grep ${relSpecPath} | cut -c1-80 "
        steps.echo "This is status:: ${status}"
        if (status) {
            steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${steps.env.STASH_CREDENTIALS}", usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']]) {
                steps.sh("git add ${relSpecPath}")
                def email = "${steps.env.GIT_USERNAME}@mastercard.com"
                def message = "AUTOMATED_CI_COMMIT: Adding ${relSpecPath} "
                steps.sh("GIT_COMMITTER_NAME='${steps.env.GIT_USERNAME}' GIT_COMMITTER_EMAIL='${email}' git commit -m '${message}' --author='${steps.env.GIT_USERNAME} <${email}>'")
                steps.sh('git push https://${GIT_USERNAME}:${GIT_PASSWORD}@' + "${gitArr[1]}")
            }
            steps.sh "echo Updated and Committed the File: ${relSpecPath}"

        }
    }

    public  getUrlStrip() {
        def url = steps.sh returnStdout: true, script: 'git config --get remote.origin.url'
        def branch = steps.sh returnStdout: true, script: 'git rev-parse --abbrev-ref HEAD'
        def gitArr = []
        gitArr << branch
        gitArr << url.replaceFirst("^(http(?>s)://www\\.|http(?>s)://|www\\.)", "")
        return gitArr
    }


    public getCommitMetadata() {
        def requestTemplate = """{"CHANGE_ID":"${steps.env.commit}","CHANGE_AUTHOR":"${steps.env.CHANGE_AUTHOR}","CHANGE_MESSAGE":"${steps.env.CHANGE_MESSAGE}"}"""
        return requestTemplate
    }

    public getE2ECommitMetadata(String commitID){
        ///try{
        def gitRepo = "https://globalrepository.mclocal.int/stash/scm/alberta/trident-alberta-e2e.git"
        steps.checkout([$class: 'GitSCM', credentialsId: "${steps.env.STASH_CREDENTIALS}", branches: [[name: "${commitID}"]],
                        userRemoteConfigs: [[url: "${gitRepo}"]]])
        steps.env.E2E_COMMIT = steps.sh(returnStdout: true, script: "git log -n 1 --pretty=format:'%h'").trim()
        steps.env.E2E_CHANGE_AUTHOR = steps.sh(script: 'git --no-pager show -s --format=\'%an\'', returnStdout: true ).trim()
        def changeMessage = steps.sh(script: "git rev-list --format=%B --max-count=1 ${steps.env.E2E_COMMIT}", returnStdout: true ).trim()
        steps.env.E2E_CHANGE_MESSAGE = changeMessage.replace("\n","").replace("\"", "")

        // }catch (Exception ex){
        //    echo "${ex}"
        //     steps.sh "exit 1"
        // }

    }

    public  getDeployedArtifactURL(String pcfAppName, String Environment){
        def CF_CLI_LABEL = Environment.contains('prod') ? "CF-CLI" : "DTL-CF-CLI"
        def deployedArtifactURL
        def paasUrl

        switch(Environment) {
            case 'pre-prod-release':
                paasUrl = 'api.system.stl.pcfprod00.mastercard.int';
                steps.env.STASH_CREDENTIALS = 'stash-creds';
                steps.env.PCF_CREDENTIALS = 'alberta-pcf-creds-stl-prod';
                steps.env.PCF_ORG = "Alberta"
                steps.env.PCF_DEV_SPACE = "pre-prod"
                break;
            case 'prod-release':
                paasUrl = 'api.system.stl.pcfprod00.mastercard.int';
                steps.env.STASH_CREDENTIALS = 'stash-creds';
                steps.env.PCF_CREDENTIALS = 'alberta-pcf-creds-stl-prod';
                steps.env.PCF_ORG = "Alberta"
                steps.env.PCF_DEV_SPACE = "prod"
                break;
            case 'mtf-release':
                paasUrl = 'api.system.stl.pcfprod00.mastercard.int';
                steps.env.STASH_CREDENTIALS = 'stash-creds';
                steps.env.PCF_CREDENTIALS = 'alberta-pcf-creds-stl-prod';
                steps.env.PCF_ORG = "Alberta"
                steps.env.PCF_DEV_SPACE = "src-mtf"
                break;
            case 'perf-release':
                paasUrl = 'api.system.stl.pcfstage00.mastercard.int';
                steps.env.STASH_CREDENTIALS = 'alberta-pcfstage';
                steps.env.PCF_CREDENTIALS = 'alberta-pcf-creds-stl-stage'
                steps.env.PCF_ORG = "Alberta"
                steps.env.PCF_DEV_SPACE = "src-perf"
                break;
        }

        steps.node("${CF_CLI_LABEL}") {

            steps.withEnv(["CF_HOME=."]) {

                steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${steps.env.PCF_CREDENTIALS}", usernameVariable: 'PCF_USERNAME', passwordVariable: 'PCF_PASSWORD']]) {
                    steps.sh "cf login -a ${paasUrl} -u ${steps.env.PCF_USERNAME} -p ${steps.env.PCF_PASSWORD} -o ${steps.env.PCF_ORG} -s ${steps.env.PCF_DEV_SPACE}"
                }
                if( pcfAppName == 'varys' || pcfAppName == 'cersei'){

                    deployedArtifactURL = steps.sh(script: "cf env ${steps.env.PCF_DEV_SPACE}-${pcfAppName} | grep ArtifactURL | awk '{print \$2}'", returnStdout: true).trim()

                }else{

                    deployedArtifactURL = steps.sh(script: "cf env ${steps.env.PCF_DEV_SPACE}-${pcfAppName}-blue | grep ArtifactURL | awk '{print \$2}'", returnStdout: true).trim()

                }


            }
        }
        return deployedArtifactURL

    }

}