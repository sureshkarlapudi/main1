/**
 * org.mastercard.alberta is a collection of alberta utility tasks for jenkins dsl to perform pipeline related tasks.
 */

package org.mastercard.alberta

/**
 *
 * @Author ashok.gattu@mastercard.com
 */

class ContractTestingUtil implements Serializable {

    /**
     * a reference to the pipeline that allows you to run pipeline steps in your shared libary
     */
    def steps
    def contractMap =[:]

    /**
     * Constructor
     *
     * @param steps a reference to the pipeline that allows you to run pipeline steps in your shared libary
     */
    public ContractTestingUtil(steps) { this.steps = steps }

    /**
     * Checking for the backend or frontend code
     *
     */

    public checkBackendFrontend() {
        def codeType = ''
        if (steps.fileExists("build.gradle")) {
            codeType = "backEnd"
        }
        else{
            codeType = "frontEnd"
        }
        return codeType
    }

    /**
     * Backend Contract Testing which returns the service Type for backend code.
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param serviceName service name which is the repo name
     * @return contract_map map which has the info if the service is consumer or provider or consumer-provider
     */

    public backendCT(boolean isBlueGreenDeployment, String stashCredentials, String pactBrokerURL, String env = "stage") {
        def statusCodeConsumer
        def statusCodeProvider
        def statusCodeConsumerProvider

        def serviceName = getApplicationName(isBlueGreenDeployment)
       
        def CF_CLI_LABEL = env.contains('prod') ? "GRADLE" : "DTL-GRADLE"
        def branchName = "master"
        // steps.node('DTL-GRADLE')
        steps.node("${CF_CLI_LABEL}") {
            try {
                def gitRepo = "https://globalrepository.mclocal.int/stash/scm/alberta/contract-validator-java.git"
                steps.deleteDir()
                steps.git branch: branchName, url: gitRepo, credentialsId: stashCredentials

                statusCodeConsumer = steps.sh(returnStatus: true, script: "${steps.env.GRADLE4}/bin/gradle test -DURL=${pactBrokerURL} -DSERVICE_NAME=${serviceName} -DPROVIDER_CHECK=false -DCONSUMER_CHECK=true > /dev/null 2>&1 ")
                statusCodeProvider = steps.sh(returnStatus: true, script: "${steps.env.GRADLE4}/bin/gradle test -DURL=${pactBrokerURL} -DSERVICE_NAME=${serviceName}  -DPROVIDER_CHECK=true -DCONSUMER_CHECK=false > /dev/null 2>&1 ")
                statusCodeConsumerProvider = steps.sh(returnStatus: true, script: "${steps.env.GRADLE4}/bin/gradle test -DURL=${pactBrokerURL} -DSERVICE_NAME=${serviceName}  -DPROVIDER_CHECK=true -DCONSUMER_CHECK=true > /dev/null 2>&1 ")

                steps.echo "This is the list from Contract Testing  library: ${statusCodeConsumer} and ${statusCodeProvider} and ${statusCodeConsumerProvider}"
                contractMap = [statusCodeConsumer: "${statusCodeConsumer}", statusCodeProvider: "${statusCodeProvider}", statusCodeConsumerProvider: "${statusCodeConsumerProvider}"]

                return contractMap
            }
            finally {
                steps.deleteDir()
            }
        }
    }

    /**
     * Frontend Contract Testing which returns the service Type for UI code.
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param serviceName service name which is the repo name
     * @return contract_map map which has the info if the service is consumer or provider or consumer-provider
     */

    public frontendCT(boolean isBlueGreenDeployment, String stashCredentials, String pactBrokerURL) {
        def statusCodeConsumer
        def statusCodeProvider
        def statusCodeConsumerProvider

        def serviceName = getApplicationName(isBlueGreenDeployment)

        def branchName = "master"
        def gitRepo = "https://globalrepository.mclocal.int/stash/scm/alberta/trident-contract-report-js.git"
        steps.node('DTL-YARN') {
            try {
                steps.deleteDir()
                steps.git branch: branchName, url: gitRepo, credentialsId: stashCredentials
                steps.withEnv(["PATH+NODEJS=${steps.env.NODE9}/bin", 'PATH+GULP=node_modules/.bin']) {

                    statusCodeConsumer = steps.sh(returnStatus: true, script: "npm install && SERVICE=${serviceName}  IS_CONSUMER=true IS_PROVIDER=false NODE_TLS_REJECT_UNAUTHORIZED=0 PACT_BROKER_URI=${pactBrokerURL} node src/ContractValidation.js > /dev/null 2>&1 ")
                    statusCodeProvider = steps.sh(returnStatus: true, script: "npm install && SERVICE=${serviceName}  IS_CONSUMER=false IS_PROVIDER=true NODE_TLS_REJECT_UNAUTHORIZED=0 PACT_BROKER_URI=${pactBrokerURL} node src/ContractValidation.js > /dev/null 2>&1 ")
                    statusCodeConsumerProvider = steps.sh(returnStatus: true, script: "npm install && SERVICE=${serviceName}  IS_CONSUMER=true IS_PROVIDER=true NODE_TLS_REJECT_UNAUTHORIZED=0 PACT_BROKER_URI=${pactBrokerURL} node src/ContractValidation.js > /dev/null 2>&1 ")
                }
                steps.echo "This is the list from Contract Testing  library: ${statusCodeConsumer} and ${statusCodeProvider} and ${statusCodeConsumerProvider}"
                contractMap = [statusCodeConsumer: "${statusCodeConsumer}", statusCodeProvider: "${statusCodeProvider}", statusCodeConsumerProvider: "${statusCodeConsumerProvider}"]
                steps.deleteDir()

                return contractMap

            }
            finally {
                steps.deleteDir()
            }
        }
    }

    private void pactVerify( String env = null ){
        def albertaPcfUtil = new AlbertaPCFUtil(steps)
        def artifacoryUtil = new ArtifactoryUtil(steps)

        def appHostName = artifacoryUtil.getAppName()
        def myPcfSpace =  albertaPcfUtil.getIntSpaceName(steps)
        
        if ( steps.env.CHANGE_ID ) {
            steps.env.pvAppHostName  = "${myPcfSpace}-${appHostName}-${steps.env.CHANGE_ID}"
        }
        else {
            steps.env.pvAppHostName = "green-${appHostName}"
        }

        if (env == "prod-release"|| env == "pre-prod-release" ) {
            steps.env.ORG_GRADLE_PROJECT_PROVIDER_HOST = "${steps.env.pvAppHostName}" +"."+ "${steps.globalVars.preprodAndprodproviderHost}"
        } else {
            steps.env.ORG_GRADLE_PROJECT_PROVIDER_HOST = "${steps.env.pvAppHostName}" +"."+ "${steps.globalVars.providerHost}"
        }

        steps.echo "This is PROVIDER_HOST:: ${steps.env.ORG_GRADLE_PROJECT_PROVIDER_HOST}"

        steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'pactbroker_credentials', usernameVariable: 'PB_USERNAME', passwordVariable: 'PB_PASSWORD']]) {
          steps.sh "${steps.env.GRADLE4}/bin/gradle pactVerify  -Dusername=${steps.PB_USERNAME} -Dpassword=${steps.PB_PASSWORD}"

        }

    }


    private String getApplicationName(boolean isBlueGreenDeployment){
       //steps.unstash 'workspace'
        def manifestData = steps.readYaml file: "manifest.yml"

        if (manifestData.applications) {
            if (isBlueGreenDeployment) {
                return "${manifestData.applications[0].name}'-blue'"
            } else {
                return manifestData.applications[0].name
            }

        } else {
            steps.error "Either manifest.yml file not found or Application name not found in manifest.yml"
        }
    }

    /**
     * Update gradle.properties file with the new username and password if provided
     *
     */

    public void updateGradleProperties() {

        if (steps.fileExists(".gradle/gradle.properties")) {
            steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'pactbroker_credentials', usernameVariable: 'PB_USERNAME', passwordVariable: 'PB_PASSWORD']]) {
                steps.sh "printf 'username=${steps.PB_USERNAME}\npassword=${steps.PB_PASSWORD}\n' >> .gradle/gradle.properties"
                steps.sh "cat .gradle/gradle.properties"
            }

        }
        else if (steps.fileExists("build.gradle")){
            steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'pactbroker_credentials', usernameVariable: 'PB_USERNAME', passwordVariable: 'PB_PASSWORD']]) {
                steps.sh "mkdir -p -m 777 .gradle"
                steps.sh "printf 'username=${steps.PB_USERNAME}\npassword=${steps.PB_PASSWORD}\n' >> .gradle/gradle.properties"
                steps.sh "cat .gradle/gradle.properties"
            }
        }
        else{

        }
    }


}
