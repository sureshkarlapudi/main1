
package org.mastercard.alberta

class PipelineUtil {
    def steps

    public PipelineUtil(steps) {
        this.steps = steps
    }

    public void buildVarys(String ALBERTA_CREDENTIALS) {
        steps.echo "Building Varys"
        steps.git branch: "dev", url: "https://globalrepository.mclocal.int/stash/scm/ALBERTA/varys.git", credentialsId: ALBERTA_CREDENTIALS
        steps.sh "SASS_BINARY_SITE=${steps.env.ALBERTA_ARTIFACTORY_URL}/archive-external-release/node-sass/ CYPRESS_INSTALL_BINARY=0 npm i"
        steps.sh "npm run build:stage"
        steps.stash includes: '**', name: 'varys'
    }

    public void buildCersei(String ALBERTA_CREDENTIALS) {
        steps.echo "Building Cersei"
        steps.git branch: "dev", url: "https://globalrepository.mclocal.int/stash/scm/ALBERTA/cersei.git", credentialsId: ALBERTA_CREDENTIALS
        steps.sh "SASS_BINARY_SITE=${steps.env.ALBERTA_ARTIFACTORY_URL}/archive-external-release/node-sass/ CYPRESS_INSTALL_BINARY=0 npm i"
        steps.sh "npm run build:stage"
        steps.stash includes: '**', name: 'cersei'
    }

    public void pullE2ETests() {
        steps.echo "Building E2E"
        steps.git branch: "master", url: "https://globalrepository.mclocal.int/stash/scm/~e046132/alberta-e2e-poc.git"
        steps.sh "npm i"
        steps.stash includes: '**', name: 'e2e'
    }

    public void runE2E(String host) {
        steps.unstash 'e2e'
        steps.sh 'curl -o xvfb-wrapper.sh https://globalrepository.mclocal.int/stash/projects/BAS/repos/xvfb-wrapper/raw/xvfb-wrapper.sh?at=refs%2Fheads%2Fmaster'
        steps.sh 'chmod +x xvfb-wrapper.sh'
        steps.sh "./xvfb-wrapper.sh ENTRY_URL=https://${host}.apps.stl.pcfstage00.mastercard.int npm run e2e:ci"
        steps.stash includes: '**', name: 'e2e'
    }

    public void renameHost(String newHost) {
        if (steps.fileExists("manifest.yml")) {
            def manifestData = steps.readFile("manifest.yml")
            steps.echo manifestData
            steps.writeFile(file: "manifest.yml", text: manifestData.replaceAll(/host:[a-zA-Z0-9. \/-]+/,"host: ${newHost}"))
        }
    }

    public void rename(String newHost, String newName) {
        renameHost(newHost)
        renameName(newName)
    }

    public void renameName(String newName) {
        if (steps.fileExists("manifest.yml")) {
            def manifestData = steps.readFile("manifest.yml")
            steps.writeFile(file: "manifest.yml", text: manifestData.replaceAll(/name:[a-zA-Z0-9. \/-]+/, "name: ${newName}"))
            steps.echo steps.readFile("manifest.yml")
        }
    }

    public void inputStep(String groupName, String message){
        steps.echo "Do you want to proceed to next stage"
        steps.input(message: message, ok: "Proceed", submitter:groupName)
    }

    public void inputTimeDelay(int input){
        steps.echo "Waiting ${input} seconds "
        steps.sleep input
    }

    public String scriptUpdateVersionInAppProps(String versionB) {
        return String.format("newversion=%s\n", versionB) + ''' 
            GREP=grep
            FILE=src/main/resources/application.properties
            touch $FILE

            $GREP -P 'info\\.version\\s*=' $FILE || {
                echo "creating file for version info"
                echo 'info.version='$newversion >> $FILE
            }

            perl -pi -e 's/(info\\.version)\\s*=\\s*(.*)/\\1='$newversion'/' $FILE                            
        '''        
    }

    public String scriptUpdateVersionInGradleBuild(String versionB) {
        return String.format("newversion=%s\n", versionB) + ''' 
            GREP=grep
            FILE=build.gradle

            perl -pi -e "s/^\\s*(version)\\s*=\\s*(.*)/\\1='$newversion'/" $FILE                            
        '''
    }
    public String scriptUpdateJarInManifest(String jarName) {
        return String.format("newversion=%s\n", jarName) + ''' 
            GREP=grep
            FILE=manifest.yml

            perl -pi -e "s#^(\\s*path):\\s+(.*)#\\1: build/libs/$newversion#" $FILE                            
        '''
    }

}
