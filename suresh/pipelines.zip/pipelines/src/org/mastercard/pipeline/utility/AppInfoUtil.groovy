/**
 * org.mastercard.pipeline.utility is a collection of utilities to perform common pipeline tasks.
 */
package org.mastercard.pipeline.utility

/**
 * Utility which gives us method to know information about the build
 *
 * @Author semal.gajera@mastercard.com
 */

class AppInfoUtil implements Serializable {

    /**
     * Returns the version of the application running with this name
     * @param steps
     * @param appName
     * @param env
     * @param apiInfoEndpoint
     * @return
     */
    public static String getBuildVersionOfRunningApp(Object steps, String appName, String env, String apiInfoEndpoint) {

        String appDomain

        switch(env) {
            case 'stl-dev': appDomain = steps.globalVars.DEV_PAAS_DOMAIN; break
            case 'stl-stage': appDomain = steps.globalVars.STAGE_PAAS_DOMAIN; break
            case 'bel-prod': appDomain = steps.globalVars.BEL_PROD_PAAS_DOMAIN; break
            case 'stl-prod': appDomain = steps.globalVars.STL_PROD_PAAS_DOMAIN; break
            case 'ksc-prod': appDomain = steps.globalVars.KSC_PROD_PAAS_DOMAIN; break
        }
        try {
            def info = steps.sh(returnStdout: true, script: "curl https://blue-${appName}.${appDomain}/${apiInfoEndpoint}").trim()
            def infoJson = steps.readJSON text: info
            return "${infoJson.build.version}"
        }catch(Exception e){
            steps.echo("Something went wrong trying to reach info api.")
            //default will be whatever it would do without the trigger
            return "SNAPSHOT"
        }

    }


}