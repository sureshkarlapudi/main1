package org.mastercard.pipeline.utility

/**
 * Utility to handle Synapse related tasks.
 *
 * @Author indrajitsinh.gohil@mastercard.com
 */
class SynapseUtil implements Serializable {



	/**
	 * This method takes basic Synapse related params and returns map has all environment variables related to Synapse.
	 *
	 * @param keyMap This should contain below items:
	 * 		encodedKeyfile -
	 * 		encodedKeyfilePassword -
	 *		encodedTruststore -
	 *		encodedTruststorePassword -
	 * @param env Environmant on which you are trying to enable synapse. Possible values are : 'stl-dev', 'stl-stage',
	 * @param isLocusInin A boolean to identify Locus init status to set.
	 */
	public static Map getEnvVar(Object steps, Map keyMap, String env, boolean isLocusInin = false, boolean vaultEnabled = false){

		def Map envVars = [:]

		def encodedClientKeyFile = keyMap["encodedKeyfile"]
		def encodedClientKeyFilePassword = keyMap["encodedKeyfilePassword"]
		def encodedTrustoreFile = keyMap["encodedTruststore"]
		def encodedTrustoreFilePassword = keyMap["encodedTruststorePassword"]
		def vaultCredentialsId
		def vaultBackendId
		def vaultAppName

		envVars['KEYSTORE'] = "${encodedClientKeyFile}"
		envVars['TRUSTSTORE'] = "${encodedTrustoreFile}"
		envVars['KEYSTORE_PASSWORD'] = "${encodedClientKeyFilePassword}"
		envVars['TRUSTSTORE_PASSWORD'] = "${encodedTrustoreFilePassword}"
		envVars['SYNAPSE_SSL_KEYSTORE_LOCATION'] = "KEYSTORE"
		envVars['SYNAPSE_SSL_TRUSTSTORE_LOCATION'] = "TRUSTSTORE"
		envVars['SYNAPSE_SSL_KEYSTORE_CLIENT_ALIAS'] = "client-common"
		envVars['SYNAPSE_SSL_KEYSTORE_TYPE'] = "JKS"
		envVars['ENABLE_LOCUS_INIT'] = "${isLocusInin}"
		envVars['ArtifactURL'] = "${steps.env.artifactURL}"
		envVars['Cert_Valid_From'] = "'${steps.env.certValidFrom}'"
        envVars["Cert_Valid_Until"] = "'${steps.env.certValidUntil}'"

		// setting commit Metadata to Env Vars
		def releaseUtil = new org.mastercard.alberta.ReleaseSpecGenUtil(steps)
		def commitMetadata = releaseUtil.getCommitMetadata()
		envVars["COMMIT_METADATA"] = "'${commitMetadata}'"

		switch(env) {
			case 'stl-dev':
				envVars['APIE_REGION'] = "US"
				envVars['APIE_PLATFORM'] = "DEV"
				envVars['APIE_ZONE'] = "STL"
				break
			case 'stl-stage':
				envVars['APIE_REGION'] = "US"
				envVars['APIE_PLATFORM'] = "STAGE"
				envVars['APIE_ZONE'] = "STL"
				break
			case 'stl-pre-prod':
				envVars['APIE_REGION'] = "US"
				envVars['APIE_PLATFORM'] = "MTF"
				envVars['APIE_ZONE'] = "STL"
				break
			case 'bel-pre-prod':
				envVars['APIE_REGION'] = "US"
				envVars['APIE_PLATFORM'] = "MTF"
				envVars['APIE_ZONE'] = "STL"
				break
			case 'ksc-pre-prod':
				envVars['APIE_REGION'] = "US"
				envVars['APIE_PLATFORM'] = "MTF"
				envVars['APIE_ZONE'] = "STL"
				break
			case 'bel-prod':
				envVars['APIE_REGION'] = "EU"
				envVars['APIE_PLATFORM'] = "PROD"
				envVars['APIE_ZONE'] = "BEL"
				break
			case 'stl-prod':
				envVars['APIE_REGION'] = "US"
				envVars['APIE_PLATFORM'] = "PROD"
				envVars['APIE_ZONE'] = "STL"
				break
			case 'ksc-prod':
				envVars['APIE_REGION'] = "US"
				envVars['APIE_PLATFORM'] = "PROD"
				envVars['APIE_ZONE'] = "KSC"
				break
		}

		if (vaultEnabled) {

			def envConfigString = steps.libraryResource 'org/mastercard/pipeline/alberta/environmentconfignew.yml'
			def envConfigData = steps.readYaml text: envConfigString

			vaultCredentialsId = envConfigData."${steps.env.PCF_DEV_SPACE}".pcf.vaultid
			steps.echo "${vaultCredentialsId}"
			vaultBackendId = 'srcsystem-alberta'
			vaultAppName = "${steps.env.PCF_DEV_SPACE}/${steps.env.APP_NAME}"
			steps.echo "this is the vaultappname: ${vaultAppName}"

			steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${vaultCredentialsId}", usernameVariable: 'VAULT_ID', passwordVariable: 'VAULT_SECRET']]) {
				envVars['SPRING_CLOUD_VAULT_APP-ROLE_AUTH-PATH'] = "approle"
				envVars['SPRING_CLOUD_VAULT_APP-ROLE_ROLE-ID'] = "${steps.VAULT_ID}"
				envVars['SPRING_CLOUD_VAULT_APP-ROLE_SECRET-ID'] = "${steps.VAULT_SECRET}"

				envVars['SPRING_CLOUD_VAULT_AUTHENTICATION'] = "APPROLE"
				envVars['SPRING_CLOUD_VAULT_GENERIC_BACKEND'] = "${vaultBackendId}"

				envVars['SPRING_CLOUD_VAULT_HOST'] = "${env.replace('-', '.')}.vault.mastercard.int"
				envVars['SPRING_CLOUD_VAULT_PORT'] = "8200"
				envVars['SPRING_CLOUD_VAULT_SCHEME'] = "https"
				envVars['SPRING_CLOUD_VAULT_ENABLED'] = "true"
				envVars['SPRING_CLOUD_VAULT_APPL_NAME'] = "${vaultAppName}"
			}
		}

		return envVars
	}
}
