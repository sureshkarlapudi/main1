/**
 * org.mastercard.pipeline.utility is a collection of utilities to perform common pipeline tasks.
 */
package org.mastercard.pipeline.utility

import com.thoughtworks.xstream.converters.basic.StringBufferConverter

/**
 * Utility to which reads a autoscale.yml file and scale the application according to rule specified in YML file.
 * This utility uses App Autoscaling APIs to scale the app.
 *
 */

class AutoscaleUtil implements Serializable {

    /**
     * a reference to the pipeline that allows you to run pipeline steps in your shared library.
     */
    def steps

    final String HTTP_LATENCY_RULE_TYPE = "http_latency"
    final String HTTP_THROUGHPUT_RULE_TYPE = "http_throughput"
    final String CPU_UTILIZATION_RULE_TYPE = "cpu"
	
	final String ENV_STL_DEV = "stl-dev"
	final String ENV_STL_STAGE = "stl-stage"
	final String ENV_BEL_PROD = "bel-prod"
	final String ENV_STL_PROD = "stl-prod"
    final String ENV_KSC_PROD = "ksc-prod"
	
    /**
     * Constructor
     *
     * @param steps A reference to the steps in a pipeline to give access to them in the shared library.
     */
    public AutoscaleUtil(steps) {this.steps = steps}

    /**
     * This method will will autos-scale the application based on rules specified in autoscale.yml.
     *
     *
     * @param steps A reference to the steps in a pipeline to give access to them in the shared library.
     * @param org what PCF org we want to deploy to
     * @param space what PCF space we want to deploy to
     * @param pcfCredId the name of the credentialsId you want to use to deploy to PCF (configured in Jenkins)
     * @param env what we are deploying to. values can be 'stl-dev', 'stl-stage', or 'bel-prod'
     */

    public void autoscaleApplication(String org, String space, String pcfCredId, String environment, boolean isBlueGreenDeployment) {

        steps.echo "Application Autoscale Process Starting"

        def paasUrl
        def appSystemDomain

        switch(environment) {
            case ENV_STL_DEV: appSystemDomain = steps.globalVars.DEV_SYSTEM_STL_DOMAIN; paasUrl = steps.globalVars.DEV_PAAS_URL; break;
            case ENV_STL_STAGE: appSystemDomain = steps.globalVars.STAGE_SYSTEM_STL_DOMAIN; paasUrl = steps.globalVars.STAGE_PAAS_URL; break;
            case ENV_BEL_PROD: appSystemDomain = steps.globalVars.PROD_SYSTEM_BEL_DOMAIN; paasUrl = steps.globalVars.BEL_PROD_PAAS_URL;  break;
            case ENV_STL_PROD: appSystemDomain = steps.globalVars.PROD_SYSTEM_STL_DOMAIN; paasUrl = steps.globalVars.STL_PROD_PAAS_URL; break;
            case ENV_KSC_PROD: appSystemDomain = steps.globalVars.PROD_SYSTEM_KSC_DOMAIN; paasUrl = steps.globalVars.KSC_PROD_PAAS_URL; break;
        }
        steps.withEnv(["CF_HOME=."]) {

        // Get application name
        steps.echo "Getting Application Name from manifest.yml"
        def applicationName = getApplicationName(isBlueGreenDeployment)

        // Read rules from autoscale.yml file
        steps.echo "Getting Auto-Scalling Rules from autoscale.yml"
        def autoscaleRules = getAutoscaleRules();

        steps.echo "Getting HTTP Latency Rule"
        def httpLatency = getHttpLatency(autoscaleRules)

        steps.echo "Getting CPU Utilization Rule"
        def cpuUtilization = getCpuUtilization(autoscaleRules)

        steps.echo "Getting HTTP Throughput Rule"
        def httpThroughput = getHttpThroughput(autoscaleRules)

        steps.withCredentials([[$class: "UsernamePasswordMultiBinding", credentialsId: "${pcfCredId}", usernameVariable: "PCF_USERNAME", passwordVariable: "PCF_PASSWORD"]]) {
            steps.sh "cf login -a ${paasUrl} -u ${steps.PCF_USERNAME} -p ${steps.PCF_PASSWORD} -o ${org} -s ${space}"
        }
        steps.echo "Login Successful"

        def oauthToken = getOauthToken()

        steps.echo "Getting Application GUID"
        def appGUID = getAppGUID(applicationName)

        steps.echo "Getting Service GUID"
        def serviceGUID = getServiceGUID(autoscaleRules.service_name)

        def responseCode
        steps.echo "Getting Service Binding GUID"

        responseCode = steps.sh (script: "curl -o /dev/null -s -w \"%{http_code}\\n\" -X POST \\\n" +
                "  https://${appSystemDomain}/proxy/api/v2/service_bindings \\\n" +
                "  -H 'Authorization: ${oauthToken}' \\\n" +
                "  -H 'Content-Type: application/json' \\\n" +
                "  -d '{\"app_guid\":\"${appGUID}\",\"service_instance_guid\":\"${serviceGUID}\",\"parameters\":{}}'", returnStdout: true).trim()

        checkStatusCode(responseCode)

        def serviceBindingGUID = getServiceBindingGUID(appGUID, serviceGUID);

        steps.echo "Removing All Existing Rules..."
        responseCode = steps.sh (script: "curl -o /dev/null -s -w \"%{http_code}\\n\" -X PUT \\\n" +
                "  https://${appSystemDomain}/proxy/autoscale/api/bindings/${serviceBindingGUID} \\\n" +
                "  -H 'authorization: ${oauthToken}' \\\n" +
                "  -d '{\"min_instances\":12,\"max_instances\":20,\"enabled\":true,\"relationships\":{\"rules\":[]}}'", returnStdout: true).trim()
        steps.echo "Existing rules removed"
        checkStatusCode(responseCode)

        steps.echo "Applying New Rules"
        responseCode = steps.sh (script: "curl -o /dev/null -s -w \"%{http_code}\\n\" -X PUT \\\n" +
                "  https://${appSystemDomain}/proxy/autoscale/api/bindings/${serviceBindingGUID} \\\n" +
                "  -H 'authorization: ${oauthToken}' \\\n" +
                "  -d '{\"min_instances\":${autoscaleRules.instance_limits.min},\"max_instances\":${autoscaleRules.instance_limits.max},\"enabled\":true,\"relationships\":{\"rules\":[{\"enabled\":true,\"max_threshold\":${httpLatency.threshold.max},\"min_threshold\":${httpLatency.threshold.min},\"type\":\"${httpLatency.rule_type}\",\"sub_type\":\"${httpLatency.rule_sub_type}\"},{\"enabled\":true,\"max_threshold\":${cpuUtilization.threshold.max},\"min_threshold\":${cpuUtilization.threshold.min},\"type\":\"${cpuUtilization.rule_type}\",\"sub_type\":\"\"},{\"enabled\":true,\"max_threshold\":${httpThroughput.threshold.max},\"min_threshold\":${httpThroughput.threshold.min},\"type\":\"${httpThroughput.rule_type}\",\"sub_type\":\"\"}]}}'",
                returnStdout: true).trim()
        checkStatusCode(responseCode)

        steps.echo "Autoscale API Response JSON: - ${responseCode}"
        steps.echo "AutoscaleApplication Stage Completed"

        }
    }

    private String getOauthToken(){

        def oauthToken = steps.sh(script: "cf oauth-token", returnStdout: true).trim()
        steps.echo "Oauth Token: ${oauthToken}"
        return oauthToken
    }

    private String getAppGUID(String applicationName){

        def appGUID = steps.sh(script: "cf app ${applicationName} --guid", returnStdout: true).trim()
        steps.echo "App GUID: ${appGUID}"
        return appGUID;
    }

    private String getServiceGUID(String serviceName){
        
        def serviceGUID = steps.sh(script: "cf service ${serviceName} --guid", returnStdout: true).trim()
        steps.echo "Auto-Scaler Service GUID: ${serviceGUID}"
        return serviceGUID;
    }

    private String getServiceBindingGUID(String appGUID, String serviceGUID) {

        //TODO: Refactor variable name, it should be camel case.
        def PCF_SERVICE_BINDINGS_GUID = steps.sh(script: "cf curl /v2/apps/${appGUID}/service_bindings", returnStdout: true).trim()
        steps.echo "${PCF_SERVICE_BINDINGS_GUID}"
        def PCF_GIT_SERVER_APP_SUMMARY_JSON = steps.readJSON text: PCF_SERVICE_BINDINGS_GUID
        steps.echo "Service Binding Response JSON: - ${PCF_GIT_SERVER_APP_SUMMARY_JSON}"
        def SERVICE_BINDING_GUID = null
        for(Object item: PCF_GIT_SERVER_APP_SUMMARY_JSON.resources) {
            if (item.entity.service_instance_guid.trim() == serviceGUID) {
                SERVICE_BINDING_GUID = item.metadata.guid
            }
        }

        steps.echo "Service Binding GUID: - ${SERVICE_BINDING_GUID}"

        return SERVICE_BINDING_GUID;
    }

    private Object getAutoscaleRules() {
        // Read rules from autoscale.yml file
        def autoscaleRules = steps.readYaml file: "autoscale.yml"
        //TODO: Validate rules from autoscale YML
        return autoscaleRules;
    }

    private Object getHttpLatency(Object autoscaleRules) {

        def rules = autoscaleRules.rules
        def filteredRules = rules.findAll { it.rule_type == HTTP_LATENCY_RULE_TYPE }
        return filteredRules[0]
    }

    private Object getCpuUtilization(Object autoscaleRules) {

        def rules = autoscaleRules.rules
        def filteredRules = rules.findAll { it.rule_type == CPU_UTILIZATION_RULE_TYPE }
        return filteredRules[0]
    }

    private Object getHttpThroughput(Object autoscaleRules) {

        def rules = autoscaleRules.rules
        def filteredRules = rules.findAll { it.rule_type == HTTP_THROUGHPUT_RULE_TYPE }
        return filteredRules[0]
    }

    private String getApplicationName(boolean isBlueGreenDeployment){

        def manifestData = steps.readYaml file: "manifest.yml"

        if (manifestData.applications) {
            if (isBlueGreenDeployment) {
                return "${manifestData.applications[0].name}'-blue'"
            } else {
                return manifestData.applications[0].name
            }

        } else {
            steps.error "Either manifest.yml file not found or Application name not found in manifest.yml"
        }
    }
    
	private void checkStatusCode(String code){
        if(null == code){
            commonUtil.echoSteps("WARNING: Null response code found. Replacing with zero.")
            code = 0
        }

		steps.echo "Response code : ${code}"
		int httpStatusInt = code.toInteger()
		steps.echo "Response code int : ${httpStatusInt}"
		
		if(!(httpStatusInt >= 200 && httpStatusInt < 300)){
			steps.error "Got HTTP response code ${code}"
		}	
	}
}
