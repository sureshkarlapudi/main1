/**
 * org.mastercard.pipeline.utility is a collection of utilities to perform common pipeline tasks.
 */
package org.mastercard.pipeline.utility

/**
 * Utility that performs various maven tasks as well as other tasks tied to it such as git.
 * peforms tasks such as build, interact with sonar, run integration tests, git pull, etc.
 *
 * @Author grant.gortsema@mastercard.com
 */
class MavenUtil implements Serializable {

  /**
  * a reference to the pipeline that allows you to run pipeline steps in your shared libary
  */
  def steps


  /**
  * Constructor
  *
  * @param steps A reference to the steps in a pipeline to give access to them in the shared library.
  */
  public MavenUtil(steps) {this.steps = steps}


  /**
  * Uses maven to deploy your code to artifactory. It assumes you have the correct parent pom set up in your project and
  * that you are in the directory with the pom. You also need to have deployer credentials set up in jenkins as they are required to deploy to artifactory.
  *
  * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
  * @param deployerCredentails string that represents the id of the jenkins credentials used for your artifactory deployer
  */
  public void mvnDeployToArtifactory(script, String deployerCredentails) {

    steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${deployerCredentails}", usernameVariable: 'UNAME', passwordVariable: 'PASS']]) {
      steps.sh """
      export ARTIFACTORY_USR=${script.UNAME}
      export ARTIFACTORY_PSW=${script.PASS}
      ${steps.tool 'M3'}/bin/mvn -X clean deploy
      """
    }
  }

  /**
  * Pulls shared ansible files from git repo and stashes them under ansible-workspace
  *
  * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
  * @param branch the branch for the git repo. if this param is ommited it will use default branch
  *
  */
  public void gitPullSharedAnsibleFiles(script, String branch = null) {

    if(branch) steps.git branch: "${branch}", url: "https://globalrepository.mclocal.int/stash/scm/ca/shared-pct-ansible-libraries.git"
    else steps.git url: "https://globalrepository.mclocal.int/stash/scm/ca/shared-pct-ansible-libraries.git"

    steps.stash includes: '**', name: 'ansible-workspace'
  }

  /**
  * Pulls code from a git repo
  *
  * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
  * @param repo is the URL to pull the git code from
  * @param branch the branch for the git repo. if this param is ommited it will use default branch
  *
  */
  public void gitPull(script, String repo, String branch = null) {
    steps.git branch: "${branch}", url: "${repo}"
  }

  /**
  * Runs static analysis on a project
  *
  * @todo arrive a code parity in parent poms and how sonar is run across projects. The pipeline code should be able to highlight the differences.
  *
  * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
  * @param branch the git branch we are running sonar tests on. If this is null it will override the main sonar page for this project.
  * @param pomLoc The location of the pom file relative to the workspace. Optional parameter. Will use pom current directory if it is left off.
  */
  public void runSonar(script, String branch,String pomLoc = null) {

    def pomFlag = ' '
    if(pomLoc) pomFlag = " -f ${pomLoc} "
    else pomLoc = 'pom.xml'

    def pom = steps.readMavenPom file: pomLoc
    def parentPart = pom.groupId ?: pom.parent.groupId
    def reportLocation = "https://fusion.mastercard.int/sonar/overview?id=${parentPart}%3A${pom.artifactId}"

    def branchParam = ' '
    if(branch) {
      branchParam = " -Dsonar.branch=${branch} "
      reportLocation += "%3A" + branch.replace('/','%2F')
    }

    steps.sh "${steps.tool 'M3'}/bin/mvn${pomFlag}-Dsonar.exclusions=**/domain/**,**/constants/**,**/config/**,**/repository/**,**/types/**,**/mock/**,**/model/**,**/initdata/** -Djavax.net.ssl.trustStore=${script.globalVars.sonarTestTrustStore}${branchParam}-Dsonar.findbugs.timeout=1200000 -Dsonar.jacoco.reportMissing.force.zero=true -Dsonar.scm.disabled=true sonar:sonar"
    steps.echo "changed - URL for sonar project is at: ${reportLocation}"

  }

  /**
  * Build a project using maven.
  * executes clean and package. Currently this also installs npm and karma until it can be backed into the agent.
  *
  * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
  * @param pom A string that gives the path of the pom file relative to the directory.
  * @param mvnArgs is an optional parameter that indicate any maven arguments you want to pass to the method. These will be appended to the end of the mvn clean package command
  *
  */
  public void mvnPackage(script, String pom, String mvnArgs = null) {
    def mvnHome = steps.tool 'M3'
    def node_path = script.env.NODE6

    steps.echo "NODE PATH: ${node_path}"

    script.env.JAVA_HOME="${steps.tool 'JDK 1.8'}"

    if(!mvnArgs) mvnArgs = ''

    def buildString = "${mvnHome}/bin/mvn clean package -f ${pom} ${mvnArgs}".trim()

    steps.sh "curl -s -o phantomjs-2.1.1.zip ${script.env.ALBERTA_ARTIFACTORY_URL}/maven-external-release/phantomjs/phantomjs/2.1.1/phantomjs-2.1.1.zip"
    steps.sh "unzip -o phantomjs-2.1.1.zip"
    steps.sh "mkdir -p bin"
    steps.sh "mv phantomjs-static bin/phantomjs"
    steps.withEnv(["PATH+PHANTOMJS=${script.env.WORKSPACE}/bin"]) {
      steps.withEnv(["PATH+NODEJS=${node_path}/bin"]) {
        steps.withCredentials([steps.usernameColonPassword(
          credentialsId: 'artifactory_deployer', variable: 'afact_repo_creds')]) {
            steps.sh """curl '-u${script.afact_repo_creds}' \
              '${steps.env.ALBERTA_ARTIFACTORY_URL}/api/npm/auth' > .npmrc"""
          }
          steps.sh 'pwd'
          steps.sh 'npm install karma --save-dev'
          steps.sh 'npm install karma-jasmine --save-dev'
          steps.sh 'npm install karma-chrome-launcher --save-dev'
          steps.sh 'npm install jasmine-core --save-dev'
          steps.sh 'npm install karma-cli'
          steps.sh 'npm install karma-coverage --save-dev'
          steps.sh 'npm install karma-junit-reporter --save-dev'
          steps.sh 'npm install karma-phantomjs-launcher --save-dev'

          steps.echo "BUILD STRING: ${buildString}"
          steps.sh buildString
        }
      }
  }

  /**
  * Build a project using maven.
  * executes clean and package. This method does not install karma and will be depreicated once there is no distinction in the shared code. This will happen when npm and karma are baked into the agent.
  *
  * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
  * @param pom A string that gives the path of the pom file relative to the directory.
  * @param mvnArgs is an optional parameter that indicate any maven arguments you want to pass to the method. These will be appended to the end of the mvn clean package command
  *
  */
  public void mvnPackageNoKarma(script, String pom, String mvnArgs = null) {
    def mvnHome = steps.tool 'M3'
    def node_path = script.env.NODE6

    steps.echo "NODE PATH: ${node_path}"

    script.env.JAVA_HOME="${steps.tool 'JDK 1.8'}"

    if(!mvnArgs) mvnArgs = ''

    def buildString = "${mvnHome}/bin/mvn clean package -f ${pom} ${mvnArgs}".trim()
      steps.echo "BUILD STRING: ${buildString}"
      steps.sh buildString
  }

}
