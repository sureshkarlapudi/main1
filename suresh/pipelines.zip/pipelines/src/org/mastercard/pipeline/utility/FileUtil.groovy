/**
 * org.mastercard.pipeline.utility is a collection of utilities to perform common pipeline tasks.
 */
package org.mastercard.pipeline.utility

/**
 * Utility which reads various YML files and validate the file inputs.
 *
 * @Author semal.gajera@mastercard.com
 */

class FileUtil implements Serializable {

    /**
     * a reference to the pipeline that allows you to run pipeline steps in your shared library
     */
    def steps

    /**
     * Constructor
     *
     * @param steps A reference to the steps in a pipeline to give access to them in the shared library.
     */
    public FileUtil(steps) {this.steps = steps}

    public Object readManifest() {
        // TODO: Implement this and refactor all other code to use this function.Read from manifest.yml
    }

    private boolean validateManifest(Object manifestData) {
        // TODO: Validate inputs from manifest.yml
        return true;
    }

    public Object readPipelineConfig() {
        // Read from pipelineconfig.yml
        def pipelineConfigData = steps.readYaml file: "pipelineconfig.yml"
        if (!validatePipelineConfig(pipelineConfigData)) {
            steps.error "Either pipelineConfig.yml file not found or invalid parameters inside pipelineConfig.yml"
        }

        return pipelineConfigData

    }
    /**
     * This method will return the file object which consists of all the environments and its start and end stages
     * @return
     */
    public Object readEnvironmentsConfig() {
        def envConfigString = steps.libraryResource 'org/mastercard/pipeline/alberta/environmentconfig.yml'
        def envConfigData = steps.readYaml text: envConfigString
      	
        return envConfigData
    }

    private boolean validatePipelineConfig(Object pipelineConfigData) {
        // TODO: Validate inputs from pipelineconfig.yml
        return true;
    }

    public Object readAutoscaleConfig() {
        // TODO: Implement this and refactor AutoscaleUtil other code to use this function

        // Read from autoscale.yml
    }

    private boolean validateAutoscaleConfig(Object autoscaleData) {
        // TODO: Validate inputs from autoscale.yml
        return true;
    }
}
