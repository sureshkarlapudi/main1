/**
 * org.mastercard.pipeline.utility is a collection of utilities to perform common pipeline tasks.
 */
package org.mastercard.pipeline.utility

/**
 * Utility to interact with the PCF platform. Used to deploy artifacts and manage services.
 *
 * @Author grant.gortsema@mastercard.com
 */
class PCFUtil implements Serializable {

    /**
     * a reference to the pipeline that allows you to run pipeline steps in your shared libary
     */
    def steps

    def commonUtil
    /**
     * Constructor
     *
     * @param steps A reference to the steps in a pipeline to give access to them in the shared library.
     */
    public PCFUtil(steps) {
      this.steps = steps
      this.commonUtil = new org.mastercard.alberta.CommonUtil(steps)
    }

    /**
     * use the CLI to do a CF push on an artifact and deploy it to a PCF env. This method assumes you have populated the keyMap
     * with values from the  getJKSFromCaaS method if you are setting synapseEnabled to true. This method will use the keymap to set different variables.
     * The aliases for these certs are client-common, and client-access. Other than the env variables that are being set in this
     * method, if you want to add any other pcf env varibles or override ones that you know are being set in here, you can prepare-agent
     * populate the keyMap with the values you want to take precedence and just prepend them with PCFENV_ . An example would
     * be to override the value that is being set for API_REGION = dev we would preopulate the keyMap with the values
     * keyMap['PCFENV_API_REGION'] = 'something else'. This will cause the varible API_REGION to be set, or if it is already
     * being set by the method it will override the value and use the value you have chosen.
     *
     * @param script reference to pipeline script used to access global variables. Usually passed in as 'this' from the pipeline
     * @param appHostName Name of the app, should be same as in manifest.
     * @param env what we are deploying to. values can be 'stl-dev', 'stl-stage', or 'bel-prod'
     * @param org what PCF org we want to deploy to
     * @param space what PCF space we want to deploy to
     * @param pcfCredentialsId the name of the credentialsId you want to use to deploy to PCF (configured in Jenkins)
     * @param vaultCredentialsId the name of the credentialsId you want to use for vault. If you are setting vaultEnabled to false then make this null. it will be ignored in any case.
     * @param vaultBackendId the name The string you have configured with vault for your generic backend id. If you have vaultEnabled to false this will be ignored.
     * @param keyMap A Map containing the encrypted cert information as wel as any special env variables your app would need. PCF env variables should be in the map in the form of PCFENV_<keyname> , <value>. env variables will be removed after they are set
     * @param synapseEnabled determins if we are setting synapse properties.
     * @param vaultEnabled determins if we are setting spring cloud vault variables
     * @param activeProfile sets springs active profile env variable. if you do not want to set one just give null value and it will not be set.
     * @param dirToPush optional relative directory to cf push from. defaults to current workspace directory.
     * @param manifestLoc an optional string to be passed to the -f option of pcf push
     */
    public void deployToPCFGoRouter(script, String appHostName, String env, String org, String space, String pcfCredentialsId, String vaultCredentialsId, String vaultBackendId, Map keyMap, boolean synapseEnabled, boolean vaultEnabled, String activeProfile = null, String hostName = null, boolean customEnvVars = false, String dirToPush = '.', String manifestLoc = null) {

        def appDomain = ''
        def paas_url = ''

        // temp vars for tracing logs
        def pushed = false
        boolean deployPcfPass = true

        switch (env) {
            case 'stl-dev': appDomain = script.globalVars.devDomain; paas_url = script.globalVars.DEV_PAAS_URL; break;
            case 'stl-stage': appDomain = script.globalVars.stageDomain; paas_url = script.globalVars.STAGE_PAAS_URL; break;
            case 'bel-prod': appDomain = script.globalVars.prodDomain; paas_url = script.globalVars.BEL_PROD_PAAS_URL; break;
            case 'stl-prod': appDomain = script.globalVars.stl_prodDomain; paas_url = script.globalVars.STL_PROD_PAAS_URL; break;
            case 'ksc-prod': appDomain = script.globalVars.stl_prodDomain; paas_url = script.globalVars.KSC_PROD_PAAS_URL; break;
        }

        def appRoute = "https://${appHostName}.${appDomain}"

        steps.dir(dirToPush) {

            steps.withEnv(["CF_HOME=."]) {

                try {

                    steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${pcfCredentialsId}", usernameVariable: 'PCF_USERNAME', passwordVariable: 'PCF_PASSWORD']]) {
                        steps.sh "cf login -a ${paas_url} -u ${script.PCF_USERNAME} -p ${script.PCF_PASSWORD} -o ${org} -s ${space}"
                    }

                    try {
                        steps.env.currentArtifactURL = steps.sh(script: "cf env ${appHostName} | grep ArtifactURL | awk '{print \$2}'", returnStdout: true).trim()
                    }catch (Exception ex){
                        steps.echo "There is No Artifact URL in the Env Vars"
                    }

                    def pushString = ''
                    if (manifestLoc) pushString = " -f ${manifestLoc}"
                    pushed = true
                    //push application but don't start it so we can set env variables
                    if (hostName){
                        steps.sh "cf push ${appHostName} -n ${hostName} --no-start"
                    }else{
                        steps.sh "cf push ${appHostName} ${pushString} --no-start"
                    }

                    if (activeProfile) {
                        steps.sh "cf set-env ${appHostName} SPRING_PROFILES_ACTIVE ${activeProfile}"
                    }
                    //TODO : Why only when synapse is enabled?
                    if (vaultEnabled) {
                        steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${vaultCredentialsId}", usernameVariable: 'VAULT_ID', passwordVariable: 'VAULT_SECRET']]) {
                            steps.sh "cf set-env ${appHostName} SPRING_CLOUD_VAULT_APP-ROLE_AUTH-PATH approle"
                            steps.sh "cf set-env ${appHostName} SPRING_CLOUD_VAULT_APP-ROLE_ROLE-ID ${script.VAULT_ID}"
                            steps.sh "cf set-env ${appHostName} SPRING_CLOUD_VAULT_APP-ROLE_SECRET-ID ${script.VAULT_SECRET}"
                            steps.sh "cf set-env ${appHostName} SPRING_CLOUD_VAULT_AUTHENTICATION APPROLE"
                            steps.sh "cf set-env ${appHostName} SPRING_CLOUD_VAULT_GENERIC_BACKEND ${vaultBackendId}"
                            steps.sh "cf set-env ${appHostName} SPRING_CLOUD_VAULT_HOST ${env.replace('-', '.')}.vault.mastercard.int"
                            steps.sh "cf set-env ${appHostName} SPRING_CLOUD_VAULT_PORT 8200"
                            steps.sh "cf set-env ${appHostName} SPRING_CLOUD_VAULT_SCHEME https"
                            steps.sh "cf set-env ${appHostName} SPRING_CLOUD_VAULT_ENABLED true"
                        }
                    }

                    if (synapseEnabled) {
                        def encodedClientKeyFile = keyMap["encodedKeyfile"]
                        def encodedClientKeyFilePassword = keyMap["encodedKeyfilePassword"]
                        def encodedTrustoreFile = keyMap["encodedTruststore"]
                        def encodedTrustoreFilePassword = keyMap["encodedTruststorePassword"]

                        steps.sh "cf set-env ${appHostName} KEYSTORE ${encodedClientKeyFile}"
                        steps.sh "cf set-env ${appHostName} TRUSTSTORE ${encodedTrustoreFile}"
                        steps.sh "cf set-env ${appHostName} KEYSTORE_PASSWORD ${encodedClientKeyFilePassword}"
                        steps.sh "cf set-env ${appHostName} TRUSTSTORE_PASSWORD ${encodedTrustoreFilePassword}"
                        steps.sh "cf set-env ${appHostName} SYNAPSE_SSL_KEYSTORE_LOCATION KEYSTORE"
                        steps.sh "cf set-env ${appHostName} SYNAPSE_SSL_TRUSTSTORE_LOCATION TRUSTSTORE"
                        steps.sh "cf set-env ${appHostName} SYNAPSE_SSL_KEYSTORE_CLIENT_ALIAS client-common"
                        steps.sh "cf set-env ${appHostName} SYNAPSE_SSL_KEYSTORE_TYPE JKS"

                        switch (env) {
                            case 'stl-dev':
                                steps.sh "cf set-env ${appHostName} APIE_REGION US"
                                steps.sh "cf set-env ${appHostName} APIE_PLATFORM DEV"
                                steps.sh "cf set-env ${appHostName} APIE_ZONE STL"
                                break;
                            case 'stl-stage':
                                steps.sh "cf set-env ${appHostName} APIE_REGION US"
                                steps.sh "cf set-env ${appHostName} APIE_PLATFORM STAGE"
                                steps.sh "cf set-env ${appHostName} APIE_ZONE STL"
                                break;
                            case 'stl-pre-prod':
                                steps.sh "cf set-env ${appHostName} APIE_REGION US"
                                steps.sh "cf set-env ${appHostName} APIE_PLATFORM MTF"
                                steps.sh "cf set-env ${appHostName} APIE_ZONE STL"
                                break;
                            case 'bel-pre-prod':
                                steps.sh "cf set-env ${appHostName} APIE_REGION US"
                                steps.sh "cf set-env ${appHostName} APIE_PLATFORM MTF"
                                steps.sh "cf set-env ${appHostName} APIE_ZONE STL"
                                break;
                            case 'ksc-pre-prod':
                                steps.sh "cf set-env ${appHostName} APIE_REGION US"
                                steps.sh "cf set-env ${appHostName} APIE_PLATFORM MTF"
                                steps.sh "cf set-env ${appHostName} APIE_ZONE STL"
                                break;
                            case 'bel-prod':
                                steps.sh "cf set-env ${appHostName} APIE_REGION EU"
                                steps.sh "cf set-env ${appHostName} APIE_PLATFORM PROD"
                                steps.sh "cf set-env ${appHostName} APIE_ZONE BEL"
                                break;
                            case 'stl-prod':
                                steps.sh "cf set-env ${appHostName} APIE_REGION US"
                                steps.sh "cf set-env ${appHostName} APIE_PLATFORM PROD"
                                steps.sh "cf set-env ${appHostName} APIE_ZONE STL"
                                break;
                        }
                    }
                    //steps.echo "Key Map : ${keyMap}"
                    //set custom variables including any overrides
                    if(customEnvVars){
                        steps.echo "Setting Custom Env Vars"
                        setPCFEnvVarsFromMap(script, appHostName, keyMap)
                    }
                    steps.sh "cf start ${appHostName}"
                    //restarge and start the application
                    steps.sh "cf restage ${appHostName}"
                    steps.sh "cf start ${appHostName}"

                } catch (Exception ex) {
                    steps.echo "${ex}"
                    deployPcfPass = false
                    if (pushed) {
                        steps.sh "cf logs ${appHostName} --recent"
                    }
                } finally {
                    steps.sh "cf logout"
                    steps.deleteDir()

                }
                if (!deployPcfPass){
                    steps.echo "JOB STOPPED due to PCF Push."
                    steps.sh "exit 1"
                }
            }
        }
    }

    public void deleteOldBackApp(script) {
        def appDomain
        def paas_url
        switch (steps.env.PCF_FOUNDATION) {
            case 'stl-dev': appDomain = steps.globalVars.devDomain; paas_url = steps.globalVars.DEV_PAAS_URL; break;
            case 'stl-stage': appDomain = steps.globalVars.stageDomain; paas_url = steps.globalVars.STAGE_PAAS_URL; break;
            case 'bel-prod': appDomain = steps.globalVars.prodDomain; paas_url = steps.globalVars.BEL_PROD_PAAS_URL; break;
            case 'stl-prod': appDomain = steps.globalVars.stl_prodDomain; paas_url = steps.globalVars.STL_PROD_PAAS_URL; break;
            case 'ksc-prod': appDomain = steps.globalVars.stl_prodDomain; paas_url = steps.globalVars.KSC_PROD_PAAS_URL; break;
        }
        steps.node("${script.env.CF_CLI_LABEL}") {
            try{
            steps.withEnv(["CF_HOME=."]) {
                steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${steps.env.PCF_CREDENTIALS}", usernameVariable: 'PCF_USERNAME', passwordVariable: 'PCF_PASSWORD']]) {
                    steps.sh "cf login -a ${paas_url} -u ${steps.PCF_USERNAME} -p ${steps.PCF_PASSWORD} -o ${steps.env.PCF_ORG} -s ${steps.env.PCF_DEV_SPACE}"
                    steps.sh "cf delete ${steps.env.currentBlueAppName}'-back-old' -f"
                }
            }
          }
            catch (Exception e){
                steps.echo("There is no blue back old app")
            }
        }
    }

    public void restoreOldBackApp(script) {
        def appDomain
        def paas_url
        switch (steps.env.PCF_FOUNDATION) {
            case 'stl-dev': appDomain = steps.globalVars.devDomain; paas_url = steps.globalVars.DEV_PAAS_URL; break;
            case 'stl-stage': appDomain = steps.globalVars.stageDomain; paas_url = steps.globalVars.STAGE_PAAS_URL; break;
            case 'bel-prod': appDomain = steps.globalVars.prodDomain; paas_url = steps.globalVars.BEL_PROD_PAAS_URL; break;
            case 'stl-prod': appDomain = steps.globalVars.stl_prodDomain; paas_url = steps.globalVars.STL_PROD_PAAS_URL; break;
            case 'ksc-prod': appDomain = steps.globalVars.stl_prodDomain; paas_url = steps.globalVars.KSC_PROD_PAAS_URL; break;
        }
        steps.node("${script.env.CF_CLI_LABEL}") {
            steps.withEnv(["CF_HOME=."]) {
                steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${steps.env.PCF_CREDENTIALS}", usernameVariable: 'PCF_USERNAME', passwordVariable: 'PCF_PASSWORD']]) {
                    steps.sh "cf login -a ${paas_url} -u ${steps.PCF_USERNAME} -p ${steps.PCF_PASSWORD} -o ${steps.env.PCF_ORG} -s ${steps.env.PCF_DEV_SPACE}"
                    def blueBackAppExists = steps.sh(script: "cf app ${steps.env.currentBlueAppName}'-back'", returnStatus: true) == 0
                    if(blueBackAppExists){
                        steps.sh "cf delete ${steps.env.currentBlueAppName}'-back' -f"
                    }
                    def blueBackOldAppExists = steps.sh(script: "cf app ${steps.env.currentBlueAppName}'-back-old'", returnStatus: true) == 0
                    if(blueBackOldAppExists){
                        steps.sh "cf rename ${steps.env.currentBlueAppName}'-back-old' ${steps.env.currentBlueAppName}'-back'"
                    }
                }
            }
        }
    }

    public void setArtifactURL(script, String appHostname=null, String localArtifactURL=null) {
        def appDomain
        def paas_url
        def blueAppExists
        steps.echo("Setting Up ArtifactURL to the Deployed PCF Application")

        switch (steps.env.PCF_FOUNDATION) {
            case 'stl-dev': appDomain = steps.globalVars.devDomain; paas_url = steps.globalVars.DEV_PAAS_URL; break;
            case 'stl-stage': appDomain = steps.globalVars.stageDomain; paas_url = steps.globalVars.STAGE_PAAS_URL; break;
            case 'bel-prod': appDomain = steps.globalVars.prodDomain; paas_url = steps.globalVars.BEL_PROD_PAAS_URL; break;
            case 'stl-prod': appDomain = steps.globalVars.stl_prodDomain; paas_url = steps.globalVars.STL_PROD_PAAS_URL; break;
            case 'ksc-prod': appDomain = steps.globalVars.stl_prodDomain; paas_url = steps.globalVars.KSC_PROD_PAAS_URL; break;
        }

        steps.node("${script.env.CF_CLI_LABEL}") {
            steps.withEnv(["CF_HOME=."]) {
                steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${steps.env.PCF_CREDENTIALS}", usernameVariable: 'PCF_USERNAME', passwordVariable: 'PCF_PASSWORD']]) {
                    steps.sh "cf login -a ${paas_url} -u ${steps.PCF_USERNAME} -p ${steps.PCF_PASSWORD} -o ${steps.env.PCF_ORG} -s ${steps.env.PCF_DEV_SPACE}"

                    if ( appHostname ) {
                        blueAppExists = steps.sh(script: "cf app ${appHostname}", returnStatus: true) == 0

                        if( blueAppExists ) {
                            if ( localArtifactURL ) {
                                steps.sh "cf set-env ${appHostname} ArtifactURL ${localArtifactURL}"
                            }
                            else {
                                steps.sh "cf set-env ${appHostname} ArtifactURL ${steps.env.artifactURL}"
                            }
                        }
                    }
                    else {
                        blueAppExists = steps.sh(script: "cf app ${steps.env.currentBlueAppName}", returnStatus: true) == 0

                        if( blueAppExists ) {
                            if ( localArtifactURL ) {
                                steps.sh "cf set-env ${steps.env.currentBlueAppName} ArtifactURL ${localArtifactURL}"
                            }
                            else {
                                steps.sh "cf set-env ${steps.env.currentBlueAppName} ArtifactURL ${steps.env.artifactURL}"
                            }
                        }
                    }
                }
            }
        }
    }

    public void appRollBack(script, Map envVarMap = null, boolean artifactUpload ){

        if ( ! script.env.FRONTEND_JOB ) {
            script.echo("Roll back App Post E2E Failures")
        }

        def artifacturl = "${script.env.ALBERTA_ARTIFACTORY_URL}/${script.env.currentArtifactURL}"

        script.node("${script.env.CF_CLI_LABEL}") {
            script.withEnv(["CF_HOME=."]) {
                script.sh "curl -O --fail ${artifacturl}"
                def artifactId = script.sh(script: "basename ${artifacturl}", returnStdout: true).trim()
                def repoBaseName = commonUtil.getRepoName(artifacturl)
                println "this is repo name" + repoBaseName
                try {
                    if(repoBaseName.contains('varys') ){
                        steps.sh "unzip -o ${artifactId} -d dist"
                        artifactId = "dist"
                    }else if(repoBaseName.contains('cersei') ) {
                        steps.sh "unzip -o ${artifactId} -d dist"
                        artifactId = "dist/cersei"
                    }else{
                        steps.sh("jar xf ${artifactId} BOOT-INF/classes/manifest.yml")
                    }
                } catch (Exception e) {
                    script.echo("The app does not have the files required for pipeline configuration")
                }

                script.sh """
                    curl -ks -o manifest.yml \
                    "https://globalrepository.mclocal.int/stash/projects/ALBERTA/repos/${repoBaseName}/raw/manifest.yml?at=refs%2Fheads%2Fdev"
                  """
                if (script.fileExists("manifest.yml")) {
                    script.echo "Found manifest.yml file, will update the path value with the downloaded artifact path"
                    def manifestData = script.readFile("manifest.yml")
                    script.writeFile(file: "manifest.yml", text: manifestData.replaceAll(/path:[a-zA-Z0-9. \/-]+/, "path: ${artifactId}"))
                    script.sh("more manifest.yml")
                }
                script.sh "ls -latr"

                envVarMap['ArtifactURL'] = "${script.env.currentArtifactURL}"

                zeroDowntimeRefreshToPCFGoRouter(
                        script,
                        "${script.env.currentBlueAppName}",
                        "${script.env.PCF_FOUNDATION}",
                        "${script.env.PCF_ORG}",
                        "${script.env.PCF_DEV_SPACE}",
                        "${script.env.PCF_CREDENTIALS}",
                        null,
                        null,
                        envVarMap,
                        false,
                        false,
                        'pcf' // TODO: Shared Util this
                )

                if(!(repoBaseName.contains('cersei') ||  repoBaseName.contains('varys')) ) {
                    script.echo("Restoring Old Backed up File")
                    restoreOldBackApp(script)
                }

                if(artifactUpload){
                    script.echo("Deleting Corrupted Artifact")
                    try {
                        script.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "artifactory-creds", usernameVariable: 'UNAME', passwordVariable: 'PASS']]) {
                            script.sh "curl -X DELETE -u ${script.UNAME}:${script.PASS}  ${script.env.ALBERTA_ARTIFACTORY_URL}/${script.env.artifactURL}"
                        }
                    }catch (Exception ex){
                        steps.echo "${ex}"
                    }
                }
            }
        }
    }

    public void deployStaticReports(script) {
        script.node('DTL-CF-CLI') {
            script.git url:"https://globalrepository.mclocal.int/stash/scm/alberta/lighthouse-reports.git", branch:"master"

            script.withEnv(["CF_HOME=."]) {
                try {
                    script.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${script.env.PCF_CREDENTIALS}", usernameVariable: 'PCF_USER', passwordVariable: 'PCF_PASSWORD']]) {
                        script.sh "cf login -a ${script.env.PAAS_URL} -u ${script.PCF_USER} -p ${script.PCF_PASSWORD} -o ${script.env.PCF_ORG} -s ${script.env.PCF_DEV_SPACE}"
                    }
                    script.sh "cf push lighthouse-reports -n lighthouse-reports"
                }
                catch (Exception ex) {
                    script.echo(ex)
                }
                finally {
                    script.sh "cf logout"
                }
            }
        }
    }

    /**
     * Set PAAS_URL as environment Variable based on Foundation
     *
     */
    public void getPaasURL(script){
        def paasUrl = ''
        switch(script.env.PCF_FOUNDATION) {
            case 'stl-stage': paasUrl = 'api.system.stl.pcfstage00.mastercard.int'; break;
            case 'stl-prod': paasUrl = 'api.system.stl.pcfprod00.mastercard.int'; break;
            case 'stl-dev': paasUrl = 'api.system.stl.pcfdev00.mastercard.int'; break;
            case 'bel-prod': paasUrl = 'api.system.bel.pcfprod00.mastercard.int'; break;
            case 'ksc-prod': paasUrl = 'api.system.ksc.pcfprod00.mastercard.int'; break;
        }
        script.env.PAAS_URL = paasUrl
    }

    public void zeroDowntimeRefreshToPCFGoRouter(script, String appHostName, String env, String org, String space, String pcfCredentialsId, String vaultCredentialsId, String vaultBackendId, Map keyMap, boolean synapseEnabled, boolean vaultEnabled, String activeProfile, String buildPack = 'java_buildpack_offline', String pathToDirectory = '.' , String dirToPush='.',String manifestLoc=null) {

        def appDomain = ''
        def paas_url = ''

        switch(env) {
            case 'stl-dev': appDomain = script.globalVars.devDomain; paas_url = script.globalVars.devPaas_url; break;
            case 'stl-stage': appDomain = script.globalVars.stageDomain; paas_url = script.globalVars.stagePaas_url; break;
            case 'bel-prod': appDomain = script.globalVars.prodDomain; paas_url = script.globalVars.prodPaas_url;  break;
            case 'stl-prod': appDomain = script.globalVars.stl_prodDomain; paas_url = script.globalVars.stl_prodPaas_url; break;
            case 'ksc-prod': appDomain = script.globalVars.ksc_prodDomain; paas_url = script.globalVars.ksc_prodPaas_url; break;
        }

        def appRoute = "https://${appHostName}.${appDomain}"
        def greenAppHostName = "${appHostName}-green"

        steps.withEnv(["CF_HOME=."]) {

            try {

                steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${pcfCredentialsId}", usernameVariable: 'PCF_USERNAME', passwordVariable: 'PCF_PASSWORD']]) {
                    steps.sh "cf login -a ${paas_url} -u ${script.PCF_USERNAME} -p ${script.PCF_PASSWORD} -o ${org} -s ${space}"
                }

                def pushString = ''
                if(manifestLoc) pushString = " -f ${manifestLoc}"

                steps.dir(dirToPush) {
                    //push application but don't start it so we can set env variables
                   // steps.sh "cf push ${greenAppHostName} -n ${greenAppHostName} ${pushString} -b ${buildPack} -p ${pathToDirectory} --no-manifest -v --no-start"
                    steps.sh "cf push ${greenAppHostName} -n ${greenAppHostName} ${pushString} --no-start"
                }

                if(activeProfile) {
                    steps.sh "cf set-env ${greenAppHostName} SPRING_PROFILES_ACTIVE ${activeProfile}"
                }

                if(vaultEnabled) {
                    steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${vaultCredentialsId}", usernameVariable: 'VAULT_ID', passwordVariable: 'VAULT_SECRET']]) {
                        steps.sh "cf set-env ${greenAppHostName} SPRING_CLOUD_VAULT_APP-ROLE_AUTH-PATH approle"
                        steps.sh "cf set-env ${greenAppHostName} SPRING_CLOUD_VAULT_APP-ROLE_ROLE-ID ${script.VAULT_ID}"
                        steps.sh "cf set-env ${greenAppHostName} SPRING_CLOUD_VAULT_APP-ROLE_SECRET-ID ${script.VAULT_SECRET}"
                        steps.sh "cf set-env ${greenAppHostName} SPRING_CLOUD_VAULT_AUTHENTICATION APPROLE"
                        steps.sh "cf set-env ${greenAppHostName} SPRING_CLOUD_VAULT_GENERIC_BACKEND ${vaultBackendId}"
                        steps.sh "cf set-env ${greenAppHostName} SPRING_CLOUD_VAULT_HOST ${env.replace('-','.')}.vault.mastercard.int"
                        steps.sh "cf set-env ${greenAppHostName} SPRING_CLOUD_VAULT_PORT 8200"
                        steps.sh "cf set-env ${greenAppHostName} SPRING_CLOUD_VAULT_SCHEME https"
                        steps.sh "cf set-env ${greenAppHostName} SPRING_CLOUD_VAULT_ENABLED true"
                        if(keyMap["vaultApplicationName"]) {
                            def vaultApplicationName = keyMap["vaultApplicationName"]
                            steps.sh "cf set-env ${greenAppHostName} SPRING_CLOUD_VAULT_GENERIC_APPLICATION-NAME ${vaultApplicationName}"
                        }
                    }
                }

                def encodedClientKeyFile = keyMap["encodedKeyfile"]
                def encodedClientKeyFilePassword = keyMap["encodedKeyfilePassword"]

                steps.sh "cf set-env ${greenAppHostName} KEYSTORE ${encodedClientKeyFile}"
                steps.sh "cf set-env ${greenAppHostName} TRUSTSTORE /etc/ssl/certs/ca-certificates.crt"
                steps.sh "cf set-env ${greenAppHostName} KEYSTORE_PASSWORD ${encodedClientKeyFilePassword}"

                if(synapseEnabled) {
                    steps.sh "cf set-env ${greenAppHostName} SYNAPSE_SSL_KEYSTORE_CLIENT_ALIAS client-common"
                    steps.sh "cf set-env ${greenAppHostName} SYNAPSE_SSL_KEYSTORE_LOCATION KEYSTORE"

                    switch(env) {
                        case 'stl-dev':
                            steps.sh "cf set-env ${greenAppHostName} APIE_REGION US"
                            steps.sh "cf set-env ${greenAppHostName} APIE_PLATFORM DEV"
                            steps.sh "cf set-env ${greenAppHostName} APIE_ZONE STL"
                            break;
                        case 'stl-stage':
                            steps.sh "cf set-env ${greenAppHostName} APIE_REGION US"
                            steps.sh "cf set-env ${greenAppHostName} APIE_PLATFORM STAGE"
                            steps.sh "cf set-env ${greenAppHostName} APIE_ZONE STL"
                            break;
                        case 'bel-prod':
                            steps.sh "cf set-env ${greenAppHostName} APIE_REGION EU"
                            steps.sh "cf set-env ${greenAppHostName} APIE_PLATFORM PROD"
                            steps.sh "cf set-env ${greenAppHostName} APIE_ZONE BEL"
                            break;
                        case 'ksc-prod':
                            steps.sh "cf set-env ${greenAppHostName} APIE_REGION US"
                            steps.sh "cf set-env ${greenAppHostName} APIE_PLATFORM PROD"
                            steps.sh "cf set-env ${greenAppHostName} APIE_ZONE KSC"
                            break;
                        case 'stl-prod':
                            steps.sh "cf set-env ${greenAppHostName} APIE_REGION US"
                            steps.sh "cf set-env ${greenAppHostName} APIE_PLATFORM PROD"
                            steps.sh "cf set-env ${greenAppHostName} APIE_ZONE STL"
                            break;
                    }
                }

                //set custom variables including any overrides
                setPCFEnvVarsFromMap(script, greenAppHostName, keyMap)

                steps.sh "cf start ${greenAppHostName}"
                //restarge and start the application
                steps.sh "cf restage ${greenAppHostName}"
                steps.sh "cf start ${greenAppHostName}"

                if(keyMap["instance_count"] != null) {
                    def instanceCount = keyMap["instance_count"]
                    steps.sh "cf scale ${greenAppHostName} -i ${instanceCount}"
                }else{
                    def count = commonUtil.getInstanceCount(appHostName)
                    if(count){
                        steps.sh "cf scale ${greenAppHostName} -i ${count}"
                    }
                }

                //map new to main route
                steps.sh "cf map-route ${greenAppHostName} ${appDomain} -n ${appHostName}"

                //unmap old from main route
                steps.sh "cf unmap-route ${appHostName} ${appDomain} -n ${appHostName}"

                //rename oldApp to oldApp-old
                steps.sh "cf rename ${appHostName} ${appHostName}-old"

                //map oldApp-old to main route
                steps.sh "cf map-route ${appHostName}-old ${appDomain} -n ${appHostName}"

                //unmap new from main route
                steps.sh "cf unmap-route ${greenAppHostName} ${appDomain} -n ${appHostName}"

                //unmap the temp route from green app
                steps.sh "cf unmap-route ${greenAppHostName} ${appDomain} -n ${greenAppHostName}"

                //get other routes from old app. not live route
                String[] routes = commonUtil.getRoutesForApp("${appHostName}-old")

                int numberRoutes = routes.length

                //rename green to old
                steps.sh "cf rename ${greenAppHostName} ${appHostName}"


                for (int i = 0; i < numberRoutes; i++) {
                    String[] nameOfRoute = routes[i].split('\\.')

                    steps.echo "this is name of the route: ${nameOfRoute}"

                    //getting any possible api
                    String path = commonUtil.getPathForRoute(routes[i])

                    steps.echo "this is path: ${path}"

                    if (appRoute != nameOfRoute[0].trim()) {
                        //map other routes to new blue app
                        steps.sh "cf map-route ${appHostName} ${appDomain} --hostname ${nameOfRoute[0].trim()} ${path}"
                    }
                }

                //map new to main route
                steps.sh "cf map-route ${appHostName} ${appDomain} -n ${appHostName}"

                //delete old
                steps.sh "cf delete ${appHostName}-old -f"

            } finally {
                steps.sh "cf logout"
                steps.deleteDir()
            }
        }
    }

    // This sets pcf env variables from the key map
    private void setPCFEnvVarsFromMap(script, String appHostName, Map keyMap) {
        keyMap.each{ k, v -> steps.echo "set ${k} to ${v}"; steps.sh "cf set-env ${appHostName} ${k} ${v}";}
    }

  	// This function binds an environment variable to a PCF application
    private void bindEnvVarToApp(script, String appHostName, String pcfFoundation, String pcfOrg, String pcfSpace, String pcfCredentials, String appVariable, String appVariableValue) {

        def albertaPCFUtil = new org.mastercard.alberta.AlbertaPCFUtil(script)
        def paas_url = albertaPCFUtil.getPcfFoundationUrl(script, pcfFoundation)

        steps.withEnv(["CF_HOME=."]) {
            try {
                steps.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${pcfCredentials}", usernameVariable: 'PCF_USERNAME', passwordVariable: 'PCF_PASSWORD']]) {
                    steps.sh "cf login -a ${paas_url} -u ${script.PCF_USERNAME} -p ${script.PCF_PASSWORD} -o ${pcfOrg} -s ${pcfSpace}"
                    steps.sh "cf set-env ${appHostName} ${appVariable} ${appVariableValue}"
                    steps.sh "cf restage ${appHostName}"
                    steps.sh "cf start ${appHostName}"
                }
            }
            catch (Exception ex) {
                steps.echo "${ex}"
            }
            finally {
                steps.sh "cf logout"
            }
        }
    }

}
