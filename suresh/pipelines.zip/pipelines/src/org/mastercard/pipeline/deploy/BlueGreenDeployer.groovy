package org.mastercard.pipeline.deploy

import java.util.regex.Matcher

/**
 * Utility to interact with the PCF platform. Used to deploy artifacts and manage services.
 *
 * @author Indrajitsinh.Gohil
 */

class BlueGreenDeployer implements Serializable {

	/**
	 * a reference to the pipeline that allows you to run pipeline steps in your shared libary
	 */
	private final Object  steps
  def commonUtil

	/**
	 * pcfCredentialsId the name of the credentialsId you want to use to deploy to PCF (configured in Jenkins)
	 */
	private final String pcfCredId

	/**
	 * org what PCF org we want to deploy to
	 */
	private final String org

	/**
	 * space what PCF space we want to deploy to
	 */
	private final String space

	/**
	 * appDomain
	 */
	private final String appDomain

	/**
	 * Platform foundation URL.
	 */
	private final String paasUrl

	/**
	 * appHostName Name of the app, should be same as in manifest.
	 */
	private String appHostName
	/**
	 * Testing route defined by
	 */
	private String testRoute
	/**
	 * Tracks if green deployment is done or not.
	 */
	boolean isGreenDeployed = false


	/**
	 * Constructor
	 *
	 * @param steps A reference to the steps in a pipeline to give access to them in the shared library.
	 * @param org what PCF org we want to deploy to
	 * @param space what PCF space we want to deploy to
	 * @param pcfCredId the name of the credentialsId you want to use to deploy to PCF (configured in Jenkins)
	 * @param env what we are deploying to. values can be 'stl-dev', 'stl-stage', or 'bel-prod'
	 */
	public BlueGreenDeployer(Object steps, String org, String space, String pcfCredId, String env) {
		this.steps = steps
		this.org = org
		this.space = space
		this.pcfCredId = pcfCredId
        this.commonUtil = new org.mastercard.alberta.CommonUtil(steps)

		switch(env) {
			case 'stl-dev': appDomain = steps.globalVars.DEV_PAAS_DOMAIN; paasUrl = steps.globalVars.DEV_PAAS_URL; break;
			case 'stl-stage': appDomain = steps.globalVars.STAGE_PAAS_DOMAIN; paasUrl = steps.globalVars.STAGE_PAAS_URL; break;
			case 'bel-prod': appDomain = steps.globalVars.BEL_PROD_PAAS_DOMAIN; paasUrl = steps.globalVars.BEL_PROD_PAAS_URL;  break;
			case 'stl-prod': appDomain = steps.globalVars.STL_PROD_PAAS_DOMAIN; paasUrl = steps.globalVars.STL_PROD_PAAS_URL; break;
			case 'ksc-prod': appDomain = steps.globalVars.KSC_PROD_PAAS_DOMAIN; paasUrl = steps.globalVars.KSC_PROD_PAAS_URL; break;
		}
	}

	/**
	 * This method executes first part of overall Blue-Green deployment.
	 * Reads application name from manifest.yml and posfix "-green" to deploy application.
	 * use the CLI to do a CF push on an artifact and deploy it to a PCF env.
	 *
	 * @param testRoute A test rout on which you want to deploy green App. Default value will be green-<APP_NAME>
	 * @param envVarMap A Map containing the key value pair which needs to be set as an Environment variable.
	 * @param dirToPush optional relative directory to cf push from. defaults to current workspace directory.
	 * @param manifestLoc an optional string to be passed to the -f option of pcf push
	 */
	public void deployGreenApp(String testRoute = null, Map envVarMap = null, String dirToPush='.', String manifestLoc=null ) {
		def pushed = false
		boolean deployPcfPass = true


		steps.dir(dirToPush) {
			steps.withEnv(["CF_HOME=."]) {

				if(isGreenDeployed){
					steps.error "Green App is already deployed once. Please call flipTraffic() method to change Green app to Blue."
				}

				try {

					this.appHostName = commonUtil.getAppNameFromManifest()

					//TODO: Need to implement better approach for this. Route should be always provided by caller and also there should not be any hardcoded values in manifest file.
					//If test route is not provided take default one
					if (!testRoute) {
						testRoute = "green-${appHostName}"
					}

					steps.withCredentials([
							[$class: 'UsernamePasswordMultiBinding', credentialsId: "${pcfCredId}", usernameVariable: 'PCF_USERNAME', passwordVariable: 'PCF_PASSWORD']
					]) { steps.sh "cf login -a ${paasUrl} -u ${steps.PCF_USERNAME} -p ${steps.PCF_PASSWORD} -o ${org} -s ${space}" }

					def pushString = ''
					if(manifestLoc) pushString = " -f ${manifestLoc}"
					pushed = true
					//push application but don't start it so we can set env variables
					steps.echo "deploy green app"
					steps.sh "cf push ${appHostName}'-green' -n ${testRoute} ${pushString} --no-start"


					//Set PCF environment variables from map
					setEnvVarsFromMap(envVarMap)

					//Binding services
					//bindServices(appHostName)
					steps.sh "cf start ${appHostName}'-green'"//starting to get around restaging error
					//restarge and start the application
					steps.sh "cf restage ${appHostName}'-green'"
					steps.sh "cf start ${appHostName}'-green'"
				} catch (Exception ex) {
					steps.echo "${ex}"
					deployPcfPass = false
					if (pushed) {
						steps.sh "cf logs ${appHostName}'-green' --recent"
					}
				} finally {
					steps.sh "cf logout"
					this.testRoute = testRoute
					isGreenDeployed = true
					steps.deleteDir()
				}
				if (!deployPcfPass){
					steps.echo "JOB Exiting due to PCF Failure."
					steps.sh "exit 1"
				}
			}
		}
	}

	public void deleteGreenApp(Boolean isGreenDeployed = false) {
		steps.withEnv(["CF_HOME=."]) {
			if(isGreenDeployed){
				try {
					this.appHostName = commonUtil.getAppNameFromManifest()
					steps.echo "Deleting  ${appHostName}-green"

					steps.withCredentials([
							[$class: 'UsernamePasswordMultiBinding', credentialsId: "${pcfCredId}", usernameVariable: 'PCF_USERNAME', passwordVariable: 'PCF_PASSWORD']
					]) {
						steps.sh "cf login -a ${paasUrl} -u ${steps.PCF_USERNAME} -p ${steps.PCF_PASSWORD} -o ${org} -s ${space}"
					}

					steps.echo "un binds services for green app"
					unbindServices(appHostName)

					steps.echo "delete green app"
					steps.sh "cf delete ${appHostName}-green -f -r"

				}
				finally {
					steps.sh "cf logout"
					isGreenDeployed = false
					//steps.deleteDir()
				}
			}else{
				steps.error "There is no Green App"
			}
		}
	}

	/**
	 * This method executes Second part of overall Blue-Green deployment.
	 * Scales Green application to existing Blue application instance count.
	 * Route live traffic to Green application
	 * Delete blue backup application if exists.
	 * Remove live traffice from blue application.
	 * Rename Blue application to Blue backup, decrease it's instances to 0 and stop it.
	 * Reanme Green application to blue and remove test rout from it.
	 *
	 * @param liveRout A test rout on which you want to deploy green App. Default value will be blue-<APP_NAME>
	 * @param envVarMap A Map containing the key value pair which needs to be set as an Environment variable.
	 */
	public void flipTraffic(String liveRoute = null, Map envVarMap = null) {
		steps.withEnv(["CF_HOME=."]) {
			if (!isGreenDeployed) {
				steps.error "Cannot flip Traffic without deploying Green App"
			}

			try {

				//TODO: Need to implement better approach for this. Route should be always provided by caller and also there should not be any hardcoded values in manifest file.
				//If live route is not provided take default one
				if (!liveRoute) {
					liveRoute = "blue-${appHostName}"
				}

				steps.withCredentials([
						[$class: 'UsernamePasswordMultiBinding', credentialsId: "${pcfCredId}", usernameVariable: 'PCF_USERNAME', passwordVariable: 'PCF_PASSWORD']
				]) {
					steps.sh "cf login -a ${paasUrl} -u ${steps.PCF_USERNAME} -p ${steps.PCF_PASSWORD} -o ${org} -s ${space}"
				}

				steps.echo "Checking if Blue App already Exists"
				def blueAppExists = steps.sh(script: "cf app ${appHostName}'-blue'", returnStatus: true) == 0

				steps.env.currentArtifactURL = steps.sh(script: "cf env ${appHostName}'-blue' | grep ArtifactURL | awk '{print \$2}'", returnStdout: true).trim()
				steps.env.currentBlueAppName = "${appHostName}'-blue'"

				if ("${steps.env.currentArtifactURL}" == '') {
					steps.echo "Setting to new Artifact URL since there is not current Aritfact Version"
					steps.env.currentArtifactURL = "${steps.env.artifactURL}"
				}

				steps.echo "Current Artifact URL + ${steps.env.currentArtifactURL}"

				int count = 1;
				if (blueAppExists) {
					count = getInstanceCount()
				}

				steps.echo "Increasing Green Instance Count"
				steps.sh "cf scale ${appHostName}'-green' -i ${count}"

				steps.echo "Mapping Blue Route to Green App"
				if (blueAppExists) {
					//map all routes from blue to green
					String[] routes = getRoutesForApp("${appHostName}-blue")

					int numberRoutes = routes.length
					for (int i = 0; i < numberRoutes; i++) {
						String[] nameOfRoute = routes[i].split('\\.')
						//getting any possible api
						String path = commonUtil.getPathForRoute(routes[i])

						if (liveRoute != nameOfRoute[0].trim()) {
							steps.sh "cf map-route ${appHostName}'-green' ${appDomain} --hostname ${nameOfRoute[0].trim()} ${path}"
						}
					}
				} else {
					setCustomRoutesForApp("${appHostName}-green")
				}

				steps.sh "cf map-route ${appHostName}'-green' ${appDomain} --hostname ${liveRoute}"

				steps.echo "Un-mapping Test Route from Green App"
				steps.sh "cf unmap-route ${appHostName}'-green' ${appDomain} --hostname ${testRoute}"

				//Set PCF environment variables from map
				if (envVarMap) {
					setEnvVarsFromMap(envVarMap)
				}

				/* steps.echo "Restarting Green Application after setting up Environment Variables"
				steps.sh "cf restage ${appHostName}'-green'"
				steps.sh "cf start ${appHostName}'-green'"
				*/

				if (blueAppExists) {
					deleteBlueBack()
					sunsetBlueApp(liveRoute)
				}

				steps.echo "Renaming Green App to Blue"
				steps.sh "cf rename ${appHostName}'-green' ${appHostName}'-blue'"

				steps.echo "Restarting the app for synapse to update new route"
				steps.sh "cf restart ${appHostName}'-blue'"

			} finally {
				steps.sh "cf logout"
				this.isGreenDeployed = false
				this.appHostName = null
				this.testRoute = null
			}
		}
	}

	public void setCustomRoutesForApp(String appHostName) {
		steps.withEnv(["CF_HOME=."]) {
			def albertaPcfUtil = new org.mastercard.alberta.AlbertaPCFUtil(steps)
			def durableDataServicesPath = "api"
			def checkoutServicesPath = "api/checkout"
			def precheckoutServicesPath = "api/precheckout"
			def srciMiddleWarePath = "api"
			def remoteLoggingPath = "api/logging"
			def identityServicePath1 = "api/verification"
			def identityServicePath2 = "api/link"
			def srcRouteName

			if (appHostName.contains('durable-data-service')) {
				srcRouteName = "${steps.PCF_DEV_SPACE}-varys"
				albertaPcfUtil.setCustomPcfRoute(steps, "${steps.PCF_CREDENTIALS}", appHostName, srcRouteName, durableDataServicesPath)
			} else if (appHostName.contains('srci-middleware')) {
				srcRouteName = "${steps.PCF_DEV_SPACE}-cersei"
				albertaPcfUtil.setCustomPcfRoute(steps, "${steps.PCF_CREDENTIALS}", appHostName, srcRouteName, srciMiddleWarePath)
			} else if (appHostName.contains('remote-logging-service')) {
				srcRouteName = "${steps.PCF_DEV_SPACE}-varys"
				albertaPcfUtil.setCustomPcfRoute(steps, "${steps.PCF_CREDENTIALS}", appHostName, srcRouteName, remoteLoggingPath)

				srcRouteName = "${steps.PCF_DEV_SPACE}-cersei"
				albertaPcfUtil.setCustomPcfRoute(steps, "${steps.PCF_CREDENTIALS}", appHostName, srcRouteName, remoteLoggingPath)
			} else if (appHostName.contains('precheckout-service')) {
				srcRouteName = "${steps.PCF_DEV_SPACE}-varys"

				albertaPcfUtil.setCustomPcfRoute(steps, "${steps.PCF_CREDENTIALS}", appHostName, srcRouteName, precheckoutServicesPath)
			} else if (appHostName.contains('checkout-service')) {
				srcRouteName = "${steps.PCF_DEV_SPACE}-varys"

				albertaPcfUtil.setCustomPcfRoute(steps, "${steps.PCF_CREDENTIALS}", appHostName, srcRouteName, checkoutServicesPath)
			} else {
				steps.echo "No custom routes need to be set"
			}
		}
	}

	// This binds services
	private void bindServices(String appHostName) {
		steps.withEnv(["CF_HOME=."]) {
			def albertaPcfUtil = new org.mastercard.alberta.AlbertaPCFUtil(steps)
			def servicesList = albertaPcfUtil.getPcfServicesList(steps).tokenize(',')

			for (service in servicesList) {
				if (service.contains('config')) {
					steps.sh "cf bind-service ${appHostName}-green ${service}"
				}
				if (service.contains('redis')) {
					steps.sh "cf bind-service ${appHostName}-green ${service}"
				}
			}
		}
	}

	// This un-binds services
	private void unbindServices(String appHostName) {
		steps.withEnv(["CF_HOME=."]) {
			def albertaPcfUtil = new org.mastercard.alberta.AlbertaPCFUtil(steps)
			def servicesList = albertaPcfUtil.getPcfServicesList(steps).tokenize(',')

			for (service in servicesList) {
				if (service.contains('config')) {
					steps.sh "cf unbind-service ${appHostName}-green ${service}"
				}
				if (service.contains('redis')) {
					steps.sh "cf unbind-service ${appHostName}-green ${service}"
				}
			}
		}
	}

	// This sets env variables from the key map
	private void setEnvVarsFromMap(Map keyMap) {
		steps.withEnv(["CF_HOME=."]) {
			keyMap.each{ k, v -> steps.echo "set ${k} to ${v}"; steps.sh "cf set-env ${appHostName}'-green' ${k} ${v}";}
		}
	}

	private String[] getRoutesForApp(String appToGetRouteFrom){
		steps.withEnv(["CF_HOME=."]) {
			commonUtil.getRoutesForApp(appToGetRouteFrom)
		}
	}

  private int getInstanceCount(){
  		steps.withEnv(["CF_HOME=."]) {
  			commonUtil.getInstanceCount("${appHostName}-blue")
  		}
  }

	private void deleteBlueBack() {
		steps.withEnv(["CF_HOME=."]) {
			steps.echo "check if blue backup exist"
			def blueBackAppExists = steps.sh(script: "cf app ${appHostName}'-blue-back'", returnStatus: true) == 0

			def blueBackOldAppExists = steps.sh(script: "cf app ${appHostName}'-blue-back-old'", returnStatus: true) == 0
			if(blueBackOldAppExists){
				steps.sh "cf delete ${appHostName}'-blue-back-old' -f"
			}

			if (blueBackAppExists) {
				steps.echo "Blue Backup already Exists... Renaming the Existing back file to back_old"
				steps.sh "cf rename ${appHostName}'-blue-back' ${appHostName}'-blue-back-old'"
				//steps.sh "cf delete ${appHostName}'-blue-back' -f"
			}
		}
	}

	private void sunsetBlueApp(String liveRoute){
		steps.withEnv(["CF_HOME=."]) {
			steps.echo "Unmapping Live Route from Blue App"
			//this unmaps all routes
			String[] routes = getRoutesForApp("${appHostName}-blue")
			int numberRoutes = routes.length
			for(int i = 0; i < numberRoutes; i++){
				String[] nameOfRoute = routes[i].split('\\.')
				//getting any possible api
				String path = commonUtil.getPathForRoute(routes[i])
				steps.sh "cf unmap-route ${appHostName}'-blue' ${appDomain} --hostname ${nameOfRoute[0].trim()} ${path}"
			}


			steps.echo "Scaling Down Blue Instances to 0"
			steps.sh "cf scale ${appHostName}'-blue' -i 0"

			steps.echo "Stopping Blue Application"
			steps.sh "cf stop ${appHostName}'-blue'"

			steps.echo "Renaming Blue App to blue-back"
			steps.sh "cf rename ${appHostName}'-blue' ${appHostName}'-blue-back'"
		}
	}

}
